<?php
require_once '../../includes/functions.php';
check_permission([1, 2]); // Admin y Vendedor

include_once '../../includes/header.php';
$pdo = db_connect();

// Obtener métodos de pago
$metodos = ['Efectivo', 'Tarjeta Débito', 'Tarjeta Crédito', 'Transferencia'];
?>

<div class="row" id="pos-app">
    <!-- Columna Izquierda: Buscador -->
    <div class="col-md-4">
        <div class="card mb-3">
            <div class="card-header bg-primary text-white">Buscar Producto</div>
            <div class="card-body">
                <input type="text" id="buscador-producto" class="form-control mb-2" placeholder="Escriba código o nombre..." autofocus>
                <div id="resultados-busqueda" class="list-group">
                    <!-- AJAX Results -->
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-secondary text-white">Cliente</div>
            <div class="card-body">
                <div class="input-group mb-2">
                    <input type="text" id="buscador-cliente" class="form-control" placeholder="Buscar Cliente (Cédula/Nombre)">
                    <button class="btn btn-outline-secondary" type="button" id="btn-buscar-cliente"><i class="fas fa-search"></i></button>
                </div>
                <input type="hidden" id="cliente-id" value="">
                <div id="info-cliente" class="alert alert-info py-2" style="display:none;"></div>
                <button class="btn btn-sm btn-success w-100" data-bs-toggle="modal" data-bs-target="#modalNuevoCliente">
                    <i class="fas fa-user-plus"></i> Nuevo Cliente
                </button>
            </div>
        </div>
    </div>

    <!-- Columna Central: Carrito -->
    <div class="col-md-5">
        <div class="card h-100">
            <div class="card-header bg-dark text-white">Carrito de Compra</div>
            <div class="card-body p-0 table-responsive">
                <table class="table table-striped mb-0">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th width="80">Cant</th>
                            <th width="100">Subtotal</th>
                            <th width="40"></th>
                        </tr>
                    </thead>
                    <tbody id="carrito-body">
                        <!-- Items JS -->
                    </tbody>
                </table>
            </div>
            <div class="card-footer text-end">
                <button class="btn btn-danger btn-sm" onclick="limpiarCarrito()">Limpiar</button>
            </div>
        </div>
    </div>

    <!-- Columna Derecha: Resumen -->
    <div class="col-md-3">
        <div class="card border-primary h-100">
            <div class="card-header bg-primary text-white">Resumen de Venta</div>
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                    <span>Subtotal:</span>
                    <span id="lbl-subtotal">$0.00</span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>IVA (15%):</span>
                    <span id="lbl-iva">$0.00</span>
                </div>
                <div class="mb-3">
                    <label>Descuento:</label>
                    <input type="number" id="input-descuento" class="form-control form-control-sm text-end" value="0.00" min="0" step="0.01">
                </div>
                <hr>
                <div class="d-flex justify-content-between mb-3">
                    <h4 class="fw-bold">TOTAL:</h4>
                    <h4 class="fw-bold text-primary" id="lbl-total">$0.00</h4>
                </div>

                <div class="mb-3">
                    <label>Método de Pago:</label>
                    <select id="select-metodo" class="form-select">
                        <?php foreach($metodos as $m): ?>
                            <option value="<?php echo $m; ?>"><?php echo $m; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="d-grid">
                    <button class="btn btn-success btn-lg" onclick="procesarVenta()">
                        <i class="fas fa-check-circle"></i> PROCESAR
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Nuevo Cliente -->
<div class="modal fade" id="modalNuevoCliente" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="form-nuevo-cliente">
                <div class="modal-header">
                    <h5 class="modal-title">Registrar Cliente</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-2"><input type="text" name="cedula" class="form-control" placeholder="Cédula" required></div>
                    <div class="mb-2"><input type="text" name="nombre" class="form-control" placeholder="Nombre Completo" required></div>
                    <div class="mb-2"><input type="email" name="email" class="form-control" placeholder="Email"></div>
                    <div class="mb-2"><input type="text" name="telefono" class="form-control" placeholder="Teléfono"></div>
                    <div class="mb-2"><input type="text" name="direccion" class="form-control" placeholder="Dirección"></div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JS Logic for POS (Simplified) -->
<script>
    let carrito = [];

    // Config
    const IVA_RATE = 0.15;

    // Buscar Producto
    document.getElementById('buscador-producto').addEventListener('keyup', function() {
        let term = this.value;
        if(term.length < 2) {
            document.getElementById('resultados-busqueda').innerHTML = '';
            return;
        }

        fetch('<?php echo BASE_URL; ?>ajax/buscar-producto.php?q=' + term)
            .then(res => res.json())
            .then(data => {
                let html = '';
                data.forEach(p => {
                    html += `<a href="#" class="list-group-item list-group-item-action"
                    onclick="agregarAlCarrito(${p.id}, '${p.nombre}', ${p.precio_venta}, ${p.stock_actual}); return false;">
                    ${p.codigo} - ${p.nombre} ($${p.precio_venta}) [Stock: ${p.stock_actual}]
                    </a>`;
                });
                document.getElementById('resultados-busqueda').innerHTML = html;
            });
    });

    function agregarAlCarrito(id, nombre, precio, stock) {
        let existe = carrito.find(i => i.id === id);
        if(existe) {
            if(existe.cantidad < stock) existe.cantidad++;
            else alert('Stock insuficiente');
        } else {
            if(stock > 0) carrito.push({id, nombre, precio, cantidad: 1, stock});
            else alert('Sin stock');
        }
        renderCarrito();
        document.getElementById('buscador-producto').value = '';
        document.getElementById('resultados-busqueda').innerHTML = '';
        document.getElementById('buscador-producto').focus();
    }

    function renderCarrito() {
        let html = '';
        let subtotal = 0;

        carrito.forEach((item, index) => {
            let totalItem = item.precio * item.cantidad;
            subtotal += totalItem;
            html += `<tr>
                <td><small>${item.nombre}</small></td>
                <td><input type="number" min="1" max="${item.stock}" value="${item.cantidad}"
                    class="form-control form-control-sm" onchange="updateCantidad(${index}, this.value)"></td>
                <td>$${totalItem.toFixed(2)}</td>
                <td><button class="btn btn-xs btn-danger" onclick="removerItem(${index})">X</button></td>
            </tr>`;
        });

        document.getElementById('carrito-body').innerHTML = html;
        calcularTotales(subtotal);
    }

    function updateCantidad(index, val) {
        val = parseInt(val);
        if(val > 0 && val <= carrito[index].stock) {
            carrito[index].cantidad = val;
            renderCarrito();
        } else {
            alert('Cantidad inválida');
            renderCarrito();
        }
    }

    function removerItem(index) {
        carrito.splice(index, 1);
        renderCarrito();
    }

    function calcularTotales(subtotal) {
        let descuento = parseFloat(document.getElementById('input-descuento').value) || 0;
        let iva = subtotal * IVA_RATE;
        let total = (subtotal + iva) - descuento;

        document.getElementById('lbl-subtotal').innerText = '$' + subtotal.toFixed(2);
        document.getElementById('lbl-iva').innerText = '$' + iva.toFixed(2);
        document.getElementById('lbl-total').innerText = '$' + total.toFixed(2);
    }

    document.getElementById('input-descuento').addEventListener('change', () => renderCarrito()); // Re-calc triggers render which calculates

    function limpiarCarrito() {
        carrito = [];
        renderCarrito();
    }

    // Buscar Cliente AJAX
    document.getElementById('btn-buscar-cliente').addEventListener('click', function() {
        let q = document.getElementById('buscador-cliente').value;
        if(!q) return;

        fetch('<?php echo BASE_URL; ?>ajax/buscar-cliente.php?q=' + q)
            .then(res => res.json())
            .then(data => {
                if(data.id) {
                    document.getElementById('cliente-id').value = data.id;
                    document.getElementById('info-cliente').style.display = 'block';
                    document.getElementById('info-cliente').innerText = data.nombre + ' - ' + data.cedula;
                } else {
                    alert('Cliente no encontrado');
                }
            });
    });

    // Nuevo Cliente Form
    document.getElementById('form-nuevo-cliente').addEventListener('submit', function(e) {
        e.preventDefault();
        // Send AJAX to create client
        let formData = new FormData(this);
        fetch('<?php echo BASE_URL; ?>ajax/guardar-cliente.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if(data.success) {
                alert('Cliente creado');
                document.getElementById('cliente-id').value = data.id;
                document.getElementById('info-cliente').style.display = 'block';
                document.getElementById('info-cliente').innerText = data.nombre;
                const modal = bootstrap.Modal.getInstance(document.getElementById('modalNuevoCliente'));
                modal.hide();
            } else {
                alert('Error al crear cliente');
            }
        });
    });

    function procesarVenta() {
        if(carrito.length === 0) { alert('Carrito vacío'); return; }
        let clienteId = document.getElementById('cliente-id').value;
        if(!clienteId) { alert('Seleccione un cliente'); return; }

        let metodo = document.getElementById('select-metodo').value;
        let descuento = document.getElementById('input-descuento').value;

        let data = {
            cliente_id: clienteId,
            metodo_pago: metodo,
            descuento: descuento,
            productos: carrito
        };

        if(!confirm('¿Procesar venta por ' + document.getElementById('lbl-total').innerText + '?')) return;

        fetch('procesar-venta.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        })
        .then(res => res.json())
        .then(resp => {
            if(resp.success) {
                alert('Venta Procesada! Ticket #' + resp.numero_venta);
                window.location.href = 'ticket.php?id=' + resp.id_venta;
            } else {
                alert('Error: ' + resp.message);
            }
        });
    }

</script>

<?php include_once '../../includes/footer.php'; ?>
