<?php
require_once '../../includes/functions.php';
check_permission([1, 3]);

$id = $_GET['id'] ?? 0;
$pdo = db_connect();

// Obtener datos actuales para el log (antes de borrar)
$stmt = $pdo->prepare("SELECT * FROM productos WHERE id = ?");
$stmt->execute([$id]);
$producto = $stmt->fetch();

if($producto) {
    // 1. Soft Delete
    $stmtUpdate = $pdo->prepare("UPDATE productos SET activo = 0 WHERE id = ?");
    $stmtUpdate->execute([$id]);

    // 2. Manual Audit Log for "DELETE" (Since it's physically an update, but logically a delete)
    // We want to record all data that was "deleted"
    registrar_auditoria_operacion(
        'DELETE',
        'productos',
        $id,
        "Producto eliminado (Soft Delete): {$producto['nombre']}",
        $producto, // Old data (All fields)
        null,      // New data
        'productos'
    );

    header('Location: index.php?msg=deleted');
} else {
    header('Location: index.php?error=notfound');
}
exit;
