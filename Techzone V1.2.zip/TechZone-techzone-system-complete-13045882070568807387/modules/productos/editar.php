<?php
require_once '../../includes/functions.php';
check_permission([1, 3]);

include_once '../../includes/header.php';
$pdo = db_connect();

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM productos WHERE id = ?");
$stmt->execute([$id]);
$prod = $stmt->fetch();

if(!$prod) { echo "Producto no encontrado"; exit; }

$marcas = $pdo->query("SELECT * FROM marcas")->fetchAll();
$categorias = $pdo->query("SELECT * FROM categorias_producto")->fetchAll();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect Data
    $codigo = $_POST['codigo'];
    $nombre = $_POST['nombre'];
    $desc = $_POST['descripcion'];
    $marca = $_POST['marca_id'];
    $cat = $_POST['categoria_id'];
    $p_compra = $_POST['precio_compra'];
    $p_venta = $_POST['precio_venta'];
    $stock = $_POST['stock'];

    try {
        // We use UPDATE. Trigger 'trg_productos_update' will automatically log the changes (Old vs New)
        $sql = "UPDATE productos SET codigo=?, nombre=?, descripcion=?, marca_id=?, categoria_id=?, precio_compra=?, precio_venta=?, stock_actual=? WHERE id=?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$codigo, $nombre, $desc, $marca, $cat, $p_compra, $p_venta, $stock, $id]);

        echo "<div class='alert alert-success'>Producto actualizado</div>";
        // Refresh data
        $stmt = $pdo->prepare("SELECT * FROM productos WHERE id = ?");
        $stmt->execute([$id]);
        $prod = $stmt->fetch();

    } catch(Exception $e) {
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}
?>

<h3>Editar Producto: <?php echo $prod['nombre']; ?></h3>

<form method="POST" class="row g-3">
    <div class="col-md-6">
        <label>Código</label>
        <input type="text" name="codigo" class="form-control" value="<?php echo $prod['codigo']; ?>" required>
    </div>
    <div class="col-md-6">
        <label>Nombre</label>
        <input type="text" name="nombre" class="form-control" value="<?php echo $prod['nombre']; ?>" required>
    </div>
    <div class="col-12">
        <label>Descripción</label>
        <textarea name="descripcion" class="form-control"><?php echo $prod['descripcion']; ?></textarea>
    </div>
    <div class="col-md-4">
        <label>Marca</label>
        <select name="marca_id" class="form-select">
            <?php foreach($marcas as $m) {
                $selected = ($m['id'] == $prod['marca_id']) ? 'selected' : '';
                echo "<option value='{$m['id']}' $selected>{$m['nombre']}</option>";
            } ?>
        </select>
    </div>
    <div class="col-md-4">
        <label>Categoría</label>
        <select name="categoria_id" class="form-select">
            <?php foreach($categorias as $c) {
                $selected = ($c['id'] == $prod['categoria_id']) ? 'selected' : '';
                echo "<option value='{$c['id']}' $selected>{$c['nombre']}</option>";
            } ?>
        </select>
    </div>
    <div class="col-md-4">
        <label>Stock Actual</label>
        <input type="number" name="stock" class="form-control" value="<?php echo $prod['stock_actual']; ?>">
    </div>
    <div class="col-md-6">
        <label>Precio Compra</label>
        <input type="number" step="0.01" name="precio_compra" class="form-control" value="<?php echo $prod['precio_compra']; ?>" required>
    </div>
    <div class="col-md-6">
        <label>Precio Venta</label>
        <input type="number" step="0.01" name="precio_venta" class="form-control" value="<?php echo $prod['precio_venta']; ?>" required>
    </div>

    <div class="col-12 mt-3">
        <button type="submit" class="btn btn-primary">Actualizar Producto</button>
        <a href="index.php" class="btn btn-secondary">Volver</a>
    </div>
</form>

<?php include_once '../../includes/footer.php'; ?>
