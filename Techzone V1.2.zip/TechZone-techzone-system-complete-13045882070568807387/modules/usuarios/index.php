<?php
require_once '../../includes/functions.php';
check_permission([1]); // Admin
include_once '../../includes/header.php';
$pdo = db_connect();

$usuarios = $pdo->query("SELECT u.*, r.nombre as rol FROM usuarios u JOIN roles r ON u.rol_id = r.id")->fetchAll();
?>

<h3>Gestión de Usuarios</h3>
<div class="mb-3">
    <a href="crear.php" class="btn btn-primary"><i class="fas fa-plus"></i> Nuevo Usuario</a>
</div>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Email</th>
            <th>Rol</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($usuarios as $u): ?>
        <tr>
            <td><?php echo htmlspecialchars($u['nombre']); ?></td>
            <td><?php echo htmlspecialchars($u['email']); ?></td>
            <td><?php echo htmlspecialchars($u['rol']); ?></td>
            <td><?php echo $u['activo'] ? 'Activo' : 'Inactivo'; ?></td>
            <td>
                <a href="editar.php?id=<?php echo $u['id']; ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                <a href="eliminar.php?id=<?php echo $u['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Eliminar usuario?');"><i class="fas fa-trash"></i></a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include_once '../../includes/footer.php'; ?>
