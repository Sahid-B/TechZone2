<?php
require_once '../../includes/functions.php';
check_permission([1]); // Admin
include_once '../../includes/header.php';
$pdo = db_connect();

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$id]);
$u = $stmt->fetch();

if(!$u) { echo "Usuario no encontrado"; exit; }

$roles = $pdo->query("SELECT * FROM roles")->fetchAll();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $rol_id = $_POST['rol_id'];
    $password = $_POST['password'];

    try {
        if(!empty($password)) {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE usuarios SET nombre=?, email=?, rol_id=?, password=? WHERE id=?");
            $stmt->execute([$nombre, $email, $rol_id, $hash, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE usuarios SET nombre=?, email=?, rol_id=? WHERE id=?");
            $stmt->execute([$nombre, $email, $rol_id, $id]);
        }
        echo "<div class='alert alert-success'>Usuario actualizado</div>";
        // Refresh
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
        $stmt->execute([$id]);
        $u = $stmt->fetch();
    } catch(Exception $e) {
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}
?>

<h3>Editar Usuario: <?php echo htmlspecialchars($u['nombre']); ?></h3>
<form method="POST" class="row g-3">
    <div class="col-md-6">
        <label>Nombre Completo</label>
        <input type="text" name="nombre" class="form-control" value="<?php echo htmlspecialchars($u['nombre']); ?>" required>
    </div>
    <div class="col-md-6">
        <label>Email</label>
        <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($u['email']); ?>" required>
    </div>
    <div class="col-md-6">
        <label>Contraseña (Dejar en blanco para mantener actual)</label>
        <input type="password" name="password" class="form-control">
    </div>
    <div class="col-md-6">
        <label>Rol</label>
        <select name="rol_id" class="form-select" required>
            <?php foreach($roles as $r): ?>
                <option value="<?php echo $r['id']; ?>" <?php echo $r['id'] == $u['rol_id'] ? 'selected' : ''; ?>><?php echo $r['nombre']; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-12 mt-3">
        <button type="submit" class="btn btn-primary">Actualizar</button>
        <a href="index.php" class="btn btn-secondary">Volver</a>
    </div>
</form>

<?php include_once '../../includes/footer.php'; ?>
