<?php
require_once '../../includes/functions.php';
check_permission([1]);

$id = $_GET['id'] ?? 0;
if($id == $_SESSION['user_id']) {
    die("No puede eliminarse a sí mismo");
}

$pdo = db_connect();

// Soft delete
// We don't have triggers for usuarios in the initial SQL provided by me earlier (it said "Repetir lógica").
// I need to ensure triggers exist OR do manual audit.
// I will do manual audit to be safe, but also update the SQL file in the next step to include triggers as promised.

$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$id]);
$u = $stmt->fetch();

if($u) {
    $stmt = $pdo->prepare("UPDATE usuarios SET activo = 0 WHERE id = ?");
    $stmt->execute([$id]);

    // Manual audit just in case trigger is missing (User Requirement override)
    registrar_auditoria_operacion('DELETE', 'usuarios', $id, "Usuario desactivado: {$u['nombre']}", $u, null, 'usuarios');

    header('Location: index.php?msg=deleted');
}
exit;
