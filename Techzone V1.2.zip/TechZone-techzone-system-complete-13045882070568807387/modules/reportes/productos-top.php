<?php
require_once '../../includes/functions.php';
check_permission([1]);
include_once '../../includes/header.php';
$pdo = db_connect();

$sql = "SELECT p.nombre, p.codigo, m.nombre as marca, c.nombre as categoria,
        SUM(dv.cantidad) as total_vendido, SUM(dv.subtotal) as ingresos
        FROM detalle_ventas dv
        JOIN productos p ON dv.id_producto = p.id
        JOIN marcas m ON p.marca_id = m.id
        JOIN categorias_producto c ON p.categoria_id = c.id
        GROUP BY p.id
        ORDER BY total_vendido DESC
        LIMIT 20";
$top = $pdo->query($sql)->fetchAll();
?>

<h3>Productos Más Vendidos (Top 20)</h3>
<button onclick="window.print()" class="btn btn-secondary mb-3 no-print">Imprimir</button>

<table class="table table-striped">
    <thead>
        <tr>
            <th>Rank</th>
            <th>Producto</th>
            <th>Marca</th>
            <th>Categoría</th>
            <th>Unidades</th>
            <th>Ingresos</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($top as $k => $p): ?>
        <tr>
            <td><?php echo $k + 1; ?></td>
            <td><?php echo htmlspecialchars($p['nombre']); ?> (<?php echo $p['codigo']; ?>)</td>
            <td><?php echo htmlspecialchars($p['marca']); ?></td>
            <td><?php echo htmlspecialchars($p['categoria']); ?></td>
            <td><?php echo $p['total_vendido']; ?></td>
            <td><?php echo format_currency($p['ingresos']); ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<style>@media print { .no-print { display: none; } }</style>

<?php include_once '../../includes/footer.php'; ?>
