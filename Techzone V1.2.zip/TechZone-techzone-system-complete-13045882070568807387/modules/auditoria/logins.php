<?php
require_once '../../includes/functions.php';
check_permission([1]); // Solo admin

include_once '../../includes/header.php';

$pdo = db_connect();

// Filtros
$start_date = $_GET['start'] ?? date('Y-m-d');
$end_date = $_GET['end'] ?? date('Y-m-d');
$start_ts = $start_date . " 00:00:00";
$end_ts = $end_date . " 23:59:59";

$stmt = $pdo->prepare("CALL sp_obtener_auditoria_login(?, ?)");
$stmt->execute([$start_ts, $end_ts]);
$logins = $stmt->fetchAll();
?>

<h3>Auditoría de Logins</h3>

<form class="row g-3 mb-4" method="GET">
    <div class="col-auto">
        <label for="start" class="col-form-label">Desde</label>
        <input type="date" class="form-control" name="start" value="<?php echo $start_date; ?>">
    </div>
    <div class="col-auto">
        <label for="end" class="col-form-label">Hasta</label>
        <input type="date" class="form-control" name="end" value="<?php echo $end_date; ?>">
    </div>
    <div class="col-auto align-self-end">
        <button type="submit" class="btn btn-primary">Filtrar</button>
    </div>
</form>

<table class="table table-striped table-hover">
    <thead class="table-dark">
        <tr>
            <th>Fecha/Hora</th>
            <th>Usuario</th>
            <th>Email Usado</th>
            <th>IP</th>
            <th>Tipo</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($logins as $log): ?>
        <tr>
            <td><?php echo htmlspecialchars($log['fecha_hora']); ?></td>
            <td><?php echo htmlspecialchars($log['nombre_usuario'] ?? 'N/A'); ?></td>
            <td><?php echo htmlspecialchars($log['email_usado']); ?></td>
            <td><?php echo htmlspecialchars($log['ip_address']); ?></td>
            <td>
                <?php if($log['tipo_accion'] == 'login_exitoso'): ?>
                    <span class="badge bg-success">Exitoso</span>
                <?php elseif($log['tipo_accion'] == 'login_fallido'): ?>
                    <span class="badge bg-danger">Fallido</span>
                <?php else: ?>
                    <span class="badge bg-secondary">Logout</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include_once '../../includes/footer.php'; ?>
