<?php
require_once 'config/constants.php';
header('Location: ' . BASE_URL . 'auth/login.php');
exit;
