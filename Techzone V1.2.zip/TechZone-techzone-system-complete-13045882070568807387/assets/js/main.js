// assets/js/main.js
// Custom JS for TechZone

console.log('TechZone System Loaded');

// Helper for formatting currency
function formatCurrency(value) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(value);
}
