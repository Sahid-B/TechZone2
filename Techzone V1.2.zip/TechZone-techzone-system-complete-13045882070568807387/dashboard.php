<?php
require_once 'includes/functions.php';
check_login();
include_once 'includes/header.php';

$rol_id = $_SESSION['rol_id'];
$pdo = db_connect();

// Fetch Data for Dashboard based on Role
$stats = [];

// Admin Stats
if ($rol_id == 1) {
    // Total Clientes
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM clientes");
    $stats['clientes'] = $stmt->fetch()['total'];

    // Total Productos
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM productos WHERE activo = 1");
    $stats['productos'] = $stmt->fetch()['total'];

    // Ventas del dia
    $stmt = $pdo->query("SELECT SUM(total) as total FROM ventas WHERE DATE(fecha_venta) = CURDATE()");
    $stats['ventas_hoy'] = $stmt->fetch()['total'] ?? 0;

    // Logins Today
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM auditoria_login WHERE DATE(fecha_hora) = CURDATE() AND tipo_accion='login_exitoso'");
    $stats['logins_hoy'] = $stmt->fetch()['total'];

    // Audit Operations Today
    $stmt = $pdo->query("SELECT accion, COUNT(*) as total FROM auditoria_operaciones WHERE DATE(fecha_hora) = CURDATE() GROUP BY accion");
    $stats['ops_hoy'] = $stmt->fetchAll(PDO::FETCH_KEY_PAIR); // [INSERT => 5, UPDATE => 2]
}

// Vendedor Stats
if ($rol_id == 2) {
     $stmt = $pdo->prepare("SELECT SUM(total) as total FROM ventas WHERE id_usuario = ? AND DATE(fecha_venta) = CURDATE()");
     $stmt->execute([$_SESSION['user_id']]);
     $stats['mis_ventas_hoy'] = $stmt->fetch()['total'] ?? 0;

     $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM ventas WHERE id_usuario = ?");
     $stmt->execute([$_SESSION['user_id']]);
     $stats['mis_ventas_count'] = $stmt->fetch()['total'];
}

// Almacen Stats
if ($rol_id == 3) {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM productos WHERE stock_actual <= stock_minimo AND activo = 1");
    $stats['low_stock'] = $stmt->fetch()['total'];

    $stmt = $pdo->query("SELECT SUM(stock_actual * precio_compra) as total_compra FROM productos WHERE activo=1");
    $stats['valor_inventario'] = $stmt->fetch()['total_compra'];
}

// Cliente Stats (Rol Virtual 4)
if ($rol_id == 4) {
    // Productos para Catálogo (Simple Gallery)
    $stmt = $pdo->query("SELECT * FROM productos WHERE activo = 1 AND stock_actual > 0 ORDER BY nombre LIMIT 20");
    $catalogo = $stmt->fetchAll();

    // Mis compras
    $stmt = $pdo->prepare("SELECT * FROM ventas WHERE id_cliente = ? ORDER BY fecha_venta DESC LIMIT 10");
    $stmt->execute([$_SESSION['user_id']]);
    $mis_compras = $stmt->fetchAll();
}

?>

<!-- Client Welcome Hero -->
<?php if($rol_id == 4): ?>
<div class="p-5 mb-4 bg-primary text-white rounded-3 shadow-sm">
    <div class="container-fluid py-3">
        <h1 class="display-5 fw-bold">Bienvenido a TechZone</h1>
        <p class="col-md-8 fs-4">Encuentra la mejor tecnología al mejor precio. Explora nuestro catálogo y realiza tus pedidos hoy mismo.</p>
    </div>
</div>
<?php else: ?>
<h2 class="mb-4">Dashboard - <small class="text-muted"><?php echo htmlspecialchars($_SESSION['rol_nombre']); ?></small></h2>
<?php endif; ?>

<div class="row">
    <!-- Admin Widgets -->
    <?php if ($rol_id == 1): ?>
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-primary h-100 shadow-sm border-0">
            <div class="card-body">
                <h5 class="card-title"><i class="fas fa-users"></i> Clientes</h5>
                <p class="card-text display-6"><?php echo (int)$stats['clientes']; ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-success h-100 shadow-sm border-0">
            <div class="card-body">
                <h5 class="card-title"><i class="fas fa-dollar-sign"></i> Ventas Hoy</h5>
                <p class="card-text display-6"><?php echo format_currency($stats['ventas_hoy']); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-info h-100 shadow-sm border-0">
            <div class="card-body">
                <h5 class="card-title"><i class="fas fa-box"></i> Productos</h5>
                <p class="card-text display-6"><?php echo (int)$stats['productos']; ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-warning h-100 shadow-sm border-0">
            <div class="card-body">
                <h5 class="card-title"><i class="fas fa-key"></i> Logins Hoy</h5>
                <p class="card-text display-6"><?php echo (int)$stats['logins_hoy']; ?></p>
            </div>
        </div>
    </div>

    <div class="col-md-6 mb-4">
        <div class="card h-100 shadow-sm">
            <div class="card-header bg-white">Últimas Operaciones de Auditoría</div>
            <div class="card-body">
                <table class="table table-sm table-borderless">
                    <thead><tr><th>Usuario</th><th>Acción</th><th>Tabla</th><th>Hora</th></tr></thead>
                    <tbody>
                        <?php
                        $stmt = $pdo->query("SELECT nombre_usuario, accion, tabla_afectada, DATE_FORMAT(fecha_hora, '%H:%i') as hora FROM auditoria_operaciones ORDER BY id DESC LIMIT 5");
                        while($row = $stmt->fetch()){
                            echo "<tr><td>" . htmlspecialchars($row['nombre_usuario']) . "</td><td><span class='badge bg-light text-dark border'>" . htmlspecialchars($row['accion']) . "</span></td><td>" . htmlspecialchars($row['tabla_afectada']) . "</td><td>" . htmlspecialchars($row['hora']) . "</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
                <a href="modules/auditoria/operaciones.php" class="btn btn-sm btn-outline-primary">Ver todas</a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Vendedor Widgets -->
    <?php if ($rol_id == 2): ?>
    <div class="col-md-4 mb-4">
        <div class="card text-white bg-success h-100 shadow-sm">
            <div class="card-body">
                <h5 class="card-title">Mis Ventas Hoy</h5>
                <p class="card-text display-6"><?php echo format_currency($stats['mis_ventas_hoy']); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card text-white bg-primary h-100 shadow-sm">
            <div class="card-body">
                <h5 class="card-title">Total Ventas</h5>
                <p class="card-text display-6"><?php echo (int)$stats['mis_ventas_count']; ?></p>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Almacen Widgets -->
    <?php if ($rol_id == 3 || $rol_id == 1): ?>
        <?php if($rol_id == 1) echo "<div class='col-12 mt-4'><h4>Inventario</h4></div>"; ?>
        <div class="col-md-4 mb-4">
            <div class="card text-white bg-danger h-100 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Stock Bajo</h5>
                    <p class="card-text display-6"><?php echo (int)($stats['low_stock'] ?? 0); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
             <div class="card text-white bg-secondary h-100 shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Valor Inventario</h5>
                    <p class="card-text display-6"><?php echo format_currency($stats['valor_inventario'] ?? 0); ?></p>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Cliente Catalog & History -->
    <?php if ($rol_id == 4): ?>

    <div class="col-12 mb-4">
        <h3 class="mb-3">Catálogo de Productos</h3>
        <div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 g-4">
            <?php foreach($catalogo as $prod): ?>
            <div class="col">
                <div class="card h-100 shadow-sm border-0 product-card">
                    <?php if($prod['ruta_imagen']): ?>
                        <img src="<?php echo htmlspecialchars($prod['ruta_imagen']); ?>" class="card-img-top p-3" alt="..." style="height: 200px; object-fit: contain;">
                    <?php else: ?>
                        <div class="d-flex align-items-center justify-content-center bg-light" style="height: 200px;">
                            <i class="fas fa-image fa-3x text-muted"></i>
                        </div>
                    <?php endif; ?>
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title text-truncate" title="<?php echo htmlspecialchars($prod['nombre']); ?>"><?php echo htmlspecialchars($prod['nombre']); ?></h5>
                        <p class="card-text text-muted small flex-grow-1"><?php echo htmlspecialchars(substr($prod['descripcion'], 0, 60)) . '...'; ?></p>
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <span class="fs-5 fw-bold text-primary"><?php echo format_currency($prod['precio_venta']); ?></span>
                            <button class="btn btn-outline-primary btn-sm" onclick="alert('Función de compra en línea próximamente')"><i class="fas fa-cart-plus"></i> Comprar</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="col-12 mt-5">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white">
                <h5 class="mb-0">Mis Compras Recientes</h5>
            </div>
            <div class="card-body">
                <?php if(count($mis_compras) > 0): ?>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th># Venta</th>
                            <th>Fecha</th>
                            <th>Total</th>
                            <th>Método Pago</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($mis_compras as $v): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($v['numero_venta']); ?></td>
                            <td><?php echo htmlspecialchars($v['fecha_venta']); ?></td>
                            <td><?php echo format_currency($v['total']); ?></td>
                            <td><?php echo htmlspecialchars($v['metodo_pago']); ?></td>
                            <td>
                                <a href="modules/ventas/ticket.php?id=<?php echo $v['id']; ?>" class="btn btn-sm btn-info text-white" target="_blank"><i class="fas fa-print"></i> Ver Ticket</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                    <p class="text-muted text-center py-4">No has realizado compras todavía.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

</div>

<?php include_once 'includes/footer.php'; ?>
