<?php
require_once __DIR__ . '/../config/constants.php';
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . 'dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login - TechZone</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f0f2f5; display: flex; align-items: center; justify-content: center; height: 100vh; }
        .login-card { width: 100%; max-width: 400px; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); background: white; }
        .brand-logo { font-size: 2rem; color: #0d6efd; text-align: center; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="brand-logo"><i class="fas fa-microchip"></i> TechZone</div>
        <h4 class="text-center mb-4">Iniciar Sesión</h4>

        <?php if(isset($_SESSION['success_login'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success_login']; unset($_SESSION['success_login']); ?></div>
        <?php endif; ?>

        <?php if(isset($_SESSION['error_login'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error_login']; unset($_SESSION['error_login']); ?></div>
        <?php endif; ?>

        <form action="procesar-login.php" method="POST">
            <div class="mb-3">
                <label for="email" class="form-label">Correo Electrónico</label>
                <input type="email" class="form-control" id="email" name="email" required autofocus>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Contraseña</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <div class="d-grid mb-3">
                <button type="submit" class="btn btn-primary">Ingresar</button>
            </div>
            <div class="text-center">
                <a href="registro.php">¿No tienes cuenta? Regístrate como Cliente</a>
            </div>
        </form>
    </div>
</body>
</html>
