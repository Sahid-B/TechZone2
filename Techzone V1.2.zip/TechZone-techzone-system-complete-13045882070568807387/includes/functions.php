<?php
// includes/functions.php
require_once __DIR__ . '/../config/database.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

function db_connect() {
    global $pdo; // From config/database.php

    // Set MySQL session variables for audit triggers if user is logged in
    if (isset($_SESSION['user_id'])) {
        try {
            $stmt = $pdo->prepare("SET @usuario_id = ?, @usuario_nombre = ?");
            $stmt->execute([$_SESSION['user_id'], $_SESSION['nombre']]);
        } catch (Exception $e) {
            // Ignore error if setting vars fails
        }
    }

    return $pdo;
}

function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function check_login() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: ' . BASE_URL . 'auth/login.php');
        exit;
    }
    // Ensure db connection is initialized and vars are set
    db_connect();
}

function check_permission($allowed_roles) {
    check_login();
    if (!in_array($_SESSION['rol_id'], $allowed_roles)) {
        // Redirect to dashboard with error or showing unauthorized page
        echo "<div class='alert alert-danger'>Acceso denegado. No tiene permisos para este módulo.</div>";
        echo "<a href='" . BASE_URL . "dashboard.php' class='btn btn-primary'>Volver al Dashboard</a>";
        exit;
    }
}

function get_user_ip() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

function get_user_agent() {
    return $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
}

function registrar_auditoria_login($user_id, $email, $type) {
    $pdo = db_connect();
    $ip = get_user_ip();
    $browser = get_user_agent();
    $session = session_id();

    try {
        $stmt = $pdo->prepare("CALL sp_registrar_login(:uid, :email, :ip, :browser, :type, :session)");
        $stmt->execute([
            ':uid' => $user_id, // Can be NULL for failed login
            ':email' => $email,
            ':ip' => $ip,
            ':browser' => $browser,
            ':type' => $type,
            ':session' => $session
        ]);
    } catch (Exception $e) {
        // Log error silently to file system if DB audit fails
        error_log("Audit Error: " . $e->getMessage());
    }
}

function registrar_auditoria_operacion($accion, $tabla, $registro_id, $descripcion, $datos_old = null, $datos_new = null, $modulo = 'general') {
    $pdo = db_connect();
    $user_id = $_SESSION['user_id'] ?? null;
    $nombre = $_SESSION['nombre'] ?? 'Sistema';
    $email = $_SESSION['email'] ?? 'system@techzone';
    $ip = get_user_ip();

    // Encode JSON if array, or ensure it's null/valid JSON
    $json_old = $datos_old ? json_encode($datos_old) : null;
    $json_new = $datos_new ? json_encode($datos_new) : null;

    try {
        $stmt = $pdo->prepare("CALL sp_registrar_operacion(:uid, :uname, :uemail, :accion, :tabla, :reg_id, :desc, :old, :new, :ip, :mod)");
        $stmt->execute([
            ':uid' => $user_id,
            ':uname' => $nombre,
            ':uemail' => $email,
            ':accion' => $accion,
            ':tabla' => $tabla,
            ':reg_id' => $registro_id,
            ':desc' => $descripcion,
            ':old' => $json_old,
            ':new' => $json_new,
            ':ip' => $ip,
            ':mod' => $modulo
        ]);
    } catch (Exception $e) {
        error_log("Audit Operation Error: " . $e->getMessage());
    }
}

function format_currency($amount) {
    return '$' . number_format($amount, 2);
}
?>
