<?php
require_once 'config/constants.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Inicializar carrito si no existe
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

// Obtener productos activos
$pdo = db_connect();

// Búsqueda si existe
$busqueda = $_GET['buscar'] ?? '';
$categoria_filtro = $_GET['categoria'] ?? '';

$query = "SELECT p.*, m.nombre as marca, c.nombre as categoria, c.id as categoria_id
          FROM productos p 
          LEFT JOIN marcas m ON p.marca_id = m.id 
          LEFT JOIN categorias_producto c ON p.categoria_id = c.id 
          WHERE p.activo = 1 AND p.stock_actual > 0";

$params = [];

if (!empty($busqueda)) {
    $query .= " AND (p.nombre LIKE ? OR p.descripcion LIKE ? OR p.codigo LIKE ?)";
    $search_term = "%$busqueda%";
    $params = [$search_term, $search_term, $search_term];
}

if (!empty($categoria_filtro)) {
    $query .= " AND c.nombre = ?";
    $params[] = $categoria_filtro;
}

$query .= " ORDER BY p.precio_venta DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$productos = $stmt->fetchAll();

// Obtener categorías
$categorias = $pdo->query("SELECT * FROM categorias_producto ORDER BY nombre")->fetchAll();

// Obtener marcas
$marcas = $pdo->query("SELECT * FROM marcas ORDER BY nombre")->fetchAll();

// Estadísticas
$total_productos = count($productos);
$stmt = $pdo->query("SELECT COUNT(*) as total FROM productos WHERE activo = 1 AND stock_actual > 0");
$total_disponibles = $stmt->fetch()['total'];

// Obtener productos destacados (los más caros, top 8)
$productos_destacados = array_slice($productos, 0, 8);

// Productos más vendidos (simulado - en producción vendría de la BD)
$productos_populares = array_slice($productos, 0, 6);

// Organizar productos por categoría
$productos_por_categoria = [];
foreach($productos as $prod) {
    $cat = $prod['categoria'] ?? 'Sin categoría';
    if(!isset($productos_por_categoria[$cat])) {
        $productos_por_categoria[$cat] = [];
    }
    $productos_por_categoria[$cat][] = $prod;
}

// Contar items en carrito
$carrito_count = count($_SESSION['carrito']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechZone - Tienda de Tecnología</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
    <style>
        .navbar-public {
            background: linear-gradient(90deg, #4e73df 0%, #224abe 100%) !important;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .product-card {
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            border: 1px solid #e3e6f0;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1) !important;
        }
        .btn-cart {
            position: relative;
        }
        .cart-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #dc3545;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 80px 0;
            margin-bottom: 40px;
            position: relative;
            overflow: hidden;
        }
        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg width="100" height="100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="2" fill="rgba(255,255,255,0.1)"/></svg>');
            animation: float 20s infinite linear;
        }
        @keyframes float {
            0% { transform: translateY(0); }
            100% { transform: translateY(-100px); }
        }
        .category-card {
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
            border: 2px solid transparent;
            background: white;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .category-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            border-color: #667eea;
        }
        .category-card.active {
            border-color: #667eea;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .product-card {
            animation: fadeInUp 0.5s ease forwards;
            opacity: 0;
        }
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .product-card:nth-child(1) { animation-delay: 0.1s; }
        .product-card:nth-child(2) { animation-delay: 0.2s; }
        .product-card:nth-child(3) { animation-delay: 0.3s; }
        .product-card:nth-child(4) { animation-delay: 0.4s; }
        .product-card:nth-child(5) { animation-delay: 0.5s; }
        .product-card:nth-child(6) { animation-delay: 0.6s; }
        .carousel-item {
            transition: transform 0.6s ease-in-out;
        }
        .section-title {
            position: relative;
            padding-bottom: 15px;
            margin-bottom: 30px;
        }
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 2px;
        }
        .btn-agregar-carrito {
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .btn-agregar-carrito::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255,255,255,0.3);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }
        .btn-agregar-carrito:hover::before {
            width: 300px;
            height: 300px;
        }
        .badge-new {
            position: absolute;
            top: 10px;
            right: 10px;
            background: #28a745;
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: bold;
            z-index: 10;
        }
        .filter-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 30px;
            justify-content: center;
        }
        .filter-btn {
            padding: 10px 20px;
            border: 2px solid #667eea;
            background: white;
            color: #667eea;
            border-radius: 25px;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .filter-btn:hover, .filter-btn.active {
            background: #667eea;
            color: white;
            transform: scale(1.05);
        }
        .categoria-section {
            transition: all 0.3s ease;
            margin-bottom: 50px;
        }
        .search-results {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .product-info {
            font-size: 0.85rem;
        }
        .product-info i {
            width: 20px;
            color: #667eea;
        }
    </style>
</head>
<body>
    <!-- Navbar Público -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-public">
        <div class="container">
            <a class="navbar-brand" href="<?php echo BASE_URL; ?>">
                <i class="fas fa-microchip"></i> TechZone
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <?php if($_SESSION['rol_id'] != 4): // Solo mostrar Panel si NO es cliente ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> Panel
                            </a>
                        </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link btn-cart" href="<?php echo BASE_URL; ?>carrito.php">
                                <i class="fas fa-shopping-cart"></i> Carrito
                                <?php if($carrito_count > 0): ?>
                                    <span class="cart-badge" id="cart-badge-nav"><?php echo $carrito_count; ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <span class="navbar-text me-3 text-white">
                                <?php echo htmlspecialchars($_SESSION['nombre']); ?>
                            </span>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>auth/logout.php">
                                <i class="fas fa-sign-out-alt"></i> Salir
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link btn-cart" href="<?php echo BASE_URL; ?>carrito.php">
                                <i class="fas fa-shopping-cart"></i> Carrito
                                <?php if($carrito_count > 0): ?>
                                    <span class="cart-badge"><?php echo $carrito_count; ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>auth/login.php">
                                <i class="fas fa-sign-in-alt"></i> Iniciar Sesión
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>auth/registro.php">
                                <i class="fas fa-user-plus"></i> Crear Cuenta
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container text-center position-relative">
            <h1 class="display-3 fw-bold mb-3">Bienvenido a TechZone</h1>
            <p class="lead fs-4 mb-4">Encuentra la mejor tecnología al mejor precio</p>
            
            <!-- Barra de Búsqueda -->
            <div class="row justify-content-center mb-4">
                <div class="col-md-8">
                    <form method="GET" action="" class="d-flex gap-2">
                        <div class="input-group input-group-lg">
                            <span class="input-group-text bg-white">
                                <i class="fas fa-search text-primary"></i>
                            </span>
                            <input type="text" name="buscar" class="form-control" 
                                   placeholder="Buscar productos, marcas, categorías..." 
                                   value="<?php echo htmlspecialchars($busqueda); ?>">
                        </div>
                        <button type="submit" class="btn btn-light btn-lg">
                            <i class="fas fa-search"></i> Buscar
                        </button>
                        <?php if(!empty($busqueda)): ?>
                            <a href="<?php echo BASE_URL; ?>" class="btn btn-outline-light btn-lg">
                                <i class="fas fa-times"></i> Limpiar
                            </a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            
            <div class="d-flex gap-3 justify-content-center flex-wrap">
                <a href="#productos" class="btn btn-light btn-lg">
                    <i class="fas fa-shopping-bag"></i> Ver Productos
                </a>
                <a href="<?php echo BASE_URL; ?>carrito.php" class="btn btn-outline-light btn-lg">
                    <i class="fas fa-shopping-cart"></i> Mi Carrito
                    <?php if($carrito_count > 0): ?>
                        <span class="badge bg-danger"><?php echo $carrito_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
    </div>

    <!-- Estadísticas Rápidas -->
    <div class="container mb-5">
        <div class="row g-4">
            <div class="col-md-3 col-sm-6">
                <div class="card text-center border-0 shadow-sm h-100" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                    <div class="card-body">
                        <i class="fas fa-box fa-3x mb-3 opacity-75"></i>
                        <h3 class="mb-0"><?php echo $total_disponibles; ?></h3>
                        <p class="mb-0">Productos Disponibles</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="card text-center border-0 shadow-sm h-100" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white;">
                    <div class="card-body">
                        <i class="fas fa-th-large fa-3x mb-3 opacity-75"></i>
                        <h3 class="mb-0"><?php echo count($categorias); ?></h3>
                        <p class="mb-0">Categorías</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="card text-center border-0 shadow-sm h-100" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white;">
                    <div class="card-body">
                        <i class="fas fa-tags fa-3x mb-3 opacity-75"></i>
                        <h3 class="mb-0"><?php echo count($marcas); ?></h3>
                        <p class="mb-0">Marcas</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="card text-center border-0 shadow-sm h-100" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white;">
                    <div class="card-body">
                        <i class="fas fa-shipping-fast fa-3x mb-3 opacity-75"></i>
                        <h3 class="mb-0">24h</h3>
                        <p class="mb-0">Envío Rápido</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Categorías -->
    <div class="container mb-5">
        <h2 class="section-title text-center mb-4">
            <i class="fas fa-th-large"></i> Explora por Categoría
        </h2>
        <div class="row g-4">
            <?php 
            $category_icons = [
                'Celulares' => 'fa-mobile-alt',
                'Tablets' => 'fa-tablet-alt',
                'Laptops' => 'fa-laptop',
                'Accesorios' => 'fa-headphones'
            ];
            foreach($categorias as $cat): 
                $icon = $category_icons[$cat['nombre']] ?? 'fa-box';
                $count = isset($productos_por_categoria[$cat['nombre']]) ? count($productos_por_categoria[$cat['nombre']]) : 0;
            ?>
            <div class="col-md-3 col-sm-6">
                <div class="category-card" onclick="filtrarCategoria('<?php echo $cat['nombre']; ?>')">
                    <i class="fas <?php echo $icon; ?> fa-3x mb-3 text-primary"></i>
                    <h4><?php echo htmlspecialchars($cat['nombre']); ?></h4>
                    <p class="text-muted mb-0"><?php echo $count; ?> productos</p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Productos Destacados - Carrusel -->
    <?php if(count($productos_destacados) > 0): ?>
    <div class="container mb-5">
        <h2 class="section-title mb-4">
            <i class="fas fa-star text-warning"></i> Productos Destacados
        </h2>
        <div id="carouselDestacados" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php 
                $chunks = array_chunk($productos_destacados, 4);
                foreach($chunks as $index => $chunk): 
                ?>
                <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                    <div class="row g-4">
                        <?php foreach($chunk as $prod): ?>
                        <div class="col-md-3">
                            <div class="card h-100 product-card position-relative">
                                <span class="badge-new">Destacado</span>
                                <div class="card-body d-flex flex-column">
                                    <div class="text-center mb-3">
                                        <i class="fas <?php echo $category_icons[$prod['categoria']] ?? 'fa-box'; ?> fa-4x text-primary opacity-50"></i>
                                    </div>
                                    <h5 class="card-title"><?php echo htmlspecialchars($prod['nombre']); ?></h5>
                                    <p class="text-muted small mb-2">
                                        <strong><i class="fas fa-tag"></i> Marca:</strong> <?php echo htmlspecialchars($prod['marca'] ?? 'N/A'); ?><br>
                                        <strong><i class="fas fa-layer-group"></i> Categoría:</strong> <?php echo htmlspecialchars($prod['categoria'] ?? 'N/A'); ?>
                                    </p>
                                    <div class="mt-auto">
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <span class="fs-4 fw-bold text-primary">
                                                <?php echo format_currency($prod['precio_venta']); ?>
                                            </span>
                                            <span class="badge bg-success">
                                                <i class="fas fa-check-circle"></i> <?php echo (int)$prod['stock_actual']; ?>
                                            </span>
                                        </div>
                                        <button class="btn btn-primary w-100 btn-agregar-carrito" 
                                                data-id="<?php echo $prod['id']; ?>"
                                                data-nombre="<?php echo htmlspecialchars($prod['nombre']); ?>"
                                                data-precio="<?php echo $prod['precio_venta']; ?>"
                                                data-stock="<?php echo $prod['stock_actual']; ?>">
                                            <i class="fas fa-cart-plus"></i> Agregar al Carrito
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselDestacados" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Anterior</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselDestacados" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Siguiente</span>
            </button>
        </div>
    </div>
    <?php endif; ?>

    <!-- Resultados de Búsqueda -->
    <?php if(!empty($busqueda)): ?>
    <div class="container mb-4">
        <div class="search-results">
            <h4><i class="fas fa-search"></i> Resultados de búsqueda para: "<strong><?php echo htmlspecialchars($busqueda); ?></strong>"</h4>
            <p class="mb-0">Se encontraron <strong><?php echo count($productos); ?></strong> producto(s)</p>
        </div>
    </div>
    <?php endif; ?>

    <!-- Filtros y Productos -->
    <div class="container mb-5" id="productos">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
            <h2 class="section-title mb-0">
                <i class="fas fa-boxes"></i> 
                <?php if(!empty($busqueda)): ?>
                    Resultados de Búsqueda
                <?php else: ?>
                    Todos los Productos
                <?php endif; ?>
            </h2>
            <div class="filter-buttons">
                <a href="<?php echo BASE_URL; ?>" class="filter-btn <?php echo empty($categoria_filtro) ? 'active' : ''; ?>">
                    Todos
                </a>
                <?php foreach($categorias as $cat): ?>
                <a href="?categoria=<?php echo urlencode($cat['nombre']); ?>" 
                   class="filter-btn <?php echo $categoria_filtro === $cat['nombre'] ? 'active' : ''; ?>">
                    <?php echo htmlspecialchars($cat['nombre']); ?>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- Productos por Categoría o Todos -->
        <?php if(empty($busqueda) && empty($categoria_filtro)): ?>
            <?php foreach($productos_por_categoria as $categoria_nombre => $prods): ?>
            <div class="categoria-section" data-categoria="<?php echo htmlspecialchars($categoria_nombre); ?>">
                <h3 class="mb-4">
                    <i class="fas <?php echo $category_icons[$categoria_nombre] ?? 'fa-box'; ?>"></i> 
                    <?php echo htmlspecialchars($categoria_nombre); ?>
                    <span class="badge bg-primary"><?php echo count($prods); ?></span>
                </h3>
                <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-4 g-4">
                    <?php foreach($prods as $prod): ?>
                    <div class="col">
                        <div class="card h-100 product-card position-relative">
                            <span class="badge-new">Disponible</span>
                            <div class="card-body d-flex flex-column">
                                <div class="text-center mb-3">
                                    <i class="fas <?php echo $category_icons[$prod['categoria']] ?? 'fa-box'; ?> fa-4x text-primary opacity-50"></i>
                                </div>
                                <h5 class="card-title"><?php echo htmlspecialchars($prod['nombre']); ?></h5>
                                <div class="product-info mb-2">
                                    <div class="mb-1">
                                        <i class="fas fa-tag"></i> 
                                        <strong>Marca:</strong> <?php echo htmlspecialchars($prod['marca'] ?? 'N/A'); ?>
                                    </div>
                                    <div class="mb-1">
                                        <i class="fas fa-layer-group"></i> 
                                        <strong>Categoría:</strong> <?php echo htmlspecialchars($prod['categoria'] ?? 'N/A'); ?>
                                    </div>
                                    <div class="mb-1">
                                        <i class="fas fa-barcode"></i> 
                                        <strong>Código:</strong> <?php echo htmlspecialchars($prod['codigo']); ?>
                                    </div>
                                    <?php if($prod['almacenamiento']): ?>
                                    <div class="mb-1">
                                        <i class="fas fa-hdd"></i> 
                                        <strong>Almacenamiento:</strong> <?php echo htmlspecialchars($prod['almacenamiento']); ?>
                                    </div>
                                    <?php endif; ?>
                                    <?php if($prod['memoria_ram']): ?>
                                    <div class="mb-1">
                                        <i class="fas fa-memory"></i> 
                                        <strong>RAM:</strong> <?php echo htmlspecialchars($prod['memoria_ram']); ?>
                                    </div>
                                    <?php endif; ?>
                                    <?php if($prod['color']): ?>
                                    <div class="mb-1">
                                        <i class="fas fa-palette"></i> 
                                        <strong>Color:</strong> <?php echo htmlspecialchars($prod['color']); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <?php if($prod['descripcion']): ?>
                                    <p class="card-text small text-muted flex-grow-1">
                                        <?php echo htmlspecialchars(substr($prod['descripcion'], 0, 80)); ?>...
                                    </p>
                                <?php endif; ?>
                                <div class="mt-auto">
                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                        <span class="fs-4 fw-bold text-primary">
                                            <?php echo format_currency($prod['precio_venta']); ?>
                                        </span>
                                        <span class="badge bg-success">
                                            <i class="fas fa-check-circle"></i> <?php echo (int)$prod['stock_actual']; ?>
                                        </span>
                                    </div>
                                    <button class="btn btn-primary w-100 btn-agregar-carrito" 
                                            data-id="<?php echo $prod['id']; ?>"
                                            data-nombre="<?php echo htmlspecialchars($prod['nombre']); ?>"
                                            data-precio="<?php echo $prod['precio_venta']; ?>"
                                            data-stock="<?php echo $prod['stock_actual']; ?>">
                                        <i class="fas fa-cart-plus"></i> Agregar al Carrito
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <!-- Mostrar todos los productos filtrados -->
            <?php if(count($productos) > 0): ?>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-4 g-4">
                <?php foreach($productos as $prod): ?>
                <div class="col">
                    <div class="card h-100 product-card position-relative">
                        <span class="badge-new">Disponible</span>
                        <div class="card-body d-flex flex-column">
                            <div class="text-center mb-3">
                                <i class="fas <?php echo $category_icons[$prod['categoria']] ?? 'fa-box'; ?> fa-4x text-primary opacity-50"></i>
                            </div>
                            <h5 class="card-title"><?php echo htmlspecialchars($prod['nombre']); ?></h5>
                            <div class="product-info mb-2">
                                <div class="mb-1">
                                    <i class="fas fa-tag"></i> 
                                    <strong>Marca:</strong> <?php echo htmlspecialchars($prod['marca'] ?? 'N/A'); ?>
                                </div>
                                <div class="mb-1">
                                    <i class="fas fa-layer-group"></i> 
                                    <strong>Categoría:</strong> <?php echo htmlspecialchars($prod['categoria'] ?? 'N/A'); ?>
                                </div>
                                <div class="mb-1">
                                    <i class="fas fa-barcode"></i> 
                                    <strong>Código:</strong> <?php echo htmlspecialchars($prod['codigo']); ?>
                                </div>
                                <?php if($prod['almacenamiento']): ?>
                                <div class="mb-1">
                                    <i class="fas fa-hdd"></i> 
                                    <strong>Almacenamiento:</strong> <?php echo htmlspecialchars($prod['almacenamiento']); ?>
                                </div>
                                <?php endif; ?>
                                <?php if($prod['memoria_ram']): ?>
                                <div class="mb-1">
                                    <i class="fas fa-memory"></i> 
                                    <strong>RAM:</strong> <?php echo htmlspecialchars($prod['memoria_ram']); ?>
                                </div>
                                <?php endif; ?>
                                <?php if($prod['color']): ?>
                                <div class="mb-1">
                                    <i class="fas fa-palette"></i> 
                                    <strong>Color:</strong> <?php echo htmlspecialchars($prod['color']); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php if($prod['descripcion']): ?>
                                <p class="card-text small text-muted flex-grow-1">
                                    <?php echo htmlspecialchars(substr($prod['descripcion'], 0, 80)); ?>...
                                </p>
                            <?php endif; ?>
                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <span class="fs-4 fw-bold text-primary">
                                        <?php echo format_currency($prod['precio_venta']); ?>
                                    </span>
                                    <span class="badge bg-success">
                                        <i class="fas fa-check-circle"></i> <?php echo (int)$prod['stock_actual']; ?>
                                    </span>
                                </div>
                                <button class="btn btn-primary w-100 btn-agregar-carrito" 
                                        data-id="<?php echo $prod['id']; ?>"
                                        data-nombre="<?php echo htmlspecialchars($prod['nombre']); ?>"
                                        data-precio="<?php echo $prod['precio_venta']; ?>"
                                        data-stock="<?php echo $prod['stock_actual']; ?>">
                                    <i class="fas fa-cart-plus"></i> Agregar al Carrito
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="alert alert-info text-center py-5">
                <i class="fas fa-search fa-3x mb-3"></i>
                <h4>No se encontraron productos</h4>
                <p>Intenta con otros términos de búsqueda o <a href="<?php echo BASE_URL; ?>">ver todos los productos</a></p>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-4 mt-5">
        <div class="container">
            <p class="mb-0">&copy; <?php echo date('Y'); ?> TechZone. Todos los derechos reservados.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/main.js"></script>
    <script>
        // Función para filtrar por categoría
        function filtrarCategoria(categoria) {
            // Actualizar botones activos
            document.querySelectorAll('.filter-btn').forEach(btn => {
                btn.classList.remove('active');
                if(btn.textContent.trim() === categoria || (categoria === 'Todos' && btn.textContent.trim() === 'Todos')) {
                    btn.classList.add('active');
                }
            });
            
            // Actualizar cards de categoría
            document.querySelectorAll('.category-card').forEach(card => {
                card.classList.remove('active');
            });
            
            // Mostrar/ocultar secciones
            document.querySelectorAll('.categoria-section').forEach(section => {
                if(categoria === 'Todos') {
                    section.style.display = 'block';
                    setTimeout(() => {
                        section.style.opacity = '1';
                        section.style.transform = 'translateY(0)';
                    }, 10);
                } else {
                    const sectionCategoria = section.getAttribute('data-categoria');
                    if(sectionCategoria === categoria) {
                        section.style.display = 'block';
                        section.style.opacity = '1';
                        section.style.transform = 'translateY(0)';
                    } else {
                        section.style.opacity = '0';
                        section.style.transform = 'translateY(20px)';
                        setTimeout(() => {
                            section.style.display = 'none';
                        }, 300);
                    }
                }
            });
            
            // Scroll suave a productos
            if(categoria !== 'Todos') {
                document.getElementById('productos').scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        }
        
        // Inicializar animaciones
        document.addEventListener('DOMContentLoaded', function() {
            // Animación de entrada para productos
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if(entry.isIntersecting) {
                        entry.target.style.animationPlayState = 'running';
                    }
                });
            });
            
            document.querySelectorAll('.product-card').forEach(card => {
                observer.observe(card);
            });
        });
        
        // Agregar al carrito
        document.querySelectorAll('.btn-agregar-carrito').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const nombre = this.getAttribute('data-nombre');
                const precio = parseFloat(this.getAttribute('data-precio'));
                const stock = parseInt(this.getAttribute('data-stock'));

                fetch('<?php echo BASE_URL; ?>ajax/agregar-carrito.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        id_producto: id,
                        cantidad: 1
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        // Actualizar badge del carrito - buscar en todos los posibles lugares
                        const cartBadges = document.querySelectorAll('.cart-badge');
                        const cartBadgeNav = document.getElementById('cart-badge-nav');
                        
                        // Actualizar todos los badges existentes
                        cartBadges.forEach(badge => {
                            badge.textContent = data.carrito_count;
                        });
                        
                        // Si existe el badge del navbar, actualizarlo
                        if(cartBadgeNav) {
                            cartBadgeNav.textContent = data.carrito_count;
                        }
                        
                        // Si no existe ningún badge, crear uno
                        if(cartBadges.length === 0 && !cartBadgeNav) {
                            const cartLinks = document.querySelectorAll('.btn-cart');
                            cartLinks.forEach(cartLink => {
                                if(!cartLink.querySelector('.cart-badge')) {
                                    const badge = document.createElement('span');
                                    badge.className = 'cart-badge';
                                    badge.id = 'cart-badge-nav';
                                    badge.textContent = data.carrito_count;
                                    cartLink.appendChild(badge);
                                }
                            });
                        }
                        
                        // Mostrar mensaje de éxito
                        alert('✓ Producto agregado al carrito: ' + nombre + '\n\nTotal en carrito: ' + data.carrito_count + ' producto(s)');
                        
                        // Actualizar página si es necesario
                        if(data.redirect) {
                            window.location.href = data.redirect;
                        }
                    } else {
                        alert('✗ Error: ' + (data.message || 'No se pudo agregar el producto'));
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al agregar producto al carrito');
                });
            });
        });
    </script>
</body>
</html>
