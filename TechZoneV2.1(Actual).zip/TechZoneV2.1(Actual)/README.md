# TechZone

Sistema de gestión para tienda de tecnología.

## Requisitos

- XAMPP (Apache y MySQL)
- Navegador web

## Pasos para abrir el proyecto

### 1. Iniciar XAMPP

1. Abre el **Panel de Control de XAMPP**
2. Inicia los servicios:
   - **Apache** (clic en "Start")
   - **MySQL** (clic en "Start")

### 2. Importar la base de datos

1. Abre **phpMyAdmin** en tu navegador:
   - Ve a: `http://localhost/phpmyadmin`
2. Crea la base de datos:
   - Clic en "Nueva" (New) en el menú lateral
   - O importa directamente el archivo SQL
3. Importa el archivo SQL:
   - Selecciona la base de datos `techzone` (o créala primero)
   - Ve a la pestaña "Importar" (Import)
   - Selecciona el archivo: `sql/techzone_completo.sql`
   - Clic en "Continuar" (Go)

**Alternativa desde la línea de comandos:**
```bash
mysql -u root -p < sql/techzone_completo.sql
```

### 3. Verificar la configuración

El archivo `config/constants.php` ya está configurado con:
- Base de datos: `techzone`
- Usuario: `root`
- Contraseña: (vacía, por defecto de XAMPP)
- Host: `localhost`

Si necesitas cambiar estas configuraciones, edita `config/constants.php`.

### 4. Abrir el proyecto en el navegador

Abre tu navegador y ve a:
```
http://localhost/techzone/
```

O directamente al login:
```
http://localhost/techzone/auth/login.php
```

## Estructura del proyecto

- `auth/` - Autenticación (login, registro)
- `config/` - Configuración (base de datos, constantes)
- `modules/` - Módulos del sistema (clientes, productos, ventas, etc.)
- `ajax/` - Endpoints AJAX
- `assets/` - CSS y JavaScript
- `includes/` - Archivos reutilizables (header, footer, navbar)
- `sql/` - Scripts de base de datos

## Configurar Usuarios del Sistema

Después de importar la base de datos, ejecuta el script para configurar las contraseñas:

1. Abre en tu navegador: `http://localhost/techzone/install-passwords.php`
2. O ejecuta desde la línea de comandos: `php install-passwords.php`

Esto configurará los siguientes usuarios:

- **Admin**: `admin@gmail.com` / `admin`
- **Vendedor**: `vendedor@gmail.com` / `vendedor`

## Características del Sistema

### Página Principal
- Muestra todos los productos disponibles (sin fotos)
- Opciones de "Crear Cuenta" e "Iniciar Sesión" en el navbar
- Botón de carrito en cada producto para agregar al carrito
- Contador de productos en el carrito

### Carrito de Compras
- Ver productos agregados
- Modificar cantidades
- Eliminar productos
- Calcular totales (Subtotal, IVA 12%, Total)
- Procesar compra (requiere iniciar sesión)

### Panel de Administración
- Acceso con `admin@gmail.com` / `admin`
- Gestión completa del sistema

### Panel de Vendedor
- Acceso con `vendedor@gmail.com` / `vendedor`
- Gestión de ventas y clientes

## Notas

- Asegúrate de que Apache y MySQL estén corriendo en XAMPP
- Si tienes problemas de conexión, verifica que MySQL esté activo
- El proyecto está configurado para ejecutarse en `http://localhost/techzone/`
- El carrito se guarda en la sesión PHP (se pierde al cerrar el navegador)