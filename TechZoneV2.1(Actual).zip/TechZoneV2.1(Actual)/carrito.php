<?php
require_once 'config/constants.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Inicializar carrito si no existe
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

// Procesar acciones del carrito
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['accion'])) {
        switch ($_POST['accion']) {
            case 'actualizar':
                if (isset($_POST['id_producto']) && isset($_POST['cantidad'])) {
                    $id_producto = (int)$_POST['id_producto'];
                    $cantidad = (int)$_POST['cantidad'];
                    
                    // Verificar stock
                    $pdo = db_connect();
                    $stmt = $pdo->prepare("SELECT stock_actual, precio_venta FROM productos WHERE id = ? AND activo = 1");
                    $stmt->execute([$id_producto]);
                    $producto = $stmt->fetch();
                    
                    if ($producto && $cantidad > 0 && $cantidad <= $producto['stock_actual']) {
                        foreach ($_SESSION['carrito'] as $key => $item) {
                            if ($item['id_producto'] == $id_producto) {
                                $_SESSION['carrito'][$key]['cantidad'] = $cantidad;
                                $_SESSION['carrito'][$key]['subtotal'] = $cantidad * $producto['precio_venta'];
                                break;
                            }
                        }
                    }
                }
                break;
                
            case 'eliminar':
                if (isset($_POST['id_producto'])) {
                    $id_producto = (int)$_POST['id_producto'];
                    foreach ($_SESSION['carrito'] as $key => $item) {
                        if ($item['id_producto'] == $id_producto) {
                            unset($_SESSION['carrito'][$key]);
                            $_SESSION['carrito'] = array_values($_SESSION['carrito']); // Reindexar
                            break;
                        }
                    }
                }
                break;
                
            case 'vaciar':
                $_SESSION['carrito'] = [];
                break;
                
            case 'comprar':
                // Verificar si hay sesión de usuario
                if (!isset($_SESSION['user_id'])) {
                    $_SESSION['error_carrito'] = 'Debes iniciar sesión para realizar una compra';
                    header('Location: ' . BASE_URL . 'auth/login.php');
                    exit;
                }
                
                // Redirigir al proceso de venta
                header('Location: ' . BASE_URL . 'modules/ventas/procesar-venta-carrito.php');
                exit;
        }
    }
    header('Location: ' . BASE_URL . 'carrito.php');
    exit;
}

// Calcular totales
$subtotal = 0;
$iva = 0;
$total = 0;

foreach ($_SESSION['carrito'] as $item) {
    $subtotal += $item['subtotal'];
}

$iva = $subtotal * 0.12; // IVA 12%
$total = $subtotal + $iva;

$carrito_count = count($_SESSION['carrito']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compras - TechZone</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
    <style>
        .navbar-public {
            background: linear-gradient(90deg, #4e73df 0%, #224abe 100%) !important;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .cart-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #dc3545;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .btn-cart {
            position: relative;
        }
        .modal-content {
            border-radius: 15px;
            border: none;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        .modal-header {
            border-radius: 15px 15px 0 0;
        }
        .form-control:focus, .form-select:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-public">
        <div class="container">
            <a class="navbar-brand" href="<?php echo BASE_URL; ?>">
                <i class="fas fa-microchip"></i> TechZone
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_URL; ?>">
                            <i class="fas fa-home"></i> Inicio
                        </a>
                    </li>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <?php if($_SESSION['rol_id'] != 4): // Solo mostrar Panel si NO es cliente ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> Panel
                            </a>
                        </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <span class="navbar-text me-3 text-white">
                                <?php echo htmlspecialchars($_SESSION['nombre']); ?>
                            </span>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>auth/logout.php">
                                <i class="fas fa-sign-out-alt"></i> Salir
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>auth/login.php">
                                <i class="fas fa-sign-in-alt"></i> Iniciar Sesión
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>auth/registro.php">
                                <i class="fas fa-user-plus"></i> Crear Cuenta
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <h2 class="mb-4"><i class="fas fa-shopping-cart"></i> Carrito de Compras</h2>

        <?php if(isset($_SESSION['error_carrito'])): ?>
            <div class="alert alert-danger">
                <?php echo $_SESSION['error_carrito']; unset($_SESSION['error_carrito']); ?>
            </div>
        <?php endif; ?>

        <?php if(isset($_SESSION['success_carrito'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success_carrito']; unset($_SESSION['success_carrito']); ?>
            </div>
        <?php endif; ?>

        <?php if(count($_SESSION['carrito']) == 0): ?>
            <div class="alert alert-info text-center">
                <i class="fas fa-shopping-cart fa-3x mb-3"></i>
                <h4>Tu carrito está vacío</h4>
                <p>Agrega productos desde la página principal</p>
                <a href="<?php echo BASE_URL; ?>" class="btn btn-primary">
                    <i class="fas fa-arrow-left"></i> Volver a la Tienda
                </a>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Producto</th>
                                        <th>Precio</th>
                                        <th>Cantidad</th>
                                        <th>Subtotal</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($_SESSION['carrito'] as $item): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['nombre']); ?></td>
                                        <td><?php echo format_currency($item['precio']); ?></td>
                                        <td>
                                            <form method="POST" class="d-inline">
                                                <input type="hidden" name="accion" value="actualizar">
                                                <input type="hidden" name="id_producto" value="<?php echo $item['id_producto']; ?>">
                                                <input type="number" name="cantidad" value="<?php echo $item['cantidad']; ?>" 
                                                       min="1" max="99" class="form-control form-control-sm" style="width: 80px; display: inline-block;"
                                                       onchange="this.form.submit()">
                                            </form>
                                        </td>
                                        <td><?php echo format_currency($item['subtotal']); ?></td>
                                        <td>
                                            <form method="POST" class="d-inline" onsubmit="return confirm('¿Eliminar este producto del carrito?');">
                                                <input type="hidden" name="accion" value="eliminar">
                                                <input type="hidden" name="id_producto" value="<?php echo $item['id_producto']; ?>">
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            <form method="POST" onsubmit="return confirm('¿Vaciar todo el carrito?');">
                                <input type="hidden" name="accion" value="vaciar">
                                <button type="submit" class="btn btn-outline-danger">
                                    <i class="fas fa-trash-alt"></i> Vaciar Carrito
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">Resumen de Compra</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-borderless">
                                <tr>
                                    <td>Subtotal:</td>
                                    <td class="text-end"><?php echo format_currency($subtotal); ?></td>
                                </tr>
                                <tr>
                                    <td>IVA (12%):</td>
                                    <td class="text-end"><?php echo format_currency($iva); ?></td>
                                </tr>
                                <tr class="border-top">
                                    <td><strong>Total:</strong></td>
                                    <td class="text-end"><strong><?php echo format_currency($total); ?></strong></td>
                                </tr>
                            </table>
                            <?php if(isset($_SESSION['user_id'])): ?>
                                <button type="button" class="btn btn-success w-100 btn-lg" data-bs-toggle="modal" data-bs-target="#modalPago">
                                    <i class="fas fa-credit-card"></i> Proceder a Comprar
                                </button>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle"></i> 
                                    Debes <a href="<?php echo BASE_URL; ?>auth/login.php">iniciar sesión</a> 
                                    o <a href="<?php echo BASE_URL; ?>auth/registro.php">crear una cuenta</a> para comprar.
                                </div>
                                <a href="<?php echo BASE_URL; ?>auth/login.php" class="btn btn-primary w-100">
                                    <i class="fas fa-sign-in-alt"></i> Iniciar Sesión
                                </a>
                            <?php endif; ?>
                            <a href="<?php echo BASE_URL; ?>" class="btn btn-outline-secondary w-100 mt-2">
                                <i class="fas fa-arrow-left"></i> Seguir Comprando
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Modal de Pago -->
    <?php if(isset($_SESSION['user_id'])): ?>
    <div class="modal fade" id="modalPago" tabindex="-1" aria-labelledby="modalPagoLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalPagoLabel">
                        <i class="fas fa-credit-card"></i> Datos de Pago
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="formPago" method="POST" action="<?php echo BASE_URL; ?>modules/ventas/procesar-venta-carrito.php">
                    <div class="modal-body">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> 
                            <strong>Total a pagar:</strong> <?php echo format_currency($total); ?>
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><i class="fas fa-credit-card"></i> Método de Pago</label>
                            <select name="metodo_pago" class="form-select" id="metodoPago" required>
                                <option value="">Seleccione un método</option>
                                <option value="Tarjeta de Crédito">Tarjeta de Crédito</option>
                                <option value="Tarjeta de Débito">Tarjeta de Débito</option>
                                <option value="Efectivo">Efectivo</option>
                                <option value="Transferencia">Transferencia</option>
                            </select>
                        </div>

                        <div id="datosTarjeta" style="display: none;">
                            <hr>
                            <h6 class="mb-3"><i class="fas fa-lock"></i> Información de la Tarjeta</h6>
                            
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="form-label">Nombre en la Tarjeta</label>
                                    <input type="text" name="nombre_tarjeta" class="form-control" 
                                           placeholder="Ej: JUAN PEREZ" maxlength="50" id="nombreTarjeta">
                                </div>
                                
                                <div class="col-md-12 mb-3">
                                    <label class="form-label">Número de Tarjeta</label>
                                    <input type="text" name="numero_tarjeta" class="form-control" 
                                           placeholder="1234 5678 9012 3456" maxlength="19" 
                                           id="numeroTarjeta" pattern="[0-9\s]{13,19}">
                                    <small class="text-muted">Ingrese solo números (sin espacios)</small>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Fecha de Vencimiento</label>
                                    <input type="text" name="fecha_vencimiento" class="form-control" 
                                           placeholder="MM/AA" maxlength="5" id="fechaVencimiento" 
                                           pattern="[0-9]{2}/[0-9]{2}">
                                    <small class="text-muted">Formato: MM/AA</small>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">CVV</label>
                                    <input type="text" name="cvv" class="form-control" 
                                           placeholder="123" maxlength="4" id="cvv" 
                                           pattern="[0-9]{3,4}">
                                    <small class="text-muted">3 o 4 dígitos</small>
                                </div>
                            </div>
                        </div>

                        <div id="datosEfectivo" style="display: none;">
                            <hr>
                            <div class="alert alert-warning">
                                <i class="fas fa-money-bill-wave"></i> 
                                <strong>Pago en Efectivo:</strong> El pago se completará al momento de la entrega.
                            </div>
                        </div>

                        <div id="datosTransferencia" style="display: none;">
                            <hr>
                            <div class="alert alert-info">
                                <i class="fas fa-exchange-alt"></i> 
                                <strong>Transferencia Bancaria:</strong> 
                                <p class="mb-0 mt-2">
                                    <strong>Banco:</strong> Banco Ejemplo<br>
                                    <strong>Cuenta:</strong> 1234567890<br>
                                    <strong>CCI:</strong> 12345678901234567890
                                </p>
                                <p class="mb-0 mt-2">Envíe el comprobante a: ventas@techzone.com</p>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="fas fa-times"></i> Cancelar
                        </button>
                        <button type="submit" class="btn btn-success" id="btnConfirmarPago">
                            <i class="fas fa-check"></i> Confirmar Pago
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Formatear número de tarjeta
        document.getElementById('numeroTarjeta')?.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\s/g, '');
            let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
            e.target.value = formattedValue;
        });

        // Formatear fecha de vencimiento
        document.getElementById('fechaVencimiento')?.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length >= 2) {
                value = value.substring(0, 2) + '/' + value.substring(2, 4);
            }
            e.target.value = value;
        });

        // Solo números para CVV
        document.getElementById('cvv')?.addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/\D/g, '');
        });

        // Mostrar/ocultar campos según método de pago
        const metodoPago = document.getElementById('metodoPago');
        const datosTarjeta = document.getElementById('datosTarjeta');
        const datosEfectivo = document.getElementById('datosEfectivo');
        const datosTransferencia = document.getElementById('datosTransferencia');
        const formPago = document.getElementById('formPago');
        const nombreTarjeta = document.getElementById('nombreTarjeta');
        const numeroTarjeta = document.getElementById('numeroTarjeta');
        const fechaVencimiento = document.getElementById('fechaVencimiento');
        const cvv = document.getElementById('cvv');

        metodoPago?.addEventListener('change', function() {
            const metodo = this.value;
            
            // Ocultar todos
            datosTarjeta.style.display = 'none';
            datosEfectivo.style.display = 'none';
            datosTransferencia.style.display = 'none';
            
            // Hacer campos opcionales
            nombreTarjeta?.removeAttribute('required');
            numeroTarjeta?.removeAttribute('required');
            fechaVencimiento?.removeAttribute('required');
            cvv?.removeAttribute('required');
            
            // Mostrar según método
            if (metodo === 'Tarjeta de Crédito' || metodo === 'Tarjeta de Débito') {
                datosTarjeta.style.display = 'block';
                nombreTarjeta?.setAttribute('required', 'required');
                numeroTarjeta?.setAttribute('required', 'required');
                fechaVencimiento?.setAttribute('required', 'required');
                cvv?.setAttribute('required', 'required');
            } else if (metodo === 'Efectivo') {
                datosEfectivo.style.display = 'block';
            } else if (metodo === 'Transferencia') {
                datosTransferencia.style.display = 'block';
            }
        });

        // Validar formulario antes de enviar
        formPago?.addEventListener('submit', function(e) {
            const metodo = metodoPago.value;
            
            if (!metodo) {
                e.preventDefault();
                alert('Por favor seleccione un método de pago');
                return false;
            }
            
            // Validar datos de tarjeta si es necesario
            if (metodo === 'Tarjeta de Crédito' || metodo === 'Tarjeta de Débito') {
                const numero = numeroTarjeta.value.replace(/\s/g, '');
                const fecha = fechaVencimiento.value;
                const cvvValue = cvv.value;
                
                if (numero.length < 13 || numero.length > 19) {
                    e.preventDefault();
                    alert('El número de tarjeta debe tener entre 13 y 19 dígitos');
                    return false;
                }
                
                if (!/^\d{2}\/\d{2}$/.test(fecha)) {
                    e.preventDefault();
                    alert('La fecha de vencimiento debe tener el formato MM/AA');
                    return false;
                }
                
                if (cvvValue.length < 3 || cvvValue.length > 4) {
                    e.preventDefault();
                    alert('El CVV debe tener 3 o 4 dígitos');
                    return false;
                }
            }
            
            // Confirmar pago
            if (!confirm('¿Confirmar el pago de <?php echo format_currency($total); ?>?')) {
                e.preventDefault();
                return false;
            }
        });
    </script>
</body>
</html>

