<?php
require_once '../../includes/functions.php';
check_permission([1]); // Admin Only for delete

$id = $_GET['id'] ?? 0;
$pdo = db_connect();

// Check dependencies (sales)
$stmt = $pdo->prepare("SELECT COUNT(*) FROM ventas WHERE id_cliente = ?");
$stmt->execute([$id]);
if($stmt->fetchColumn() > 0) {
    echo "<script>alert('No se puede eliminar el cliente porque tiene ventas asociadas.'); window.location='index.php';</script>";
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM clientes WHERE id = ?");
$stmt->execute([$id]);
$c = $stmt->fetch();

if($c) {
    // Hard delete is allowed for clients without sales, or we could soft delete if table had 'activo' column (it doesn't in initial SQL)
    // SQL shows table clientes does NOT have 'activo'. So we do DELETE.
    // Trigger will log it.

    $stmt = $pdo->prepare("DELETE FROM clientes WHERE id = ?");
    $stmt->execute([$id]);

    header('Location: index.php?msg=deleted');
}
exit;
