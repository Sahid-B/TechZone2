<?php
require_once '../../includes/functions.php';
check_permission([1]); // Admin
include_once '../../includes/header.php';
$pdo = db_connect();

// Obtener usuarios con información de roles
$usuarios = $pdo->query("SELECT u.*, r.nombre as rol FROM usuarios u JOIN roles r ON u.rol_id = r.id ORDER BY u.fecha_creacion DESC")->fetchAll();

// Estadísticas
$total_usuarios = count($usuarios);
$usuarios_activos = count(array_filter($usuarios, function($u) { return $u['activo'] == 1; }));
$usuarios_por_rol = [];
foreach($usuarios as $u) {
    $rol = $u['rol'];
    $usuarios_por_rol[$rol] = ($usuarios_por_rol[$rol] ?? 0) + 1;
}
?>

<style>
    .stats-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 15px;
        padding: 25px;
        margin-bottom: 20px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        transition: transform 0.3s ease;
    }
    .stats-card:hover {
        transform: translateY(-5px);
    }
    .stats-card h3 {
        font-size: 2.5rem;
        font-weight: bold;
        margin: 0;
    }
    .user-card {
        border: none;
        border-radius: 15px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        transition: all 0.3s ease;
        margin-bottom: 20px;
    }
    .user-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 20px rgba(0,0,0,0.15);
    }
    .user-avatar {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 24px;
        font-weight: bold;
        margin-right: 15px;
    }
    .role-badge {
        padding: 5px 15px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 500;
    }
    .breadcrumb-custom {
        background: transparent;
        padding: 0;
        margin-bottom: 20px;
    }
    .breadcrumb-custom .breadcrumb-item a {
        color: #667eea;
        text-decoration: none;
    }
    .breadcrumb-custom .breadcrumb-item.active {
        color: #6c757d;
    }
</style>

<!-- Breadcrumb -->
<nav aria-label="breadcrumb" class="breadcrumb-custom">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>index.php"><i class="fas fa-home"></i> Inicio</a></li>
        <li class="breadcrumb-item active">Gestión de Usuarios</li>
    </ol>
</nav>

<!-- Header -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="mb-1"><i class="fas fa-users text-primary"></i> Gestión de Usuarios</h2>
        <p class="text-muted mb-0">Administra los usuarios del sistema</p>
    </div>
    <a href="crear.php" class="btn btn-primary btn-lg">
        <i class="fas fa-user-plus"></i> Nuevo Usuario
    </a>
</div>

<?php if(isset($_GET['msg']) && $_GET['msg'] == 'deleted'): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fas fa-check-circle"></i> Usuario eliminado correctamente
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if(isset($_SESSION['success_message'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Estadísticas -->
<div class="row mb-4">
    <div class="col-md-4">
        <div class="stats-card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <p class="mb-1">Total Usuarios</p>
                    <h3><?php echo $total_usuarios; ?></h3>
                </div>
                <i class="fas fa-users fa-3x opacity-75"></i>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stats-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <p class="mb-1">Usuarios Activos</p>
                    <h3><?php echo $usuarios_activos; ?></h3>
                </div>
                <i class="fas fa-user-check fa-3x opacity-75"></i>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stats-card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <p class="mb-1">Roles Diferentes</p>
                    <h3><?php echo count($usuarios_por_rol); ?></h3>
                </div>
                <i class="fas fa-user-tag fa-3x opacity-75"></i>
            </div>
        </div>
    </div>
</div>

<!-- Lista de Usuarios -->
<?php if(count($usuarios) > 0): ?>
<div class="row">
    <?php foreach($usuarios as $u): 
        $inicial = strtoupper(substr($u['nombre'], 0, 1));
        $rol_colors = [
            'Administrador' => 'bg-danger',
            'Vendedor' => 'bg-success',
            'Almacenista' => 'bg-info'
        ];
        $rol_color = $rol_colors[$u['rol']] ?? 'bg-secondary';
    ?>
    <div class="col-md-6 col-lg-4">
        <div class="card user-card">
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <div class="user-avatar">
                        <?php echo $inicial; ?>
                    </div>
                    <div class="flex-grow-1">
                        <h5 class="mb-1"><?php echo htmlspecialchars($u['nombre']); ?></h5>
                        <p class="text-muted mb-0 small">
                            <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($u['email']); ?>
                        </p>
                    </div>
                </div>
                
                <div class="mb-3">
                    <span class="role-badge <?php echo $rol_color; ?> text-white">
                        <i class="fas fa-user-tag"></i> <?php echo htmlspecialchars($u['rol']); ?>
                    </span>
                    <?php if($u['activo']): ?>
                        <span class="badge bg-success ms-2">
                            <i class="fas fa-check-circle"></i> Activo
                        </span>
                    <?php else: ?>
                        <span class="badge bg-secondary ms-2">
                            <i class="fas fa-times-circle"></i> Inactivo
                        </span>
                    <?php endif; ?>
                </div>
                
                <div class="text-muted small mb-3">
                    <i class="fas fa-calendar"></i> Creado: <?php echo date('d/m/Y', strtotime($u['fecha_creacion'])); ?>
                </div>
                
                <div class="d-flex gap-2">
                    <a href="editar.php?id=<?php echo $u['id']; ?>" class="btn btn-sm btn-warning flex-fill">
                        <i class="fas fa-edit"></i> Editar
                    </a>
                    <a href="eliminar.php?id=<?php echo $u['id']; ?>" 
                       class="btn btn-sm btn-danger flex-fill" 
                       onclick="return confirm('¿Estás seguro de eliminar a <?php echo htmlspecialchars($u['nombre']); ?>?');">
                        <i class="fas fa-trash"></i> Eliminar
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php else: ?>
<div class="alert alert-info text-center py-5">
    <i class="fas fa-users fa-3x mb-3 text-muted"></i>
    <h4>No hay usuarios registrados</h4>
    <p class="text-muted">Comienza creando tu primer usuario</p>
    <a href="crear.php" class="btn btn-primary">
        <i class="fas fa-user-plus"></i> Crear Usuario
    </a>
</div>
<?php endif; ?>

<?php include_once '../../includes/footer.php'; ?>
