<?php
require_once '../../includes/functions.php';
check_permission([1, 3]);

include_once '../../includes/header.php';
$pdo = db_connect();

$marcas = $pdo->query("SELECT * FROM marcas")->fetchAll();
$categorias = $pdo->query("SELECT * FROM categorias_producto")->fetchAll();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect Data
    $codigo = $_POST['codigo'];
    $nombre = $_POST['nombre'];
    $desc = $_POST['descripcion'];
    $marca = $_POST['marca_id'];
    $cat = $_POST['categoria_id'];
    $p_compra = $_POST['precio_compra'];
    $p_venta = $_POST['precio_venta'];
    $stock = $_POST['stock'];
    $min = $_POST['stock_minimo'];

    // Tech Details
    $imei = $_POST['imei'] ?? NULL;
    $serie = $_POST['numero_serie'] ?? NULL;
    $modelo = $_POST['modelo'] ?? NULL;
    $color = $_POST['color'] ?? NULL;
    $almacenamiento = $_POST['almacenamiento'] ?? NULL;
    $ram = $_POST['ram'] ?? NULL;
    $garantia = $_POST['garantia'] ?? 12;
    $estado = $_POST['estado'] ?? 'Nuevo';

    // Image Upload
    $ruta_imagen = null;
    if(isset($_FILES['imagen']) && $_FILES['imagen']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];
        $filename = $_FILES['imagen']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if(in_array($ext, $allowed)) {
            $new_name = uniqid('prod_') . '.' . $ext;
            $dest = '../../assets/img/productos/' . $new_name;
            if(move_uploaded_file($_FILES['imagen']['tmp_name'], $dest)) {
                $ruta_imagen = 'assets/img/productos/' . $new_name;
            }
        }
    }

    try {
        // Use the Stored Procedure
        $stmt = $pdo->prepare("CALL sp_registrar_producto(:cod, :nom, :desc, :mar, :cat, :pc, :pv, :stk, :stkmin, :imei, :serie, :mod, :col, :alm, :ram, :gar, :est, :img)");
        $stmt->execute([
            ':cod' => $codigo,
            ':nom' => $nombre,
            ':desc' => $desc,
            ':mar' => $marca,
            ':cat' => $cat,
            ':pc' => $p_compra,
            ':pv' => $p_venta,
            ':stk' => $stock,
            ':stkmin' => $min,
            ':imei' => $imei,
            ':serie' => $serie,
            ':mod' => $modelo,
            ':col' => $color,
            ':alm' => $almacenamiento,
            ':ram' => $ram,
            ':gar' => $garantia,
            ':est' => $estado,
            ':img' => $ruta_imagen
        ]);

        echo "<div class='alert alert-success'>Producto creado correctamente</div>";
    } catch(Exception $e) {
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}
?>

<h3>Nuevo Producto</h3>
<form method="POST" enctype="multipart/form-data" class="row g-3">
    <div class="col-md-6">
        <label>Código</label>
        <input type="text" name="codigo" class="form-control" required>
    </div>
    <div class="col-md-6">
        <label>Nombre</label>
        <input type="text" name="nombre" class="form-control" required>
    </div>
    <div class="col-12">
        <label>Descripción</label>
        <textarea name="descripcion" class="form-control"></textarea>
    </div>
    <div class="col-md-4">
        <label>Marca</label>
        <select name="marca_id" class="form-select">
            <?php foreach($marcas as $m) echo "<option value='{$m['id']}'>{$m['nombre']}</option>"; ?>
        </select>
    </div>
    <div class="col-md-4">
        <label>Categoría</label>
        <select name="categoria_id" class="form-select">
            <?php foreach($categorias as $c) echo "<option value='{$c['id']}'>{$c['nombre']}</option>"; ?>
        </select>
    </div>
    <div class="col-md-4">
        <label>Stock Inicial</label>
        <input type="number" name="stock" class="form-control" value="0">
    </div>
    <div class="col-md-4">
        <label>Precio Compra</label>
        <input type="number" step="0.01" name="precio_compra" class="form-control" required>
    </div>
    <div class="col-md-4">
        <label>Precio Venta</label>
        <input type="number" step="0.01" name="precio_venta" class="form-control" required>
    </div>
    <div class="col-md-4">
        <label>Stock Mínimo</label>
        <input type="number" name="stock_minimo" class="form-control" value="5">
    </div>

    <!-- Specs -->
    <div class="col-md-4">
        <label>Modelo</label>
        <input type="text" name="modelo" class="form-control">
    </div>
    <div class="col-md-4">
        <label>Color</label>
        <input type="text" name="color" class="form-control">
    </div>
    <div class="col-md-4">
        <label>Almacenamiento</label>
        <select name="almacenamiento" class="form-select">
            <option value="">N/A</option>
            <option value="64GB">64GB</option>
            <option value="128GB">128GB</option>
            <option value="256GB">256GB</option>
            <option value="512GB">512GB</option>
            <option value="1TB">1TB</option>
        </select>
    </div>
    <div class="col-md-4">
        <label>RAM</label>
        <select name="ram" class="form-select">
             <option value="">N/A</option>
             <option value="4GB">4GB</option>
             <option value="8GB">8GB</option>
             <option value="16GB">16GB</option>
             <option value="32GB">32GB</option>
        </select>
    </div>

    <div class="col-md-4">
        <label>Estado</label>
        <select name="estado" class="form-select">
            <option value="Nuevo">Nuevo</option>
            <option value="Reacondicionado">Reacondicionado</option>
            <option value="Usado">Usado</option>
        </select>
    </div>

    <div class="col-md-4">
        <label>Imagen</label>
        <input type="file" name="imagen" class="form-control" accept="image/*">
    </div>

    <div class="col-12 mt-3">
        <button type="submit" class="btn btn-primary">Guardar Producto</button>
        <a href="index.php" class="btn btn-secondary">Cancelar</a>
    </div>
</form>

<?php include_once '../../includes/footer.php'; ?>
