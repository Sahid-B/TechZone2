<?php
require_once '../../includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error_carrito'] = 'Debes iniciar sesión para realizar una compra';
    header('Location: ' . BASE_URL . 'auth/login.php');
    exit;
}

if (!isset($_SESSION['carrito']) || count($_SESSION['carrito']) == 0) {
    $_SESSION['error_carrito'] = 'El carrito está vacío';
    header('Location: ' . BASE_URL . 'carrito.php');
    exit;
}

$pdo = db_connect();

try {
    $pdo->beginTransaction();

    // Determinar cliente
    $cliente_id = null;
    
    // Si el usuario es un cliente (rol_id = 4), buscar su registro en la tabla clientes
    if ($_SESSION['rol_id'] == 4) {
        $stmt = $pdo->prepare("SELECT id FROM clientes WHERE email = ?");
        $stmt->execute([$_SESSION['email']]);
        $cliente = $stmt->fetch();
        
        if ($cliente) {
            $cliente_id = $cliente['id'];
        } else {
            // Si no existe, crear cliente desde la sesión
            $stmt = $pdo->prepare("INSERT INTO clientes (cedula, nombre, email, telefono) VALUES (?, ?, ?, ?)");
            $cedula = 'CLI-' . $_SESSION['user_id'] . '-' . time();
            $stmt->execute([
                $cedula,
                $_SESSION['nombre'],
                $_SESSION['email'],
                ''
            ]);
            $cliente_id = $pdo->lastInsertId();
        }
    } else {
        // Si es admin o vendedor comprando, necesitamos un cliente
        // Por ahora, usaremos un cliente genérico o el primero disponible
        $stmt = $pdo->query("SELECT id FROM clientes LIMIT 1");
        $cliente = $stmt->fetch();
        if ($cliente) {
            $cliente_id = $cliente['id'];
        } else {
            // Crear cliente genérico
            $stmt = $pdo->prepare("INSERT INTO clientes (cedula, nombre, email) VALUES (?, ?, ?)");
            $cedula = 'GEN-' . time();
            $stmt->execute([
                $cedula,
                $_SESSION['nombre'] . ' (Compra Online)',
                $_SESSION['email']
            ]);
            $cliente_id = $pdo->lastInsertId();
        }
    }

    if (!$cliente_id) {
        throw new Exception("No se pudo determinar el cliente");
    }

    // Validar productos y calcular totales
    $subtotal = 0;
    $validated_products = [];

    $stmtPrice = $pdo->prepare("SELECT id, precio_venta, stock_actual, nombre FROM productos WHERE id = ? AND activo = 1");

    foreach ($_SESSION['carrito'] as $item) {
        $stmtPrice->execute([$item['id_producto']]);
        $db_prod = $stmtPrice->fetch();

        if (!$db_prod) {
            throw new Exception("Producto no encontrado: " . $item['nombre']);
        }

        if ($db_prod['stock_actual'] < $item['cantidad']) {
            throw new Exception("Stock insuficiente para: " . $item['nombre'] . " (Disponible: " . $db_prod['stock_actual'] . ")");
        }

        $real_price = $db_prod['precio_venta'];
        $qty = $item['cantidad'];

        $subtotal += $real_price * $qty;

        $validated_products[] = [
            'id' => $item['id_producto'],
            'cantidad' => $qty,
            'precio' => $real_price,
            'subtotal' => $real_price * $qty
        ];

        $stmtPrice->closeCursor();
    }

    $iva = $subtotal * 0.12; // IVA 12%
    $descuento = 0;
    $total = $subtotal + $iva;

    // Obtener método de pago del formulario
    $metodo_pago = $_POST['metodo_pago'] ?? 'Efectivo';
    
    // Si hay datos de tarjeta, agregarlos a observaciones (en producción esto debería encriptarse)
    $observaciones = '';
    if (isset($_POST['numero_tarjeta']) && !empty($_POST['numero_tarjeta'])) {
        $numero_tarjeta = $_POST['numero_tarjeta'];
        // Mostrar solo los últimos 4 dígitos por seguridad
        $ultimos_4 = substr(str_replace(' ', '', $numero_tarjeta), -4);
        $observaciones = "Tarjeta terminada en: ****" . $ultimos_4;
        if (isset($_POST['nombre_tarjeta']) && !empty($_POST['nombre_tarjeta'])) {
            $observaciones .= " | Nombre: " . htmlspecialchars($_POST['nombre_tarjeta']);
        }
    }

    $numero_venta = 'FAC-' . date('Ymd') . '-' . uniqid();

    // Determinar id_usuario para la venta
    // Si es un cliente (rol_id = 4), necesitamos usar un usuario del sistema
    // porque id_usuario debe existir en la tabla usuarios
    $id_usuario_venta = null;
    
    if ($_SESSION['rol_id'] == 4) {
        // Para clientes, usar el primer vendedor o admin disponible
        // O crear un usuario "Sistema" si no existe
        $stmt = $pdo->query("SELECT id FROM usuarios WHERE rol_id IN (1, 2) AND activo = 1 LIMIT 1");
        $usuario_sistema = $stmt->fetch();
        
        if ($usuario_sistema) {
            $id_usuario_venta = $usuario_sistema['id'];
        } else {
            // Si no hay vendedores ni admins, crear un usuario sistema
            // Primero verificar si ya existe
            $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = 'sistema@techzone.com'");
            $stmt->execute();
            $sistema = $stmt->fetch();
            
            if ($sistema) {
                $id_usuario_venta = $sistema['id'];
            } else {
                // Crear usuario sistema
                $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, email, password, rol_id) VALUES (?, ?, ?, ?)");
                $hash_sistema = password_hash('sistema123', PASSWORD_BCRYPT);
                $stmt->execute(['Sistema', 'sistema@techzone.com', $hash_sistema, 2]); // Rol vendedor
                $id_usuario_venta = $pdo->lastInsertId();
            }
        }
    } else {
        // Si es admin o vendedor, usar su propio ID
        $id_usuario_venta = $_SESSION['user_id'];
    }

    if (!$id_usuario_venta) {
        throw new Exception("No se pudo determinar el usuario para procesar la venta");
    }

    // Registrar venta
    $stmt = $pdo->prepare("CALL sp_registrar_venta(:num, :cli, :usr, :sub, :iva, :desc, :tot, :met, @id_venta)");
    $stmt->execute([
        ':num' => $numero_venta,
        ':cli' => $cliente_id,
        ':usr' => $id_usuario_venta,
        ':sub' => $subtotal,
        ':iva' => $iva,
        ':desc' => $descuento,
        ':tot' => $total,
        ':met' => $metodo_pago
    ]);

    $result = $pdo->query("SELECT @id_venta as id")->fetch();
    $id_venta = $result['id'];

    if (!$id_venta) {
        throw new Exception("Error al crear la venta");
    }

    // Agregar detalles
    $stmtDetalle = $pdo->prepare("CALL sp_agregar_detalle_venta(:idv, :idp, :cant, :prec, :sub)");

    foreach ($validated_products as $prod) {
        $stmtDetalle->execute([
            ':idv' => $id_venta,
            ':idp' => $prod['id'],
            ':cant' => $prod['cantidad'],
            ':prec' => $prod['precio'],
            ':sub' => $prod['subtotal']
        ]);
        $stmtDetalle->closeCursor();
    }

    $pdo->commit();

    // Vaciar carrito
    $_SESSION['carrito'] = [];
    $_SESSION['success_carrito'] = 'Compra realizada exitosamente! Número de venta: ' . $numero_venta;

    // Redirigir al ticket
    header('Location: ' . BASE_URL . 'modules/ventas/ticket.php?id=' . $id_venta);
    exit;

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $_SESSION['error_carrito'] = 'Error al procesar la compra: ' . $e->getMessage();
    header('Location: ' . BASE_URL . 'carrito.php');
    exit;
}


