<?php
require_once '../includes/functions.php';

check_login(); // Security

$term = $_GET['q'] ?? '';
if(!$term) { echo json_encode([]); exit; }

$pdo = db_connect();
$stmt = $pdo->prepare("CALL sp_buscar_cliente(?)");
$stmt->execute([$term]);
$result = $stmt->fetch();

echo json_encode($result ? $result : []);
