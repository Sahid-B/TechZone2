<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['id_producto']) || !isset($input['cantidad'])) {
    echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
    exit;
}

$id_producto = (int)$input['id_producto'];
$cantidad = (int)$input['cantidad'];

if ($id_producto <= 0 || $cantidad <= 0) {
    echo json_encode(['success' => false, 'message' => 'Datos inválidos']);
    exit;
}

// Inicializar carrito si no existe
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

// Verificar stock disponible
$pdo = db_connect();
$stmt = $pdo->prepare("SELECT id, nombre, precio_venta, stock_actual FROM productos WHERE id = ? AND activo = 1");
$stmt->execute([$id_producto]);
$producto = $stmt->fetch();

if (!$producto) {
    echo json_encode(['success' => false, 'message' => 'Producto no encontrado']);
    exit;
}

// Verificar si ya está en el carrito
$encontrado = false;
$cantidad_actual = 0;

foreach ($_SESSION['carrito'] as $key => $item) {
    if ($item['id_producto'] == $id_producto) {
        $encontrado = true;
        $cantidad_actual = $item['cantidad'];
        break;
    }
}

$nueva_cantidad = $cantidad_actual + $cantidad;

// Verificar stock
if ($nueva_cantidad > $producto['stock_actual']) {
    echo json_encode([
        'success' => false, 
        'message' => 'Stock insuficiente. Disponible: ' . $producto['stock_actual']
    ]);
    exit;
}

// Agregar o actualizar en el carrito
if ($encontrado) {
    foreach ($_SESSION['carrito'] as $key => $item) {
        if ($item['id_producto'] == $id_producto) {
            $_SESSION['carrito'][$key]['cantidad'] = $nueva_cantidad;
            $_SESSION['carrito'][$key]['subtotal'] = $nueva_cantidad * $producto['precio_venta'];
            break;
        }
    }
} else {
    $_SESSION['carrito'][] = [
        'id_producto' => $id_producto,
        'nombre' => $producto['nombre'],
        'precio' => $producto['precio_venta'],
        'cantidad' => $cantidad,
        'subtotal' => $cantidad * $producto['precio_venta']
    ];
}

$carrito_count = count($_SESSION['carrito']);

echo json_encode([
    'success' => true,
    'message' => 'Producto agregado al carrito',
    'carrito_count' => $carrito_count
]);


