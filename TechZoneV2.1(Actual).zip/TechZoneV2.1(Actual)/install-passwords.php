<?php
/**
 * Script para actualizar las contraseñas de los usuarios admin y vendedor
 * Ejecutar una vez después de importar la base de datos
 * 
 * Uso: php install-passwords.php
 * O visitar: http://localhost/techzone/install-passwords.php
 */

require_once 'config/constants.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

// Contraseñas a configurar
$passwords = [
    1 => 'admin',      // admin@gmail.com
    2 => 'vendedor'    // vendedor@gmail.com
];

try {
    $pdo = db_connect();
    
    echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Configurar Contraseñas</title>";
    echo "<style>body{font-family:Arial,sans-serif;max-width:600px;margin:50px auto;padding:20px;}";
    echo "h2{color:#333;} ul{list-style-type:none;padding:0;} li{padding:10px;background:#f5f5f5;margin:5px 0;border-radius:5px;}";
    echo ".success{color:green;font-weight:bold;} .error{color:red;}</style></head><body>";
    
    echo "<h2>Actualizando contraseñas de usuarios...</h2>";
    echo "<ul>";
    
    // Asegurar que los emails estén correctos
    $emails = [
        1 => 'admin@gmail.com',
        2 => 'vendedor@gmail.com'
    ];
    
    foreach ($passwords as $user_id => $password) {
        // Actualizar email si es necesario
        if (isset($emails[$user_id])) {
            $stmt = $pdo->prepare("UPDATE usuarios SET email = ? WHERE id = ?");
            $stmt->execute([$emails[$user_id], $user_id]);
        }
        
        // Generar hash de contraseña
        $hash = password_hash($password, PASSWORD_BCRYPT);
        
        // Actualizar contraseña
        $stmt = $pdo->prepare("UPDATE usuarios SET password = ? WHERE id = ?");
        $stmt->execute([$hash, $user_id]);
        
        // Verificar y mostrar resultado
        $stmt = $pdo->prepare("SELECT email, nombre FROM usuarios WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
        
        // Verificar que la contraseña se guardó correctamente
        $stmt = $pdo->prepare("SELECT password FROM usuarios WHERE id = ?");
        $stmt->execute([$user_id]);
        $saved_hash = $stmt->fetchColumn();
        
        if (password_verify($password, $saved_hash)) {
            echo "<li class='success'>✓ Usuario ID $user_id ({$user['email']} - {$user['nombre']}): Contraseña configurada correctamente a '<strong>$password</strong>'</li>";
        } else {
            echo "<li class='error'>✗ Error al configurar contraseña para usuario ID $user_id</li>";
        }
    }
    
    echo "</ul>";
    echo "<p class='success'>¡Contraseñas actualizadas exitosamente!</p>";
    echo "<p><strong>Credenciales de acceso:</strong></p>";
    echo "<ul>";
    echo "<li>Admin: <strong>admin@gmail.com</strong> / <strong>admin</strong></li>";
    echo "<li>Vendedor: <strong>vendedor@gmail.com</strong> / <strong>vendedor</strong></li>";
    echo "</ul>";
    echo "<p><a href='auth/login.php' style='display:inline-block;padding:10px 20px;background:#007bff;color:white;text-decoration:none;border-radius:5px;'>Ir al Login</a></p>";
    echo "<p><a href='index.php' style='display:inline-block;padding:10px 20px;background:#28a745;color:white;text-decoration:none;border-radius:5px;margin-left:10px;'>Ir a la Página Principal</a></p>";
    
    // Eliminar este archivo por seguridad (opcional)
    // unlink(__FILE__);
    
    echo "</body></html>";
    
} catch (Exception $e) {
    echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Error</title></head><body>";
    echo "<p class='error'>Error: " . $e->getMessage() . "</p>";
    echo "<p>Detalles: " . $e->getTraceAsString() . "</p>";
    echo "</body></html>";
}


