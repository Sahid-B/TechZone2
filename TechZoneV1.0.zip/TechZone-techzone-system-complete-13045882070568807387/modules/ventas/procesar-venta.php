<?php
require_once '../../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid Request']);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['success' => false, 'message' => 'No data']);
    exit;
}

$pdo = db_connect();

try {
    $pdo->beginTransaction();

    // 1. Validate Prices and Calculate Totals Server-Side (Security Fix)
    // Don't trust client side prices.
    $subtotal = 0;
    $validated_products = [];

    $stmtPrice = $pdo->prepare("SELECT id, precio_venta, stock_actual, nombre FROM productos WHERE id = ?");

    foreach ($input['productos'] as $prod) {
        $stmtPrice->execute([$prod['id']]);
        $db_prod = $stmtPrice->fetch();

        if (!$db_prod) {
            throw new Exception("Producto no encontrado: ID " . $prod['id']);
        }

        if ($db_prod['stock_actual'] < $prod['cantidad']) {
            throw new Exception("Stock insuficiente para: " . $db_prod['nombre']);
        }

        $real_price = $db_prod['precio_venta'];
        $qty = $prod['cantidad'];

        $subtotal += $real_price * $qty;

        $validated_products[] = [
            'id' => $prod['id'],
            'cantidad' => $qty,
            'precio' => $real_price,
            'subtotal' => $real_price * $qty
        ];

        $stmtPrice->closeCursor();
    }

    $iva = $subtotal * 0.15;
    $descuento = floatval($input['descuento']); // Ideally validate discount limits too
    $total = ($subtotal + $iva) - $descuento;

    // Prevent negative total
    if ($total < 0) $total = 0;

    $numero_venta = uniqid('FAC-');

    // 2. Call SP Registrar Venta
    $stmt = $pdo->prepare("CALL sp_registrar_venta(:num, :cli, :usr, :sub, :iva, :desc, :tot, :met, @id_venta)");
    $stmt->execute([
        ':num' => $numero_venta,
        ':cli' => $input['cliente_id'],
        ':usr' => $_SESSION['user_id'],
        ':sub' => $subtotal,
        ':iva' => $iva,
        ':desc' => $descuento,
        ':tot' => $total,
        ':met' => $input['metodo_pago']
    ]);

    $result = $pdo->query("SELECT @id_venta as id")->fetch();
    $id_venta = $result['id'];

    if (!$id_venta) throw new Exception("Error creating sale header");

    // 3. Details
    $stmtDetalle = $pdo->prepare("CALL sp_agregar_detalle_venta(:idv, :idp, :cant, :prec, :sub)");

    foreach ($validated_products as $prod) {
        $stmtDetalle->execute([
            ':idv' => $id_venta,
            ':idp' => $prod['id'],
            ':cant' => $prod['cantidad'],
            ':prec' => $prod['precio'],
            ':sub' => $prod['subtotal']
        ]);
        $stmtDetalle->closeCursor();
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'id_venta' => $id_venta,
        'numero_venta' => $numero_venta
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
