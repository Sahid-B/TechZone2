<?php
require_once '../../includes/functions.php';
check_permission([1]); // Admin

// Placeholder for generating a full PDF report
// In a real scenario, we would use FPDF or TCPDF library
// Here we output a printable HTML version

include_once '../../includes/header.php';
$pdo = db_connect();

// Stats
$stats = [];
$stats['logins'] = $pdo->query("SELECT COUNT(*) FROM auditoria_login")->fetchColumn();
$stats['ops'] = $pdo->query("SELECT COUNT(*) FROM auditoria_operaciones")->fetchColumn();
$stats['ops_insert'] = $pdo->query("SELECT COUNT(*) FROM auditoria_operaciones WHERE accion='INSERT'")->fetchColumn();
$stats['ops_update'] = $pdo->query("SELECT COUNT(*) FROM auditoria_operaciones WHERE accion='UPDATE'")->fetchColumn();
$stats['ops_delete'] = $pdo->query("SELECT COUNT(*) FROM auditoria_operaciones WHERE accion='DELETE'")->fetchColumn();

// Critical Changes
$deletes = $pdo->query("SELECT * FROM auditoria_operaciones WHERE accion='DELETE' ORDER BY fecha_hora DESC LIMIT 10")->fetchAll();
?>

<div class="container my-5">
    <div class="text-center mb-5">
        <h1>Informe de Auditoría del Sistema</h1>
        <h3>TechZone</h3>
        <p>Generado el: <?php echo date('d/m/Y H:i:s'); ?></p>
        <button onclick="window.print()" class="btn btn-primary no-print">Imprimir / Guardar PDF</button>
    </div>

    <hr>

    <h4>1. Resumen Ejecutivo</h4>
    <div class="row text-center my-4">
        <div class="col-md-4">
            <div class="card p-3">
                <h3><?php echo $stats['logins']; ?></h3>
                <small>Total Logins</small>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3">
                <h3><?php echo $stats['ops']; ?></h3>
                <small>Total Operaciones</small>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3">
                <h3><?php echo $stats['ops_delete']; ?></h3>
                <small>Eliminaciones Críticas</small>
            </div>
        </div>
    </div>

    <h4>2. Distribución de Operaciones</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tipo</th>
                <th>Cantidad</th>
                <th>Porcentaje</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>INSERT (Creación)</td>
                <td><?php echo $stats['ops_insert']; ?></td>
                <td><?php echo $stats['ops'] > 0 ? round(($stats['ops_insert']/$stats['ops'])*100, 1) : 0; ?>%</td>
            </tr>
            <tr>
                <td>UPDATE (Modificación)</td>
                <td><?php echo $stats['ops_update']; ?></td>
                <td><?php echo $stats['ops'] > 0 ? round(($stats['ops_update']/$stats['ops'])*100, 1) : 0; ?>%</td>
            </tr>
            <tr>
                <td>DELETE (Eliminación)</td>
                <td><?php echo $stats['ops_delete']; ?></td>
                <td><?php echo $stats['ops'] > 0 ? round(($stats['ops_delete']/$stats['ops'])*100, 1) : 0; ?>%</td>
            </tr>
        </tbody>
    </table>

    <h4 class="mt-5">3. Registro de Eliminaciones (Últimas 10)</h4>
    <table class="table table-sm table-striped">
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Usuario</th>
                <th>Tabla</th>
                <th>Descripción</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($deletes as $del): ?>
            <tr>
                <td><?php echo $del['fecha_hora']; ?></td>
                <td><?php echo $del['nombre_usuario']; ?></td>
                <td><?php echo $del['tabla_afectada']; ?></td>
                <td><?php echo $del['descripcion_accion']; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="alert alert-info mt-5">
        <strong>Conclusión:</strong> El sistema mantiene un registro detallado de todas las actividades. Se recomienda revisar periódicamente las eliminaciones y los cambios de precios en productos.
    </div>
</div>

<style>
    @media print {
        .no-print { display: none; }
        body { background: white; }
    }
</style>

<?php include_once '../../includes/footer.php'; ?>
