<?php
require_once '../../includes/functions.php';
check_permission([1]);
include_once '../../includes/header.php';
$pdo = db_connect();

$start = $_GET['start'] ?? date('Y-m-01');
$end = $_GET['end'] ?? date('Y-m-d');

$sql = "SELECT v.*, c.nombre as cliente, u.nombre as vendedor
        FROM ventas v
        JOIN clientes c ON v.id_cliente = c.id
        JOIN usuarios u ON v.id_usuario = u.id
        WHERE DATE(v.fecha_venta) BETWEEN ? AND ?
        ORDER BY v.fecha_venta DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$start, $end]);
$ventas = $stmt->fetchAll();

$total_periodo = 0;
foreach($ventas as $v) $total_periodo += $v['total'];
?>

<h3>Reporte de Ventas por Periodo</h3>

<form class="row g-3 mb-4 no-print" method="GET">
    <div class="col-auto">
        <label>Inicio</label>
        <input type="date" name="start" class="form-control" value="<?php echo $start; ?>">
    </div>
    <div class="col-auto">
        <label>Fin</label>
        <input type="date" name="end" class="form-control" value="<?php echo $end; ?>">
    </div>
    <div class="col-auto align-self-end">
        <button type="submit" class="btn btn-primary">Generar</button>
        <button type="button" onclick="window.print()" class="btn btn-secondary">Imprimir</button>
    </div>
</form>

<div class="alert alert-success">Total en este periodo: <strong><?php echo format_currency($total_periodo); ?></strong></div>

<table class="table table-bordered table-sm">
    <thead class="table-dark">
        <tr>
            <th>#</th>
            <th>Fecha</th>
            <th>Cliente</th>
            <th>Vendedor</th>
            <th>Subtotal</th>
            <th>IVA</th>
            <th>Total</th>
            <th>Pago</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($ventas as $v): ?>
        <tr>
            <td><?php echo $v['numero_venta']; ?></td>
            <td><?php echo $v['fecha_venta']; ?></td>
            <td><?php echo htmlspecialchars($v['cliente']); ?></td>
            <td><?php echo htmlspecialchars($v['vendedor']); ?></td>
            <td><?php echo format_currency($v['subtotal']); ?></td>
            <td><?php echo format_currency($v['iva']); ?></td>
            <td><?php echo format_currency($v['total']); ?></td>
            <td><?php echo $v['metodo_pago']; ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<style>@media print { .no-print { display: none; } }</style>

<?php include_once '../../includes/footer.php'; ?>
