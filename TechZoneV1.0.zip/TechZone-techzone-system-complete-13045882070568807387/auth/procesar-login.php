<?php
require_once __DIR__ . '/../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    $pdo = db_connect();

    // 1. Validar usuario (Audit attempt happens inside logic)
    try {
        $stmt = $pdo->prepare("CALL sp_validar_login(:email)");
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();
        $stmt->closeCursor(); // Important for next queries

        if ($user && password_verify($password, $user['password'])) {
            // Login Success
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['nombre'] = $user['nombre'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['rol_id'] = $user['rol_id'];

            // Get Role Name
            $stmtRole = $pdo->prepare("SELECT nombre FROM roles WHERE id = ?");
            $stmtRole->execute([$user['rol_id']]);
            $rol = $stmtRole->fetch();
            $_SESSION['rol_nombre'] = $rol['nombre'];

            // Log Success Audit
            registrar_auditoria_login($user['id'], $email, 'login_exitoso');

            header('Location: ' . BASE_URL . 'dashboard.php');
            exit;
        } else {
            // Login Failed
            registrar_auditoria_login(null, $email, 'login_fallido');
            $_SESSION['error_login'] = "Credenciales incorrectas.";
            header('Location: login.php');
            exit;
        }

    } catch (PDOException $e) {
        // DB Error
        error_log($e->getMessage());
        $_SESSION['error_login'] = "Error del sistema. Intente más tarde.";
        header('Location: login.php');
        exit;
    }
} else {
    header('Location: login.php');
    exit;
}
