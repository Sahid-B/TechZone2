<?php
require_once '../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false]); exit;
}

$cedula = $_POST['cedula'];
$nombre = $_POST['nombre'];
$email = $_POST['email'] ?? '';
$telefono = $_POST['telefono'] ?? '';
$direccion = $_POST['direccion'] ?? '';

$pdo = db_connect();

try {
    $stmt = $pdo->prepare("CALL sp_registrar_cliente(:ced, :nom, :ema, :tel, :dir)");
    $stmt->execute([
        ':ced' => $cedula, ':nom' => $nombre, ':ema' => $email, ':tel' => $telefono, ':dir' => $direccion
    ]);

    // Retrieve ID (assuming auto-increment and last insert id works)
    // PDO::lastInsertId() might not work perfectly with SPs in all drivers, but usually fine
    // Or we could fetch by cedula

    $stmt = $pdo->prepare("SELECT id, nombre, cedula FROM clientes WHERE cedula = ?");
    $stmt->execute([$cedula]);
    $cliente = $stmt->fetch();

    echo json_encode(['success' => true, 'id' => $cliente['id'], 'nombre' => $cliente['nombre'], 'cedula' => $cliente['cedula']]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
