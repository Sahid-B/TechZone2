<?php
require_once 'includes/functions.php';
check_login();
include_once 'includes/header.php';

$rol_id = $_SESSION['rol_id'];
$pdo = db_connect();

// Fetch Data for Dashboard based on Role
$stats = [];

// Admin Stats
if ($rol_id == 1) {
    // Total Clientes
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM clientes");
    $stats['clientes'] = $stmt->fetch()['total'];

    // Total Productos
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM productos WHERE activo = 1");
    $stats['productos'] = $stmt->fetch()['total'];

    // Ventas del dia
    $stmt = $pdo->query("SELECT SUM(total) as total FROM ventas WHERE DATE(fecha_venta) = CURDATE()");
    $stats['ventas_hoy'] = $stmt->fetch()['total'] ?? 0;

    // Logins Today
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM auditoria_login WHERE DATE(fecha_hora) = CURDATE() AND tipo_accion='login_exitoso'");
    $stats['logins_hoy'] = $stmt->fetch()['total'];

    // Audit Operations Today
    $stmt = $pdo->query("SELECT accion, COUNT(*) as total FROM auditoria_operaciones WHERE DATE(fecha_hora) = CURDATE() GROUP BY accion");
    $stats['ops_hoy'] = $stmt->fetchAll(PDO::FETCH_KEY_PAIR); // [INSERT => 5, UPDATE => 2]
}

// Vendedor Stats
if ($rol_id == 2) {
     $stmt = $pdo->prepare("SELECT SUM(total) as total FROM ventas WHERE id_usuario = ? AND DATE(fecha_venta) = CURDATE()");
     $stmt->execute([$_SESSION['user_id']]);
     $stats['mis_ventas_hoy'] = $stmt->fetch()['total'] ?? 0;

     $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM ventas WHERE id_usuario = ?");
     $stmt->execute([$_SESSION['user_id']]);
     $stats['mis_ventas_count'] = $stmt->fetch()['total'];
}

// Almacen Stats
if ($rol_id == 3) {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM productos WHERE stock_actual <= stock_minimo AND activo = 1");
    $stats['low_stock'] = $stmt->fetch()['total'];

    $stmt = $pdo->query("SELECT SUM(stock_actual * precio_compra) as total_compra FROM productos WHERE activo=1");
    $stats['valor_inventario'] = $stmt->fetch()['total_compra'];
}

?>

<h2 class="mb-4">Dashboard - <small class="text-muted"><?php echo htmlspecialchars($_SESSION['rol_nombre']); ?></small></h2>

<div class="row">
    <!-- Admin Widgets -->
    <?php if ($rol_id == 1): ?>
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-primary h-100">
            <div class="card-body">
                <h5 class="card-title">Clientes</h5>
                <p class="card-text display-6"><?php echo (int)$stats['clientes']; ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-success h-100">
            <div class="card-body">
                <h5 class="card-title">Ventas Hoy</h5>
                <p class="card-text display-6"><?php echo format_currency($stats['ventas_hoy']); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-info h-100">
            <div class="card-body">
                <h5 class="card-title">Productos</h5>
                <p class="card-text display-6"><?php echo (int)$stats['productos']; ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-warning h-100">
            <div class="card-body">
                <h5 class="card-title">Logins Hoy</h5>
                <p class="card-text display-6"><?php echo (int)$stats['logins_hoy']; ?></p>
            </div>
        </div>
    </div>

    <div class="col-md-6 mb-4">
        <div class="card h-100">
            <div class="card-header">Últimas Operaciones de Auditoría</div>
            <div class="card-body">
                <table class="table table-sm">
                    <thead><tr><th>Usuario</th><th>Acción</th><th>Tabla</th><th>Hora</th></tr></thead>
                    <tbody>
                        <?php
                        $stmt = $pdo->query("SELECT nombre_usuario, accion, tabla_afectada, DATE_FORMAT(fecha_hora, '%H:%i') as hora FROM auditoria_operaciones ORDER BY id DESC LIMIT 5");
                        while($row = $stmt->fetch()){
                            echo "<tr><td>" . htmlspecialchars($row['nombre_usuario']) . "</td><td>" . htmlspecialchars($row['accion']) . "</td><td>" . htmlspecialchars($row['tabla_afectada']) . "</td><td>" . htmlspecialchars($row['hora']) . "</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
                <a href="modules/auditoria/operaciones.php" class="btn btn-sm btn-outline-primary">Ver todas</a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Vendedor Widgets -->
    <?php if ($rol_id == 2): ?>
    <div class="col-md-4 mb-4">
        <div class="card text-white bg-success h-100">
            <div class="card-body">
                <h5 class="card-title">Mis Ventas Hoy</h5>
                <p class="card-text display-6"><?php echo format_currency($stats['mis_ventas_hoy']); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card text-white bg-primary h-100">
            <div class="card-body">
                <h5 class="card-title">Total Ventas</h5>
                <p class="card-text display-6"><?php echo (int)$stats['mis_ventas_count']; ?></p>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Almacen Widgets -->
    <?php if ($rol_id == 3 || $rol_id == 1): ?>
        <?php if($rol_id == 1) echo "<div class='col-12 mt-4'><h4>Inventario</h4></div>"; ?>
        <div class="col-md-4 mb-4">
            <div class="card text-white bg-danger h-100">
                <div class="card-body">
                    <h5 class="card-title">Stock Bajo</h5>
                    <p class="card-text display-6"><?php echo (int)($stats['low_stock'] ?? 0); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
             <div class="card text-white bg-secondary h-100">
                <div class="card-body">
                    <h5 class="card-title">Valor Inventario</h5>
                    <p class="card-text display-6"><?php echo format_currency($stats['valor_inventario'] ?? 0); ?></p>
                </div>
            </div>
        </div>
    <?php endif; ?>

</div>

<?php include_once 'includes/footer.php'; ?>
