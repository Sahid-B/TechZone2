<?php
require_once 'config/constants.php';
require_once 'config/database.php';
require_once 'includes/functions.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Inicializar carrito si no existe
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

// Obtener productos activos
$pdo = db_connect();
$stmt = $pdo->query("SELECT p.*, m.nombre as marca, c.nombre as categoria 
                     FROM productos p 
                     LEFT JOIN marcas m ON p.marca_id = m.id 
                     LEFT JOIN categorias_producto c ON p.categoria_id = c.id 
                     WHERE p.activo = 1 AND p.stock_actual > 0 
                     ORDER BY p.nombre ASC");
$productos = $stmt->fetchAll();

// Contar items en carrito
$carrito_count = count($_SESSION['carrito']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechZone - Tienda de Tecnología</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
    <style>
        .navbar-public {
            background: linear-gradient(90deg, #4e73df 0%, #224abe 100%) !important;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .product-card {
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            border: 1px solid #e3e6f0;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1) !important;
        }
        .btn-cart {
            position: relative;
        }
        .cart-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #dc3545;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 60px 0;
            margin-bottom: 40px;
        }
    </style>
</head>
<body>
    <!-- Navbar Público -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-public">
        <div class="container">
            <a class="navbar-brand" href="<?php echo BASE_URL; ?>">
                <i class="fas fa-microchip"></i> TechZone
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <?php if($_SESSION['rol_id'] != 4): // Solo mostrar Panel si NO es cliente ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> Panel
                            </a>
                        </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link btn-cart" href="<?php echo BASE_URL; ?>carrito.php">
                                <i class="fas fa-shopping-cart"></i> Carrito
                                <?php if($carrito_count > 0): ?>
                                    <span class="cart-badge" id="cart-badge-nav"><?php echo $carrito_count; ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <span class="navbar-text me-3 text-white">
                                <?php echo htmlspecialchars($_SESSION['nombre']); ?>
                            </span>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>auth/logout.php">
                                <i class="fas fa-sign-out-alt"></i> Salir
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link btn-cart" href="<?php echo BASE_URL; ?>carrito.php">
                                <i class="fas fa-shopping-cart"></i> Carrito
                                <?php if($carrito_count > 0): ?>
                                    <span class="cart-badge"><?php echo $carrito_count; ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>auth/login.php">
                                <i class="fas fa-sign-in-alt"></i> Iniciar Sesión
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>auth/registro.php">
                                <i class="fas fa-user-plus"></i> Crear Cuenta
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container text-center">
            <h1 class="display-4 fw-bold mb-3">Bienvenido a TechZone</h1>
            <p class="lead">Encuentra la mejor tecnología al mejor precio</p>
        </div>
    </div>

    <!-- Productos -->
    <div class="container mb-5">
        <h2 class="mb-4">Nuestros Productos</h2>
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-4 g-4">
            <?php foreach($productos as $prod): ?>
            <div class="col">
                <div class="card h-100 product-card">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title"><?php echo htmlspecialchars($prod['nombre']); ?></h5>
                        <p class="text-muted small mb-2">
                            <strong>Marca:</strong> <?php echo htmlspecialchars($prod['marca'] ?? 'N/A'); ?><br>
                            <strong>Categoría:</strong> <?php echo htmlspecialchars($prod['categoria'] ?? 'N/A'); ?><br>
                            <strong>Código:</strong> <?php echo htmlspecialchars($prod['codigo']); ?>
                        </p>
                        <?php if($prod['descripcion']): ?>
                            <p class="card-text small text-muted flex-grow-1">
                                <?php echo htmlspecialchars(substr($prod['descripcion'], 0, 100)); ?>
                                <?php echo strlen($prod['descripcion']) > 100 ? '...' : ''; ?>
                            </p>
                        <?php endif; ?>
                        <div class="mt-auto">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="fs-4 fw-bold text-primary">
                                    <?php echo format_currency($prod['precio_venta']); ?>
                                </span>
                                <span class="badge bg-success">
                                    Stock: <?php echo (int)$prod['stock_actual']; ?>
                                </span>
                            </div>
                            <button class="btn btn-primary w-100 btn-agregar-carrito" 
                                    data-id="<?php echo $prod['id']; ?>"
                                    data-nombre="<?php echo htmlspecialchars($prod['nombre']); ?>"
                                    data-precio="<?php echo $prod['precio_venta']; ?>"
                                    data-stock="<?php echo $prod['stock_actual']; ?>">
                                <i class="fas fa-cart-plus"></i> Agregar al Carrito
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-4 mt-5">
        <div class="container">
            <p class="mb-0">&copy; <?php echo date('Y'); ?> TechZone. Todos los derechos reservados.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/main.js"></script>
    <script>
        // Agregar al carrito
        document.querySelectorAll('.btn-agregar-carrito').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const nombre = this.getAttribute('data-nombre');
                const precio = parseFloat(this.getAttribute('data-precio'));
                const stock = parseInt(this.getAttribute('data-stock'));

                fetch('<?php echo BASE_URL; ?>ajax/agregar-carrito.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        id_producto: id,
                        cantidad: 1
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        // Actualizar badge del carrito - buscar en todos los posibles lugares
                        const cartBadges = document.querySelectorAll('.cart-badge');
                        const cartBadgeNav = document.getElementById('cart-badge-nav');
                        
                        // Actualizar todos los badges existentes
                        cartBadges.forEach(badge => {
                            badge.textContent = data.carrito_count;
                        });
                        
                        // Si existe el badge del navbar, actualizarlo
                        if(cartBadgeNav) {
                            cartBadgeNav.textContent = data.carrito_count;
                        }
                        
                        // Si no existe ningún badge, crear uno
                        if(cartBadges.length === 0 && !cartBadgeNav) {
                            const cartLinks = document.querySelectorAll('.btn-cart');
                            cartLinks.forEach(cartLink => {
                                if(!cartLink.querySelector('.cart-badge')) {
                                    const badge = document.createElement('span');
                                    badge.className = 'cart-badge';
                                    badge.id = 'cart-badge-nav';
                                    badge.textContent = data.carrito_count;
                                    cartLink.appendChild(badge);
                                }
                            });
                        }
                        
                        // Mostrar mensaje de éxito
                        alert('✓ Producto agregado al carrito: ' + nombre + '\n\nTotal en carrito: ' + data.carrito_count + ' producto(s)');
                        
                        // Actualizar página si es necesario
                        if(data.redirect) {
                            window.location.href = data.redirect;
                        }
                    } else {
                        alert('✗ Error: ' + (data.message || 'No se pudo agregar el producto'));
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al agregar producto al carrito');
                });
            });
        });
    </script>
</body>
</html>
