<?php
require_once __DIR__ . '/../includes/functions.php';

if (isset($_SESSION['user_id'])) {
    registrar_auditoria_login($_SESSION['user_id'], $_SESSION['email'], 'logout');
}

session_unset();
session_destroy();
header('Location: ' . BASE_URL . 'index.php');
exit;
