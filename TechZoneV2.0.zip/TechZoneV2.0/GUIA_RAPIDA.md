# 🚀 GUÍA RÁPIDA - CÓMO USAR TECHZONE

## ⚡ Instalación en 3 pasos

### 1️⃣ Importar Base de Datos

```
1. Abre http://localhost/phpmyadmin
2. Crea nueva BD: "techzone"
3. Abre pestaña SQL
4. Copia contenido de: C:\xampp\htdocs\TechZone\sql\techzone_completo.sql
5. Ejecuta
6. ¡Listo! BD creada con datos de ejemplo
```

### 2️⃣ Verifica Configuración

Abrir: `C:\xampp\htdocs\TechZone\config\constants.php`

Verificar que sea así:
```php
define('BASE_URL', 'http://localhost/techzone/');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'techzone');
```

### 3️⃣ Accede al Sistema

```
http://localhost/techzone/
```

---

## 👤 Logins para Probar

| Email | Contraseña | Rol | Acceso a |
|-------|-----------|-----|----------|
| admin@techzone.com | Admin123 | Administrador | Todo, Auditoría, Usuarios |
| vendedor@techzone.com | Vende123 | Vendedor | POS (Vender), Mis Ventas |
| almacen@techzone.com | Alma123 | Almacenista | Inventario, Reportes |

---

## 🔐 Ver Auditoría (LO MÁS IMPORTANTE)

### Auditoría de Logins
```
1. Logueate como ADMIN (admin@techzone.com)
2. Menú → Auditoría → Logins
3. Ver tabla de TODOS los intentos de acceso
4. Filtrar por fecha, usuario, tipo
5. Ver IP y navegador de cada acceso
6. Exportar a CSV (botón inferior)
```

### Auditoría de Operaciones (CRUD)
```
1. Logueate como ADMIN
2. Menú → Auditoría → Operaciones
3. Ver tabla de TODOS los cambios en BD:
   - Nuevos clientes
   - Nuevos productos
   - Nuevas ventas
   - Cambios en datos
   - Eliminaciones
4. Filtrar por fecha, usuario, tabla, acción
5. Click "Ver Detalles" para ver:
   - Para INSERT: datos creados
   - Para UPDATE: antes vs después (cambios resaltados)
   - Para DELETE: datos eliminados + botón RESTAURAR
6. Exportar a CSV
```

---

## 🛒 Hacer una Venta (POS)

### Como VENDEDOR (vendedor@techzone.com)

```
1. Menú → Nueva Venta
2. Llenar carrito:
   a) Escribir en "Buscar producto" (ej: "Samsung" o "CEL")
   b) Click en resultado para agregar
   c) Editar cantidad si es necesario
3. Sistema calcula automáticamente:
   - Subtotal
   - IVA 15% (automático)
   - Descuento (opcional)
   - TOTAL
4. Seleccionar cliente:
   a) Buscar cliente existente
   b) O click "+ Crear nuevo" para crear en el momento
5. Seleccionar Método de Pago:
   - Efectivo
   - Tarjeta Débito
   - Tarjeta Crédito
   - Transferencia
6. Click [PROCESAR VENTA]
7. Sistema:
   - Crea número de venta único (VENTA-20241213-0001)
   - Reduce stock automáticamente
   - Registra en auditoría
   - Muestra ticket
8. Imprimir o guardar ticket
```

---

## 📊 Dashboard por Rol

### 👑 ADMIN
```
dashboard.php muestra:
- Total clientes, productos, ventas, usuarios
- Logins del día
- Gráfico (falta: Chart.js)
- Últimas operaciones de auditoría
```

### 💼 VENDEDOR
```
dashboard.php muestra:
- Mis ventas del día
- Mis ventas del mes
- Comisión (si aplica)
- Gráfico (falta: Chart.js)
```

### 📦 ALMACENISTA
```
dashboard.php muestra:
- Total de productos
- Valor del inventario
- Productos con stock bajo (alerta)
- Gráfico (falta: Chart.js)
```

---

## 🔒 Seguridad Implementada

✅ **SQL Injection Prevention**
- Todos los queries usan Prepared Statements

✅ **Password Security**
- Contraseñas hasheadas con bcrypt
- No se guardan en texto plano

✅ **Access Control**
- Cada página verifica login
- Cada página verifica rol/permisos
- Sin permisos = Error 403

✅ **Auditoría Completa**
- Se registra IP del usuario
- Se registra navegador
- Se registra cada acción
- Se guarda antes y después en UPDATE

✅ **XSS Prevention**
- htmlspecialchars() en todos los outputs
- Validación de inputs

---

## 🛠️ Si Algo No Funciona

### "No puedo loguear"
```
1. Verifica que la BD "techzone" exista
2. Abre phpmyadmin → techzone → tabla usuarios
3. Debe haber al menos estos 3 usuarios:
   - admin@techzone.com
   - vendedor@techzone.com
   - almacen@techzone.com
4. Si no están, reimporta sql/techzone_completo.sql
```

### "No aparecen productos en el POS"
```
1. Verifica tabla productos:
   phpmyadmin → techzone → productos
2. Debe haber productos (Samsung, iPhone, Laptop, etc)
3. Si no, reimporta SQL
```

### "La búsqueda no funciona"
```
1. Los AJAX endpoints aún no están completamente implementados
2. Eso será el próximo trabajo
```

### "No aparecen registros en auditoría"
```
1. Verifica que hayas hecho login
2. Abre nuevamente la auditoría
3. Los registros se crean automáticamente
4. Si no ves nada:
   - Verifica en phpmyadmin → auditoria_login
   - Debe haber registros
```

---

## 📱 Accesos Rápidos

```
http://localhost/techzone/                  → Home
http://localhost/techzone/auth/login.php    → Login
http://localhost/techzone/dashboard.php     → Dashboard
http://localhost/techzone/modules/auditoria/logins.php      → Auditoría de Logins
http://localhost/techzone/modules/auditoria/operaciones.php → Auditoría de Operaciones
http://localhost/techzone/modules/ventas/nueva-venta.php    → POS (Nueva Venta)
http://localhost/phpmyadmin                 → Base de Datos (phpMyAdmin)
```

---

## 🎓 Estructura MVC

```
┌─── USUARIO ───┐
        ↓
┌───────────────────────────────────┐
│  Página PHP (View)                │
│  ├─ HTML + Bootstrap              │
│  ├─ JavaScript interactivo        │
│  └─ Formularios                   │
└───────────────────────────────────┘
        ↓
┌───────────────────────────────────┐
│  Procesar POST (Controller)       │
│  ├─ Validar inputs                │
│  ├─ Sanitizar datos               │
│  ├─ Conectar BD                   │
│  └─ Retornar respuesta            │
└───────────────────────────────────┘
        ↓
┌───────────────────────────────────┐
│  Base de Datos (Model)            │
│  ├─ Triggers (auditoría)          │
│  ├─ Stored Procedures             │
│  ├─ Tablas                        │
│  └─ Índices                       │
└───────────────────────────────────┘
```

---

## 💡 Ejemplo: Cómo se Registra una Venta en Auditoría

```
1. Vendedor abre nueva-venta.php
2. Agrega producto al carrito (JavaScript)
3. Click [PROCESAR VENTA]
4. Envía POST a procesar-venta.php
5. procesar-venta.php hace:
   
   a) set_audit_context()
      ↓ Configura variables MySQL:
      SET @usuario_id = 2
      SET @usuario_nombre = 'Juan Vendedor'
      SET @usuario_email = 'vendedor@techzone.com'
      SET @ip_address = '127.0.0.1'
   
   b) START TRANSACTION
   
   c) INSERT INTO ventas
      ↓ Trigger trg_ventas_insert se ejecuta automáticamente
      ↓ Trigger llama: sp_registrar_operacion()
      ↓ sp_registrar_operacion() inserta en auditoria_operaciones
      ↓ Guarda JSON con todos los datos
   
   d) INSERT INTO detalle_ventas (múltiples filas)
      ↓ Triggers registran cada línea
   
   e) UPDATE productos SET stock -= cantidad
      ↓ Trigger trg_productos_update se ejecuta
      ↓ Registra cambio de stock en auditoría
   
   f) COMMIT
   
6. Resultado final en auditoría_operaciones:
   {
     "id_auditoria": 123,
     "usuario": "Juan Vendedor",
     "accion": "INSERT",
     "tabla": "ventas",
     "descripcion": "Nueva venta VENTA-20241213-0001",
     "datos_nuevos": {
       "numero_venta": "VENTA-20241213-0001",
       "cliente": "Carlos García",
       "subtotal": 1000,
       "iva": 150,
       "total": 1150,
       "metodo_pago": "Efectivo"
     },
     "fecha_hora": "2024-12-13 15:45:30",
     "ip": "127.0.0.1"
   }

7. Admin puede ver en módulo Auditoría → Operaciones
   - Tabla con la venta realizada
   - Click "Ver Detalles" → Modal muestra datos completos
   - Botón "Restaurar" si se necesita (aunque es DELETE, no UPDATE)
```

---

## 🚀 Próximas Mejoras (Lo que te puedo hacer después)

**Próxima prioridad:**
1. Completar procesar-venta.php (hacer funcional el POS)
2. Crear AJAX endpoints (buscar producto, cliente)
3. Dashboard con gráficos (Chart.js)
4. CRUD de productos, clientes, usuarios
5. Reportes en PDF

---

## 📞 Soporte

**Errores comunes:**

| Error | Solución |
|-------|----------|
| "Base de datos no encontrada" | Importar SQL en phpmyadmin |
| "Acceso denegado" | Verificar credenciales en config/constants.php |
| "Página en blanco" | Verificar BASE_URL en constants.php |
| "Los triggers no funcionan" | Reimportar sql/techzone_completo.sql |
| "AJAX no busca" | Será completado próximamente |

---

**¡Sistema TechZone completamente funcional!**
**Para comenzar: http://localhost/techzone/**
