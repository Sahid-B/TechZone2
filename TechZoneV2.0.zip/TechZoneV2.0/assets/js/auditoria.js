<?php
/**
 * ARCHIVO JAVASCRIPT: Funciones para Auditoría
 * Descripción: Funciones para modal de detalles, exportación CSV
 * y restauración de registros
 */

// Mostrar modal con detalles completos de auditoría
function mostrarDetallesAuditoria(datoAuditoria) {
    const modal = document.getElementById('modalDetallesAuditoria');
    
    // Llenar datos en modal
    document.getElementById('auditModal-usuario').textContent = datoAuditoria.nombre_usuario || '-';
    document.getElementById('auditModal-email').textContent = datoAuditoria.email_usuario || '-';
    document.getElementById('auditModal-tipo').innerHTML = obtenerBadgeTipo(datoAuditoria.accion);
    document.getElementById('auditModal-tabla').textContent = datoAuditoria.tabla_afectada;
    document.getElementById('auditModal-id').textContent = datoAuditoria.registro_afectado_id || '-';
    document.getElementById('auditModal-fecha').textContent = formatearFecha(datoAuditoria.fecha_hora);
    document.getElementById('auditModal-ip').textContent = datoAuditoria.ip_address || '-';
    document.getElementById('auditModal-descripcion').textContent = datoAuditoria.descripcion_accion || '-';
    
    // Datos anteriores y nuevos
    const oldData = datoAuditoria.datos_anteriores ? JSON.stringify(JSON.parse(datoAuditoria.datos_anteriores), null, 2) : '-';
    const newData = datoAuditoria.datos_nuevos ? JSON.stringify(JSON.parse(datoAuditoria.datos_nuevos), null, 2) : '-';
    
    document.getElementById('auditModal-datosOld').textContent = oldData;
    document.getElementById('auditModal-datosNew').textContent = newData;
    
    // Mostrar modal
    if(modal) {
        new bootstrap.Modal(modal).show();
    }
}

// Obtener badge HTML según tipo de operación
function obtenerBadgeTipo(tipo) {
    const colores = {
        'INSERT': 'success',
        'UPDATE': 'info',
        'DELETE': 'danger',
        'SELECT': 'secondary'
    };
    const color = colores[tipo] || 'secondary';
    return `<span class="badge bg-${color}">${tipo}</span>`;
}

// Formatear fecha y hora
function formatearFecha(fechaStr) {
    const fecha = new Date(fechaStr);
    return fecha.toLocaleString('es-ES', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

// Exportar tabla a CSV
function exportarACSV(nombreTabla, idTabla) {
    const tabla = document.getElementById(idTabla);
    if(!tabla) {
        alert('Tabla no encontrada');
        return;
    }

    let csv = [];
    
    // Obtener encabezados
    const encabezados = [];
    tabla.querySelectorAll('thead th').forEach(th => {
        encabezados.push(th.textContent.trim());
    });
    csv.push(encabezados.map(e => `"${e}"`).join(','));
    
    // Obtener filas
    tabla.querySelectorAll('tbody tr').forEach(tr => {
        const celdas = [];
        tr.querySelectorAll('td').forEach((td, index) => {
            // Excluir columna de acciones (última)
            if(index < encabezados.length - 1) {
                let texto = td.textContent.trim()
                    .replace(/\n/g, ' ')
                    .replace(/"/g, '""');
                celdas.push(`"${texto}"`);
            }
        });
        if(celdas.length > 0) csv.push(celdas.join(','));
    });
    
    // Crear y descargar archivo
    const contenido = "\uFEFF" + csv.join('\n');
    const blob = new Blob([contenido], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = nombreTabla + '_' + new Date().toISOString().split('T')[0] + '.csv';
    link.click();
}

// Buscar en tabla dinámicamente
function buscarEnTabla(idInput, idTabla) {
    const input = document.getElementById(idInput);
    const tabla = document.getElementById(idTabla);
    const filtro = input.value.toLowerCase();
    
    tabla.querySelectorAll('tbody tr').forEach(tr => {
        const texto = tr.textContent.toLowerCase();
        tr.style.display = texto.includes(filtro) ? '' : 'none';
    });
}

// Restaurar registro eliminado
function restaurarRegistro(idAuditoria, tabla) {
    if(!confirm('¿Desea restaurar este registro? Esta acción puede no ser completamente reversible.')) {
        return;
    }

    fetch(window.location.origin + '/techzone/ajax/restaurar-auditoria.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            id_auditoria: idAuditoria,
            tabla_afectada: tabla
        })
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            alert('Registro restaurado correctamente');
            location.reload();
        } else {
            alert('Error al restaurar: ' + (data.error || 'Error desconocido'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error en la solicitud');
    });
}

// Obtener estadísticas en tiempo real
function actualizarEstadisticasAuditoria() {
    fetch(window.location.origin + '/techzone/ajax/estadisticas-auditoria.php')
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            document.getElementById('stat-total-ops').textContent = data.stats.total_operaciones || 0;
            document.getElementById('stat-inserts').textContent = data.stats.inserts || 0;
            document.getElementById('stat-updates').textContent = data.stats.updates || 0;
            document.getElementById('stat-deletes').textContent = data.stats.deletes || 0;
            document.getElementById('stat-total-logins').textContent = data.stats.total_logins || 0;
        }
    })
    .catch(error => console.error('Error actualizando estadísticas:', error));
}

// Filtrar auditoría por rango de fechas
function filtrarPorFechas(idFormFiltro) {
    const form = document.getElementById(idFormFiltro);
    if(form) {
        form.submit();
    }
}

// Comparar datos anteriores y nuevos
function compararDatos(datosOld, datosNew) {
    if(!datosOld || !datosNew) return null;
    
    const oldObj = JSON.parse(datosOld);
    const newObj = JSON.parse(datosNew);
    const cambios = {};
    
    // Encontrar cambios
    for(const key in newObj) {
        if(oldObj[key] !== newObj[key]) {
            cambios[key] = {
                anterior: oldObj[key],
                nuevo: newObj[key]
            };
        }
    }
    
    return Object.keys(cambios).length > 0 ? cambios : null;
}

// Generar reporte de auditoría en JSON
function exportarReporteJSON(filtros) {
    const reporte = {
        fecha_generacion: new Date().toISOString(),
        filtros: filtros,
        datos: []
    };
    
    const tabla = document.querySelector('table#tablaOperaciones');
    if(tabla) {
        tabla.querySelectorAll('tbody tr').forEach(tr => {
            const celdas = tr.querySelectorAll('td');
            if(celdas.length > 0) {
                reporte.datos.push({
                    fecha: celdas[0].textContent.trim(),
                    usuario: celdas[1].textContent.trim(),
                    tipo: celdas[2].textContent.trim(),
                    tabla: celdas[3].textContent.trim(),
                    id_registro: celdas[4].textContent.trim()
                });
            }
        });
    }
    
    const json = JSON.stringify(reporte, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'reporte_auditoria_' + new Date().toISOString().split('T')[0] + '.json';
    link.click();
}

// Mostrar notificación toast
function mostrarNotificacion(titulo, mensaje, tipo = 'info') {
    const html = `
        <div class="toast align-items-center text-white bg-${tipo}" role="alert">
            <div class="d-flex">
                <div class="toast-body">
                    <strong>${titulo}:</strong> ${mensaje}
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `;
    
    const container = document.getElementById('toastContainer') || createToastContainer();
    container.innerHTML += html;
    
    const toast = new bootstrap.Toast(container.lastElementChild);
    toast.show();
    
    setTimeout(() => {
        container.lastElementChild.remove();
    }, 5000);
}

// Crear contenedor de notificaciones
function createToastContainer() {
    const container = document.createElement('div');
    container.id = 'toastContainer';
    container.style.position = 'fixed';
    container.style.top = '20px';
    container.style.right = '20px';
    container.style.zIndex = '9999';
    document.body.appendChild(container);
    return container;
}

// Inicializar funciones al cargar
document.addEventListener('DOMContentLoaded', function() {
    actualizarEstadisticasAuditoria();
    
    // Actualizar estadísticas cada 30 segundos
    setInterval(actualizarEstadisticasAuditoria, 30000);
});
