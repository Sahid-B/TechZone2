# 🔧 DOCUMENTACIÓN TÉCNICA COMPLETA

## 📚 Tabla de Contenidos

1. Arquitectura del Sistema
2. Base de Datos
3. Funciones PHP
4. API AJAX
5. Flujos de Datos
6. Ejemplos de Código
7. Troubleshooting

---

## 1️⃣ Arquitectura del Sistema

### Stack Tecnológico
```
Capa de Presentación (Frontend)
├── HTML5 + Bootstrap 5.3
├── CSS Custom (assets/css/style.css)
└── JavaScript Vanilla (assets/js/main.js)

Capa de Aplicación (Backend)
├── PHP 8.0+ (config/ + includes/ + modules/)
├── Funciones Globales (includes/functions.php)
├── Control de Acceso (check_login, check_permission)
└── Auditoría (registrar_auditoria_*)

Capa de Datos (Database)
├── MySQL 5.7+ (InnoDB)
├── 17 Tablas
├── 9 Triggers
├── 8 Stored Procedures
└── 20 Índices
```

### Patrón MVC Ligero
```
View                Controller              Model
(HTML)              (PHP)                  (MySQL)
  ↓                   ↓                      ↓
nueva-venta.php → procesar-venta.php → ventas table
  (form)              (validate)          (insert)
                      (sanitize)          trigger
                      (execute)           audit
                      (response)          procedures
```

### Flujo de Requests
```
1. Cliente hace request HTTP
   GET /nueva-venta.php  o  POST /procesar-venta.php

2. PHP router:
   ├─ check_login() → Verificar sesión
   ├─ check_permission() → Verificar rol
   └─ set_audit_context() → Configurar auditoría

3. Lógica:
   ├─ Validar inputs
   ├─ Conectar BD (config/database.php)
   ├─ Preparar statement
   ├─ Ejecutar query
   └─ Triggers se activan automáticamente

4. Triggers:
   ├─ sp_registrar_operacion() es llamado
   ├─ JSON de antes/después se almacena
   └─ Auditoría registrada automáticamente

5. Response:
   ├─ JSON (para AJAX)
   ├─ HTML + Redirect (para formularios)
   └─ Error (si validación falla)
```

---

## 2️⃣ Base de Datos

### Estructura de Tablas

#### roles
```sql
id_rol (PK)          INT PRIMARY KEY AUTO_INCREMENT
nombre               VARCHAR(50) UNIQUE
descripcion          TEXT
estado               TINYINT DEFAULT 1
fecha_creacion       TIMESTAMP DEFAULT CURRENT_TIMESTAMP

Índices: PRIMARY KEY (id_rol)
Data: admin, vendedor, almacenista, cliente
```

#### usuarios
```sql
id_usuario (PK)      INT PRIMARY KEY AUTO_INCREMENT
id_rol (FK)          INT FOREIGN KEY references roles(id_rol)
nombre               VARCHAR(100) NOT NULL
email                VARCHAR(100) UNIQUE NOT NULL
contrasena           VARCHAR(255) NOT NULL [BCRYPT HASH]
telefono             VARCHAR(20)
estado               TINYINT DEFAULT 1
fecha_creacion       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
fecha_ultima_login   TIMESTAMP NULL

Índices: 
  - PRIMARY KEY (id_usuario)
  - UNIQUE KEY (email)
  - KEY (id_rol)

Data: 3 usuarios (admin, vendedor, almacenista)
```

#### productos
```sql
id_producto (PK)     INT PRIMARY KEY AUTO_INCREMENT
codigo               VARCHAR(50) UNIQUE NOT NULL
nombre               VARCHAR(200) NOT NULL
descripcion          TEXT
id_marca (FK)        INT
id_categoria (FK)    INT
precio_compra        DECIMAL(10,2)
precio_venta         DECIMAL(10,2) NOT NULL
stock                INT DEFAULT 0
stock_minimo         INT DEFAULT 5
especificaciones     JSON NULL [para IMEI, RAM, etc]
imagen               VARCHAR(255)
estado               TINYINT DEFAULT 1
eliminado            TINYINT DEFAULT 0 [soft delete]
fecha_creacion       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
fecha_actualizacion  TIMESTAMP ON UPDATE CURRENT_TIMESTAMP

Índices:
  - PRIMARY KEY (id_producto)
  - UNIQUE KEY (codigo)
  - KEY (id_marca)
  - KEY (id_categoria)
  - KEY (estado)
  
Data: 15 productos variados (celulares, laptops, accesorios)
```

#### categorias
```sql
id_categoria (PK)    INT PRIMARY KEY AUTO_INCREMENT
nombre               VARCHAR(100) UNIQUE NOT NULL
descripcion          TEXT

Data: Electrónica, Accesorios, Computadoras, Telefonía
```

#### marcas
```sql
id_marca (PK)        INT PRIMARY KEY AUTO_INCREMENT
nombre               VARCHAR(100) UNIQUE NOT NULL
pais_origen          VARCHAR(50)

Data: Samsung, Apple, LG, ASUS, HP, Sony, Canon, Bose
```

#### clientes
```sql
id_cliente (PK)      INT PRIMARY KEY AUTO_INCREMENT
cedula               VARCHAR(20) UNIQUE NOT NULL
nombre               VARCHAR(100) NOT NULL
email                VARCHAR(100) UNIQUE
telefono             VARCHAR(20)
ciudad               VARCHAR(50)
estado               TINYINT DEFAULT 1
eliminado            TINYINT DEFAULT 0 [soft delete]
fecha_creacion       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
fecha_actualizacion  TIMESTAMP ON UPDATE CURRENT_TIMESTAMP

Índices:
  - PRIMARY KEY (id_cliente)
  - UNIQUE KEY (cedula)
  - KEY (email)

Data: 3 clientes de ejemplo
```

#### ventas
```sql
id_venta (PK)        INT PRIMARY KEY AUTO_INCREMENT
numero_venta         VARCHAR(50) UNIQUE NOT NULL [VENTA-YYYYMMDD-XXXX]
id_usuario (FK)      INT FOREIGN KEY references usuarios
id_cliente (FK)      INT FOREIGN KEY references clientes
fecha_venta          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
subtotal             DECIMAL(10,2)
iva                  DECIMAL(10,2)
descuento            DECIMAL(10,2) DEFAULT 0
total                DECIMAL(10,2) NOT NULL
metodo_pago          VARCHAR(50) [Efectivo, Débito, Crédito, Transferencia]
estado               VARCHAR(50) DEFAULT 'completada'

Índices:
  - PRIMARY KEY (id_venta)
  - UNIQUE KEY (numero_venta)
  - KEY (id_usuario)
  - KEY (id_cliente)
  - KEY (fecha_venta)
```

#### detalle_ventas
```sql
id_detalle (PK)      INT PRIMARY KEY AUTO_INCREMENT
id_venta (FK)        INT FOREIGN KEY references ventas
id_producto (FK)     INT FOREIGN KEY references productos
cantidad             INT NOT NULL
precio_unitario      DECIMAL(10,2) NOT NULL
subtotal             DECIMAL(10,2) NOT NULL

Índices:
  - PRIMARY KEY (id_detalle)
  - KEY (id_venta)
  - KEY (id_producto)
```

#### auditoria_login [CRÍTICA]
```sql
id_auditoria_login (PK) INT PRIMARY KEY AUTO_INCREMENT
id_usuario (FK)         INT NULL FOREIGN KEY
email_usado             VARCHAR(100)
ip_address              VARCHAR(45) [soporta IPv4 e IPv6]
user_agent              VARCHAR(500)
tipo_accion             VARCHAR(50) [login_exitoso, login_fallido, logout]
fecha_hora              TIMESTAMP DEFAULT CURRENT_TIMESTAMP

Índices:
  - PRIMARY KEY (id_auditoria_login)
  - KEY (id_usuario)
  - KEY (tipo_accion)
  - KEY (fecha_hora)
  
Registra: Cada intento de login (exitoso o fallido) + logouts
```

#### auditoria_operaciones [CRÍTICA]
```sql
id_auditoria_operacion (PK)  INT PRIMARY KEY AUTO_INCREMENT
id_usuario (FK)              INT FOREIGN KEY references usuarios
nombre_usuario               VARCHAR(100)
email_usuario                VARCHAR(100)
accion                       VARCHAR(50) [INSERT, UPDATE, DELETE]
tabla_afectada               VARCHAR(100)
registro_afectado_id         INT
descripcion_accion           VARCHAR(500)
datos_anteriores             JSON NULL [para UPDATE/DELETE]
datos_nuevos                 JSON NULL [para INSERT/UPDATE]
ip_address                   VARCHAR(45)
user_agent                   VARCHAR(500)
fecha_hora                   TIMESTAMP DEFAULT CURRENT_TIMESTAMP

Índices:
  - PRIMARY KEY (id_auditoria_operacion)
  - KEY (id_usuario)
  - KEY (accion)
  - KEY (tabla_afectada)
  - KEY (fecha_hora)
  - FULLTEXT (descripcion_accion)

Registra: CADA cambio INSERT/UPDATE/DELETE en la BD
Almacena: Before/After en JSON para análisis
```

### Triggers (Automáticos)

```sql
1. trg_productos_insert
   AFTER INSERT ON productos
   CALL sp_registrar_operacion(...)
   
2. trg_productos_update
   AFTER UPDATE ON productos
   CALL sp_registrar_operacion(...)
   
3. trg_productos_delete
   AFTER DELETE ON productos
   CALL sp_registrar_operacion(...)
   
4. trg_clientes_insert
   AFTER INSERT ON clientes
   CALL sp_registrar_operacion(...)
   
5. trg_clientes_update
   AFTER UPDATE ON clientes
   CALL sp_registrar_operacion(...)
   
6. trg_clientes_delete
   AFTER DELETE ON clientes
   CALL sp_registrar_operacion(...)
   
7. trg_ventas_insert
   AFTER INSERT ON ventas
   CALL sp_registrar_operacion(...)
   
8. trg_usuarios_insert
   AFTER INSERT ON usuarios
   CALL sp_registrar_operacion(...)
   
9. trg_usuarios_update
   AFTER UPDATE ON usuarios
   CALL sp_registrar_operacion(...)
```

### Stored Procedures

```sql
sp_registrar_login()
├─ IN: p_email, p_resultado, p_ip, p_user_agent
├─ Acción: INSERT INTO auditoria_login
└─ Retorna: ID del registro creado

sp_registrar_operacion()
├─ IN: p_accion, p_tabla, p_id_registro, p_descripcion, p_datos_antes, p_datos_nuevos
├─ Acción: INSERT INTO auditoria_operaciones
├─ Usa: Variables MySQL @usuario_id, @usuario_nombre, @usuario_email, @ip_address
└─ Retorna: ID del registro creado

sp_obtener_auditoria_login()
├─ IN: p_fecha_inicio, p_fecha_fin, p_id_usuario, p_tipo_accion
├─ Acción: SELECT con WHERE dinámico
└─ Retorna: Tabla de logins filtrada

sp_obtener_auditoria_operaciones()
├─ IN: p_fecha_inicio, p_fecha_fin, p_id_usuario, p_tabla, p_accion
├─ Acción: SELECT con WHERE dinámico
└─ Retorna: Tabla de operaciones filtrada

sp_estadisticas_auditoria()
├─ IN: p_fecha_inicio, p_fecha_fin
├─ Acción: COUNT de diferentes tipos
└─ Retorna: Estadísticas de auditoría

sp_validar_login()
├─ IN: p_email, p_contrasena
├─ Acción: SELECT usuario + password_verify()
└─ Retorna: id_usuario si válido, NULL si no

sp_registrar_venta()
├─ IN: p_numero_venta, p_id_usuario, p_id_cliente, p_subtotal, p_iva, p_descuento, p_total, p_metodo_pago
├─ Acción: INSERT INTO ventas
└─ Retorna: ID de venta creada

sp_agregar_detalle_venta()
├─ IN: p_id_venta, p_id_producto, p_cantidad, p_precio_unitario
├─ Acción: INSERT INTO detalle_ventas
└─ Retorna: ID de detalle creado
```

---

## 3️⃣ Funciones PHP (includes/functions.php)

### Funciones de Auditoría

```php
function set_audit_context()
/*
 * IMPORTANTE: Llamar después de login exitoso
 * Configura variables MySQL para que los triggers accedan
 * Variables seteadas:
 *   @usuario_id = $_SESSION['user_id']
 *   @usuario_nombre = $_SESSION['nombre']
 *   @usuario_email = $_SESSION['email']
 *   @ip_address = IP del usuario
 * Uso:
 *   after $_SESSION['user_id'] = $id;
 *   set_audit_context();
 */

function registrar_auditoria_login($email, $resultado, $ip, $user_agent)
/*
 * Registra intento de login en auditoria_login
 * Parámetros:
 *   $email (string): Email usado en login
 *   $resultado (string): 'exitoso', 'fallido', 'logout'
 *   $ip (string): IP del usuario (get_user_ip())
 *   $user_agent (string): Navegador (get_user_agent())
 * Usa stored procedure: sp_registrar_login
 * Retorna: ID del registro creado
 * Uso:
 *   registrar_auditoria_login(
 *       'usuario@email.com',
 *       'exitoso',
 *       get_user_ip(),
 *       get_user_agent()
 *   );
 */

function registrar_auditoria_operacion($accion, $tabla, $id_registro, $descripcion, $datos_antes = null, $datos_despues = null)
/*
 * Registra operación CRUD en auditoria_operaciones
 * Parámetros:
 *   $accion (string): 'INSERT', 'UPDATE', 'DELETE'
 *   $tabla (string): Nombre tabla (ej: 'productos')
 *   $id_registro (int): ID del registro afectado
 *   $descripcion (string): Descripción legible (ej: "Nuevo Samsung A54")
 *   $datos_antes (array): [opcional] Array antes de cambio
 *   $datos_despues (array): [opcional] Array después del cambio
 * Usa stored procedure: sp_registrar_operacion
 * Nota: Los triggers lo hacen automáticamente (no necesitas llamarlo siempre)
 * Uso:
 *   registrar_auditoria_operacion(
 *       'UPDATE',
 *       'productos',
 *       15,
 *       'Cambio precio Samsung A54',
 *       ['precio_venta' => 450],
 *       ['precio_venta' => 420]
 *   );
 */
```

### Funciones de Validación

```php
function sanitize($input)
/*
 * Limpia string de tags HTML y espacios extra
 * Retorna: String seguro
 * Uso:
 *   $nombre = sanitize($_POST['nombre']);
 *   // Convierte: "<script>alert('xss')</script>" → "scriptalartsxssscript"
 */

function validar_email($email)
/*
 * Valida formato de email
 * Retorna: true/false
 * Uso:
 *   if (!validar_email($email)) {
 *       error("Email inválido");
 *   }
 */

function validar_cedula($cedula)
/*
 * Valida cédula ecuatoriana (RUC/CI)
 * Retorna: true/false
 * Valida:
 *   - Exactamente 10 dígitos
 *   - Algoritmo de validación (dígito verificador)
 * Uso:
 *   if (!validar_cedula($cedula)) {
 *       error("Cédula inválida");
 *   }
 */

function get_user_ip()
/*
 * Obtiene IP del usuario (considera proxies)
 * Retorna: String IP (IPv4 o IPv6)
 * Comprueba: HTTP_CLIENT_IP, HTTP_X_FORWARDED_FOR, REMOTE_ADDR
 * Uso:
 *   $ip = get_user_ip(); // "192.168.1.100"
 */

function get_user_agent()
/*
 * Obtiene User-Agent del navegador
 * Retorna: String completo
 * Uso:
 *   $browser = get_user_agent(); // "Mozilla/5.0..."
 */
```

### Funciones de Base de Datos

```php
function obtener_categorias()
/*
 * Obtiene todas las categorías
 * Retorna: Array [id => nombre]
 * Uso:
 *   $categorias = obtener_categorias();
 *   foreach ($categorias as $id => $nombre) {
 *       echo "<option value='$id'>$nombre</option>";
 *   }
 */

function obtener_marcas()
/*
 * Obtiene todas las marcas
 * Retorna: Array [id => nombre]
 */

function obtener_roles()
/*
 * Obtiene todos los roles
 * Retorna: Array [id => nombre]
 */
```

### Funciones de Control de Acceso

```php
function check_login()
/*
 * Verifica que usuario esté logueado
 * Si NO: Redirige a login.php
 * Uso: Colocar al inicio de cada página protegida
 * Ejemplo:
 *   <?php
 *   require_once 'config/database.php';
 *   check_login();  // Si no logueado, redirige
 *   // Código de página seguro
 *   ?>
 */

function check_permission($roles_permitidos)
/*
 * Verifica que usuario tenga uno de los roles permitidos
 * Parámetro: Array de roles ['admin', 'vendedor']
 * Si NO tiene permiso: Muestra error 403 Forbidden
 * Uso:
 *   check_login();
 *   check_permission(['admin', 'almacenista']);
 *   // Solo admin o almacenista pueden ver
 */
```

### Funciones de Utilidad

```php
function generar_numero_venta()
/*
 * Genera número único para venta
 * Retorna: String formato VENTA-YYYYMMDD-XXXX
 * Ejemplo: "VENTA-20241213-0001"
 * XXXX incrementa cada venta del día
 * Uso:
 *   $numero = generar_numero_venta();
 *   // Insertar: INSERT INTO ventas (numero_venta) VALUES ('$numero')
 */
```

---

## 4️⃣ API AJAX

### Endpoints esperados (pendientes de implementar)

```
GET /ajax/buscar-producto.php?q=samsung
├─ Busca productos por código o nombre
├─ Retorna: JSON
│   [
│     {
│       "id": 1,
│       "codigo": "CEL001",
│       "nombre": "Samsung Galaxy A54",
│       "marca": "Samsung",
│       "precio_venta": 450.00,
│       "stock": 15
│     },
│     ...
│   ]
└─ Usado en: nueva-venta.php (autocompletado)

GET /ajax/buscar-cliente.php?q=juan
├─ Busca clientes por cédula, nombre o email
├─ Retorna: JSON
│   [
│     {
│       "id": 1,
│       "cedula": "1234567890",
│       "nombre": "Juan García",
│       "email": "juan@email.com",
│       "telefono": "0987654321"
│     },
│     ...
│   ]
└─ Usado en: nueva-venta.php (búsqueda cliente)

POST /ajax/guardar-cliente.php
├─ Parámetros: cedula, nombre, email, telefono, ciudad
├─ Retorna: JSON
│   {
│     "exito": true,
│     "id_cliente": 15,
│     "mensaje": "Cliente creado correctamente"
│   }
├─ Validaciones:
│   - Cédula única
│   - Email válido
│   - Campos requeridos
└─ Usado en: nueva-venta.php (crear nuevo cliente)

POST /ajax/procesar-venta.php [PENDIENTE - CRÍTICO]
├─ Parámetros:
│   {
│     "cliente_id": 1,
│     "carrito": [
│       {"producto_id": 5, "cantidad": 2, "precio": 450},
│       {"producto_id": 8, "cantidad": 1, "precio": 899}
│     ],
│     "subtotal": 1799,
│     "iva": 269.85,
│     "descuento": 0,
│     "total": 2068.85,
│     "metodo_pago": "Efectivo"
│   }
├─ Acciones:
│   - START TRANSACTION
│   - INSERT INTO ventas
│   - INSERT INTO detalle_ventas (múltiple)
│   - UPDATE productos SET stock -= cantidad
│   - COMMIT/ROLLBACK
│   - Triggers registran automáticamente
├─ Retorna: JSON
│   {
│     "exito": true,
│     "numero_venta": "VENTA-20241213-0001",
│     "total_final": 2068.85,
│     "mensaje": "Venta procesada correctamente"
│   }
└─ Usado en: nueva-venta.php (procesar carrito)

POST /ajax/restaurar-auditoria.php [PENDIENTE]
├─ Parámetros: id_auditoria_operacion
├─ Acción: Reinsertar registro eliminado
├─ Retorna: JSON {exito: true/false, mensaje: "..."}
└─ Usado en: auditoria/operaciones.php (botón restaurar)
```

---

## 5️⃣ Flujos de Datos

### Flujo: Login → Auditoría

```
┌─ Usuario ─────────────────────────────────────┐
│ Email: admin@techzone.com                     │
│ Contraseña: Admin123                          │
└──────────────────┬──────────────────────────┘
                   ↓
          ┌─ auth/login.php ─┐
          │ Formulario POST  │
          └────────┬─────────┘
                   ↓
        ┌─ auth/procesar-login.php ─┐
        │                            │
        │ 1. Sanitizar email         │
        │ 2. Buscar usuario en BD    │
        │ 3. password_verify()       │
        │ 4. Si exitoso:             │
        │    - $_SESSION['user_id']  │
        │    - set_audit_context()   │
        │    - registrar_auditoria_login('exitoso')
        │ 5. Si fallido:             │
        │    - registrar_auditoria_login('fallido')
        │                            │
        └────────┬─────────────────┘
                 ↓
    ┌─ MySQL: auditoria_login ─┐
    │ Registrado:              │
    │ - id_usuario: 1          │
    │ - email: admin@...       │
    │ - tipo_accion: exitoso   │
    │ - ip_address: 127.0.0.1  │
    │ - user_agent: Mozilla... │
    │ - fecha_hora: timestamp  │
    └──────────┬───────────────┘
               ↓
       ┌─ Redirección ─┐
       │ home.php      │
       └───────────────┘
```

### Flujo: Venta → Auditoría Múltiple

```
┌─ Vendedor ──────────────────────────────────┐
│ 1. Carrito con 2 productos                  │
│ 2. Cliente seleccionado                     │
│ 3. Método: Efectivo                         │
└──────────────────┬──────────────────────────┘
                   ↓
      ┌─ nueva-venta.php ─┐
      │ [PROCESAR VENTA]  │
      │ POST al backend   │
      └────────┬──────────┘
               ↓
     ┌─ procesar-venta.php ─────────────────────┐
     │                                          │
     │ 1. set_audit_context()                   │
     │    @usuario_id = 2                       │
     │    @usuario_nombre = 'Juan Vendedor'     │
     │                                          │
     │ 2. START TRANSACTION                     │
     │                                          │
     │ 3. INSERT INTO ventas                    │
     │    numero_venta: 'VENTA-20241213-0001'   │
     │    total: 2068.85                        │
     │    metodo_pago: 'Efectivo'               │
     │    ↓ Trigger: trg_ventas_insert          │
     │    ↓ sp_registrar_operacion() llamado    │
     │    ↓ Registra en auditoria_operaciones   │
     │                                          │
     │ 4. INSERT INTO detalle_ventas            │
     │    - Línea 1: Samsung A54 x2 @ 450       │
     │    - Línea 2: iPhone 15 x1 @ 899         │
     │    ↓ Múltiples inserts                   │
     │    ↓ Cada trigger: sp_registrar_operacion
     │                                          │
     │ 5. UPDATE productos SET stock -= cantidad
     │    - Samsung A54: stock = 13 (antes 15)  │
     │    - iPhone 15: stock = 7 (antes 8)      │
     │    ↓ Trigger: trg_productos_update       │
     │    ↓ sp_registrar_operacion() x2         │
     │                                          │
     │ 6. COMMIT (si todo OK)                   │
     │                                          │
     └─────┬────────────────────────────────────┘
           ↓
  ┌─ MySQL: auditoria_operaciones ─┐
  │ Total: 5 registros creados      │
  │                                 │
  │ 1. INSERT ventas                │
  │    - Acción: INSERT             │
  │    - Tabla: ventas              │
  │    - Descripción: Nueva venta   │
  │    - Datos nuevos: {...}        │
  │    - ID registro: 1             │
  │                                 │
  │ 2. INSERT detalle_ventas (line1)│
  │ 3. INSERT detalle_ventas (line2)│
  │                                 │
  │ 4. UPDATE productos (Samsung)   │
  │    - Acción: UPDATE             │
  │    - Datos antes: stock=15      │
  │    - Datos nuevos: stock=13     │
  │                                 │
  │ 5. UPDATE productos (iPhone)    │
  │    - Datos antes: stock=8       │
  │    - Datos nuevos: stock=7      │
  │                                 │
  │ Cada uno con:                   │
  │ - usuario_id: 2                 │
  │ - fecha_hora: timestamp         │
  │ - ip_address: 127.0.0.1         │
  └────┬──────────────────────────────┘
       ↓
  ┌─ Respuesta ─────────────────────┐
  │ JSON:                           │
  │ {                               │
  │   "exito": true,                │
  │   "numero_venta": "VENTA-...",  │
  │   "total": 2068.85              │
  │ }                               │
  └─────┬──────────────────────────┘
        ↓
   ┌─ JavaScript ─────────────┐
   │ 1. Mostrar número venta  │
   │ 2. Mostrar ticket        │
   │ 3. Opción imprimir       │
   │ 4. Opción nueva venta    │
   └──────────────────────────┘
```

---

## 6️⃣ Ejemplos de Código

### Crear una página protegida con auditoría

```php
<?php
// Archivo: modules/productos/crear.php

require_once '../../config/constants.php';
require_once '../../config/database.php';
require_once '../../includes/functions.php';
require_once '../../includes/header.php';

// Verificar login y permiso
check_login();
check_permission(['admin']);  // Solo admin puede crear

// Obtener datos para formulario
$categorias = obtener_categorias();
$marcas = obtener_marcas();

// Procesamiento de POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Validar y sanitizar
        $codigo = sanitize($_POST['codigo']);
        $nombre = sanitize($_POST['nombre']);
        $precio_venta = floatval($_POST['precio_venta']);
        
        // Validaciones
        if (empty($codigo) || empty($nombre)) {
            throw new Exception("Campos requeridos");
        }
        
        if ($precio_venta <= 0) {
            throw new Exception("Precio debe ser mayor a 0");
        }
        
        // Configurar contexto para triggers
        set_audit_context();
        
        // Preparar statement
        $stmt = $pdo->prepare("
            INSERT INTO productos (
                codigo, nombre, id_marca, id_categoria, 
                precio_compra, precio_venta, stock, stock_minimo
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        // Ejecutar
        $result = $stmt->execute([
            $codigo,
            $nombre,
            $_POST['id_marca'],
            $_POST['id_categoria'],
            floatval($_POST['precio_compra']),
            $precio_venta,
            intval($_POST['stock']),
            intval($_POST['stock_minimo'])
        ]);
        
        if ($result) {
            // El trigger automáticamente registró en auditoria_operaciones
            header("Location: " . BASE_URL . "modules/productos/index.php?msg=creado");
        }
        
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!-- HTML -->
<div class="container mt-5">
    <h2>Crear Producto</h2>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <form method="POST" class="form-control">
        <div class="mb-3">
            <label>Código (UNIQUE)</label>
            <input type="text" name="codigo" class="form-control" required>
        </div>
        
        <div class="mb-3">
            <label>Nombre</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>
        
        <div class="mb-3">
            <label>Marca</label>
            <select name="id_marca" class="form-control">
                <option value="">-- Seleccionar --</option>
                <?php foreach ($marcas as $id => $nombre): ?>
                    <option value="<?= $id ?>"><?= htmlspecialchars($nombre) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="mb-3">
            <label>Precio Compra</label>
            <input type="number" name="precio_compra" class="form-control" step="0.01" required>
        </div>
        
        <div class="mb-3">
            <label>Precio Venta</label>
            <input type="number" name="precio_venta" class="form-control" step="0.01" required>
        </div>
        
        <div class="mb-3">
            <label>Stock</label>
            <input type="number" name="stock" class="form-control" value="0" required>
        </div>
        
        <button type="submit" class="btn btn-primary">Guardar Producto</button>
    </form>
</div>

<?php require_once '../../includes/footer.php'; ?>
```

### AJAX para búsqueda

```php
<?php
// Archivo: ajax/buscar-producto.php

require_once '../config/constants.php';
require_once '../config/database.php';
require_once '../includes/functions.php';

// Verificar que sea AJAX
header('Content-Type: application/json');

// Obtener parámetro
$q = sanitize($_GET['q'] ?? '');

if (strlen($q) < 2) {
    echo json_encode([]);
    exit;
}

try {
    // Prepared statement para prevenir SQL injection
    $stmt = $pdo->prepare("
        SELECT 
            id_producto, 
            codigo, 
            nombre, 
            (SELECT nombre FROM marcas WHERE id_marca = productos.id_marca) as marca,
            precio_venta, 
            stock
        FROM productos
        WHERE (codigo LIKE ? OR nombre LIKE ?)
        AND eliminado = 0
        LIMIT 10
    ");
    
    $q_search = "%{$q}%";
    $stmt->execute([$q_search, $q_search]);
    
    $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($productos);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
```

---

## 7️⃣ Troubleshooting

### Error: "Call to undefined function check_login()"
```
Solución: Agregar require_once al inicio
<?php
require_once 'config/database.php';
require_once 'includes/functions.php';
check_login();  // Ahora funciona
?>
```

### Error: "Base de datos no encontrada"
```
Solución:
1. Abrir phpmyadmin
2. Crear BD: CREATE DATABASE techzone;
3. Importar SQL: sql/techzone_completo.sql
```

### Error: "Access denied for user 'root'@'localhost'"
```
Solución: Verificar en config/constants.php
define('DB_USER', 'root');     // Usuario MySQL
define('DB_PASS', '');         // Contraseña MySQL
define('DB_HOST', 'localhost'); // Host

Si XAMPP tiene contraseña:
define('DB_PASS', 'tu_password');
```

### Error: "Trigger syntax error"
```
Solución: Asegurarse de que SQL completo se importó
En el SQL hay:
- DELIMITER $$
- CREATE TRIGGER nombre ...
- DELIMITER ;

Si falla algún trigger, reimportar todo el SQL
```

### Error: "Los AJAX no funcionan"
```
Solución:
1. Verificar que BASE_URL sea correcto
2. Verificar que los archivos existan:
   - ajax/buscar-producto.php
   - ajax/buscar-cliente.php
   - ajax/guardar-cliente.php
3. Ver en consola JavaScript si hay errores
4. Verificar que las URLs en JavaScript sean relativas
```

### Error: "La auditoría no registra cambios"
```
Solución:
1. Verificar que set_audit_context() fue llamado
2. Verificar en phpmyadmin:
   - Tabla auditoria_operaciones (debe tener registros)
   - Verificar triggers estén creados
3. Si nada registra:
   - Reimportar SQL completo
   - Verificar que no hay errores en BD
```

---

**Documentación Técnica Completa - TechZone v1.0**
