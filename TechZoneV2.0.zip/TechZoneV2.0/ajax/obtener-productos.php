<?php
/**
 * AJAX: Obtener productos según filtros
 * Método: POST
 * Parámetros: categoria, marca
 */

require_once '../includes/functions.php';
header('Content-Type: application/json');

$pdo = db_connect();

$categoria = isset($_POST['categoria']) && !empty($_POST['categoria']) ? (int)$_POST['categoria'] : 0;
$marca = isset($_POST['marca']) && !empty($_POST['marca']) ? (int)$_POST['marca'] : 0;

$sql = "SELECT id, codigo, nombre, precio_venta, stock_actual, imagen_url, categoria_id, marca_id 
        FROM productos 
        WHERE activo = 1";

$params = [];

if($categoria > 0) {
    $sql .= " AND categoria_id = ?";
    $params[] = $categoria;
}

if($marca > 0) {
    $sql .= " AND marca_id = ?";
    $params[] = $marca;
}

$sql .= " ORDER BY nombre LIMIT 50";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $productos = $stmt->fetchAll();
    
    echo json_encode($productos);
} catch(Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
