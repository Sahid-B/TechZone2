<?php
/**
 * AJAX: Obtener detalle de un producto específico
 * Método: GET
 * Parámetro: id
 */

require_once '../includes/functions.php';
header('Content-Type: application/json');

$pdo = db_connect();

if(!isset($_GET['id']) || $_GET['id'] <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'ID de producto inválido']);
    exit;
}

$id = (int)$_GET['id'];

try {
    $stmt = $pdo->prepare("SELECT * FROM productos WHERE id = ? AND activo = 1");
    $stmt->execute([$id]);
    $producto = $stmt->fetch();
    
    if(!$producto) {
        http_response_code(404);
        echo json_encode(['error' => 'Producto no encontrado']);
        exit;
    }
    
    echo json_encode($producto);
} catch(Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
