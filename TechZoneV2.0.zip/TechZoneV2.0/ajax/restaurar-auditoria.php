<?php
/**
 * AJAX: Restaurar registro eliminado desde auditoría
 * Método: POST (JSON)
 * Requerido: id_auditoria, tabla_afectada
 */

require_once '../includes/functions.php';
check_login();

$pdo = db_connect();
header('Content-Type: application/json');

if($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método no permitido']);
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if(!isset($data['id']) || !isset($data['tabla'])) {
        throw new Exception('Parámetros inválidos');
    }

    $id_auditoria = (int)$data['id'];
    $tabla = sanitize($data['tabla']);

    // Obtener registro de auditoría
    $stmt = $pdo->prepare("SELECT * FROM auditoria_operaciones WHERE id = ? AND accion = 'DELETE'");
    $stmt->execute([$id_auditoria]);
    $auditoria = $stmt->fetch();

    if(!$auditoria) {
        throw new Exception('Registro de auditoría no encontrado o no es un DELETE');
    }

    if(!$auditoria['datos_antiguos']) {
        throw new Exception('No hay datos disponibles para restaurar');
    }

    $datos = json_decode($auditoria['datos_anteriores'], true);

    // Restaurar según tabla
    // NOTA: Requiere customización según estructura de cada tabla
    // Este es un ejemplo genérico
    
    if($tabla === 'clientes') {
        $sql = "INSERT INTO clientes (cedula, nombre, email, telefono, direccion, ciudad, activo, fecha_registro) 
                VALUES (?, ?, ?, ?, ?, ?, 1, NOW())";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $datos['cedula'] ?? null,
            $datos['nombre'] ?? null,
            $datos['email'] ?? null,
            $datos['telefono'] ?? null,
            $datos['direccion'] ?? null,
            $datos['ciudad'] ?? null
        ]);
    } else if($tabla === 'productos') {
        $sql = "INSERT INTO productos (codigo, nombre, descripcion, marca_id, categoria_id, 
                precio_compra, precio_venta, stock_actual, stock_minimo, imei, numero_serie, 
                modelo, color, almacenamiento, memoria_ram, garantia_meses, estado, imagen_url, 
                fecha_ingreso, activo) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $datos['codigo'] ?? null,
            $datos['nombre'] ?? null,
            $datos['descripcion'] ?? null,
            $datos['marca_id'] ?? null,
            $datos['categoria_id'] ?? null,
            $datos['precio_compra'] ?? null,
            $datos['precio_venta'] ?? null,
            $datos['stock_actual'] ?? 0,
            $datos['stock_minimo'] ?? 5,
            $datos['imei'] ?? null,
            $datos['numero_serie'] ?? null,
            $datos['modelo'] ?? null,
            $datos['color'] ?? null,
            $datos['almacenamiento'] ?? null,
            $datos['memoria_ram'] ?? null,
            $datos['garantia_meses'] ?? 12,
            $datos['estado'] ?? 'Nuevo',
            $datos['imagen_url'] ?? null,
            $datos['fecha_ingreso'] ?? date('Y-m-d')
        ]);
    } else if($tabla === 'usuarios') {
        if($_SESSION['rol_id'] !== 1) {
            throw new Exception('No tiene permiso para restaurar usuarios');
        }
        $sql = "INSERT INTO usuarios (nombre, email, password, rol_id, activo, fecha_creacion) 
                VALUES (?, ?, ?, ?, 1, NOW())";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $datos['nombre'] ?? null,
            $datos['email'] ?? null,
            $datos['password'] ?? null,
            $datos['rol_id'] ?? 2
        ]);
    } else {
        throw new Exception('Tabla no soportada para restauración');
    }

    // Registrar restauración en auditoría
    registrar_auditoria_operacion(
        'INSERT',
        $tabla,
        $pdo->lastInsertId(),
        'Restauración de registro eliminado - ID Auditoría: ' . $id_auditoria,
        null,
        $datos,
        'auditoria'
    );

    echo json_encode([
        'success' => true,
        'message' => 'Registro restaurado correctamente',
        'nuevo_id' => $pdo->lastInsertId()
    ]);

} catch(Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
