<?php
require_once '../includes/functions.php';

check_permission([1, 2]); // Admin or Seller only for POS creation

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false]); exit;
}

$cedula = $_POST['cedula'];
$nombre = $_POST['nombre'];
$email = $_POST['email'] ?? '';
$telefono = $_POST['telefono'] ?? '';
$direccion = $_POST['direccion'] ?? '';

$pdo = db_connect();

try {
    // Updated SP signature: sp_registrar_cliente(cedula, nombre, email, telefono, direccion, password)
    // For admin-created clients (POS), we pass NULL or empty string as password since they don't have login yet
    $stmt = $pdo->prepare("CALL sp_registrar_cliente(:ced, :nom, :ema, :tel, :dir, :pass)");
    $stmt->execute([
        ':ced' => $cedula,
        ':nom' => $nombre,
        ':ema' => $email,
        ':tel' => $telefono,
        ':dir' => $direccion,
        ':pass' => null // Admin created client has no password initially
    ]);

    // Retrieve ID
    $stmt = $pdo->prepare("SELECT id, nombre, cedula FROM clientes WHERE cedula = ?");
    $stmt->execute([$cedula]);
    $cliente = $stmt->fetch();

    echo json_encode(['success' => true, 'id' => $cliente['id'], 'nombre' => $cliente['nombre'], 'cedula' => $cliente['cedula']]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
