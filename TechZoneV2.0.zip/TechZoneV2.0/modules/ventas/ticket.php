<?php
require_once '../../includes/functions.php';
check_permission([1, 2]);

$id_venta = $_GET['id'] ?? 0;
$pdo = db_connect();

// Cabecera
$stmt = $pdo->prepare("SELECT v.*, c.nombre as cliente, c.cedula, u.nombre as vendedor FROM ventas v JOIN clientes c ON v.id_cliente = c.id JOIN usuarios u ON v.id_usuario = u.id WHERE v.id = ?");
$stmt->execute([$id_venta]);
$venta = $stmt->fetch();

if(!$venta) die("Venta no encontrada");

// Detalle
$stmt = $pdo->prepare("SELECT dv.*, p.nombre, p.codigo FROM detalle_ventas dv JOIN productos p ON dv.id_producto = p.id WHERE dv.id_venta = ?");
$stmt->execute([$id_venta]);
$detalles = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ticket #<?php echo htmlspecialchars($venta['numero_venta']); ?></title>
    <style>
        body { font-family: monospace; width: 300px; margin: 0 auto; }
        .header { text-align: center; border-bottom: 1px dashed #000; padding-bottom: 10px; margin-bottom: 10px; }
        .footer { text-align: center; border-top: 1px dashed #000; padding-top: 10px; margin-top: 10px; font-size: 12px; }
        table { width: 100%; font-size: 12px; }
        .text-right { text-align: right; }
        .totals { margin-top: 10px; font-weight: bold; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body onload="window.print()">
    <div class="header">
        <h2>TechZone</h2>
        <p>RUC: 1234567890001</p>
        <p>Dir: Av. Tecnológica 123</p>
        <p>Tel: 0991234567</p>
        <hr>
        <p>VENTA: <?php echo htmlspecialchars($venta['numero_venta']); ?></p>
        <p>FECHA: <?php echo htmlspecialchars($venta['fecha_venta']); ?></p>
        <p>VENDEDOR: <?php echo htmlspecialchars($venta['vendedor']); ?></p>
        <p>CLIENTE: <?php echo htmlspecialchars($venta['cliente']); ?></p>
        <p>RUC/CI: <?php echo htmlspecialchars($venta['cedula']); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>DESC</th>
                <th>CANT</th>
                <th class="text-right">P.U</th>
                <th class="text-right">TOT</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($detalles as $d): ?>
            <tr>
                <td><?php echo htmlspecialchars(substr($d['nombre'], 0, 15)); ?></td>
                <td><?php echo (int)$d['cantidad']; ?></td>
                <td class="text-right"><?php echo number_format($d['precio_unitario'], 2); ?></td>
                <td class="text-right"><?php echo number_format($d['subtotal'], 2); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="totals text-right">
        <p>SUBTOTAL: $<?php echo number_format($venta['subtotal'], 2); ?></p>
        <p>IVA (15%): $<?php echo number_format($venta['iva'], 2); ?></p>
        <p>DESCUENTO: $<?php echo number_format($venta['descuento'], 2); ?></p>
        <p>TOTAL: $<?php echo number_format($venta['total'], 2); ?></p>
        <p>FORMA PAGO: <?php echo htmlspecialchars($venta['metodo_pago']); ?></p>
    </div>

    <div class="footer">
        <p>¡Gracias por su compra!</p>
        <p>Documento sin validez tributaria</p>
    </div>

    <button class="no-print" onclick="window.history.back()">Volver</button>
</body>
</html>
