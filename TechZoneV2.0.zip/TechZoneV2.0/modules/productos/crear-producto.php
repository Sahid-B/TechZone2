<?php
/**
 * MÓDULO: Productos - Crear Nuevo Producto
 * Descripción: Formulario completo para crear productos con validaciones
 * y subida de imagen
 */

require_once '../../includes/functions.php';
check_permission([1]); // Solo Admin
include_once '../../includes/header.php';

$pdo = db_connect();

// Obtener marcas y categorías
$marcas = $pdo->query("SELECT * FROM marcas ORDER BY nombre")->fetchAll();
$categorias = $pdo->query("SELECT * FROM categorias_producto ORDER BY nombre")->fetchAll();

// Validación del formulario
$errores = [];
$exito = false;

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validaciones básicas
    $codigo = sanitize($_POST['codigo'] ?? '');
    $nombre = sanitize($_POST['nombre'] ?? '');
    $descripcion = sanitize($_POST['descripcion'] ?? '');
    $marca_id = (int)($_POST['marca_id'] ?? 0);
    $categoria_id = (int)($_POST['categoria_id'] ?? 0);
    $precio_compra = (float)($_POST['precio_compra'] ?? 0);
    $precio_venta = (float)($_POST['precio_venta'] ?? 0);
    $stock_actual = (int)($_POST['stock_actual'] ?? 0);
    $stock_minimo = (int)($_POST['stock_minimo'] ?? 5);
    $garantia_meses = (int)($_POST['garantia_meses'] ?? 12);
    $estado = sanitize($_POST['estado'] ?? 'Nuevo');
    $modelo = sanitize($_POST['modelo'] ?? '');
    $color = sanitize($_POST['color'] ?? '');
    $almacenamiento = sanitize($_POST['almacenamiento'] ?? '');
    $memoria_ram = sanitize($_POST['memoria_ram'] ?? '');
    $imei = sanitize($_POST['imei'] ?? '');
    $numero_serie = sanitize($_POST['numero_serie'] ?? '');

    // Validaciones
    if(empty($codigo)) $errores[] = 'El código es requerido';
    if(empty($nombre)) $errores[] = 'El nombre es requerido';
    if($marca_id <= 0) $errores[] = 'Seleccione una marca';
    if($categoria_id <= 0) $errores[] = 'Seleccione una categoría';
    if($precio_compra <= 0) $errores[] = 'El precio de compra debe ser mayor a 0';
    if($precio_venta <= 0) $errores[] = 'El precio de venta debe ser mayor a 0';
    if($stock_actual < 0) $errores[] = 'El stock no puede ser negativo';
    if($precio_venta <= $precio_compra) $errores[] = 'El precio de venta debe ser mayor al precio de compra';

    // Verificar código único
    if(empty($errores)) {
        $stmt = $pdo->prepare("SELECT COUNT(*) as c FROM productos WHERE codigo = ?");
        $stmt->execute([$codigo]);
        if($stmt->fetch()['c'] > 0) {
            $errores[] = 'El código ya existe en el sistema';
        }
    }

    // Validaciones condicionales por categoría
    if($categoria_id > 0 && empty($errores)) {
        $stmt = $pdo->prepare("SELECT nombre FROM categorias_producto WHERE id = ?");
        $stmt->execute([$categoria_id]);
        $categoria = $stmt->fetch();
        
        if($categoria) {
            $nombre_cat = strtolower($categoria['nombre']);
            
            // Para teléfonos y tablets, requerir IMEI
            if(strpos($nombre_cat, 'teléfono') !== false || strpos($nombre_cat, 'tablet') !== false) {
                if(empty($imei)) {
                    $errores[] = 'IMEI es requerido para esta categoría';
                }
            }
            
            // Para otros equipos electrónicos, requerir serie
            if(strpos($nombre_cat, 'computadora') !== false || strpos($nombre_cat, 'laptop') !== false) {
                if(empty($numero_serie)) {
                    $errores[] = 'Número de serie es requerido para esta categoría';
                }
            }
        }
    }

    // Procesar imagen
    $imagen_url = '';
    if(!empty($_FILES['imagen']['name'])) {
        $archivo = $_FILES['imagen'];
        $extensiones_permitidas = ['jpg', 'jpeg', 'png', 'gif'];
        $ext = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
        $tam_maximo = 5 * 1024 * 1024; // 5MB

        if(!in_array($ext, $extensiones_permitidas)) {
            $errores[] = 'Formato de imagen no permitido. Use: JPG, PNG, GIF';
        } elseif($archivo['size'] > $tam_maximo) {
            $errores[] = 'La imagen no debe superar 5MB';
        } else {
            // Crear directorio si no existe
            $dir_imagenes = '../../assets/img/productos/';
            if(!is_dir($dir_imagenes)) {
                mkdir($dir_imagenes, 0755, true);
            }

            // Guardar con nombre único
            $nombre_archivo = uniqid('prod_') . '.' . $ext;
            $ruta_destino = $dir_imagenes . $nombre_archivo;

            if(move_uploaded_file($archivo['tmp_name'], $ruta_destino)) {
                $imagen_url = 'assets/img/productos/' . $nombre_archivo;
            } else {
                $errores[] = 'Error al guardar la imagen';
            }
        }
    }

    // Si no hay errores, guardar en BD
    if(empty($errores)) {
        try {
            $sql = "INSERT INTO productos (
                codigo, nombre, descripcion, marca_id, categoria_id,
                precio_compra, precio_venta, stock_actual, stock_minimo,
                imei, numero_serie, modelo, color, almacenamiento, memoria_ram,
                garantia_meses, estado, imagen_url, fecha_ingreso
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $codigo, $nombre, $descripcion, $marca_id, $categoria_id,
                $precio_compra, $precio_venta, $stock_actual, $stock_minimo,
                $imei ?: null, $numero_serie ?: null, $modelo ?: null,
                $color ?: null, $almacenamiento ?: null, $memoria_ram ?: null,
                $garantia_meses, $estado, $imagen_url, date('Y-m-d')
            ]);

            $producto_id = $pdo->lastInsertId();

            // Registrar en auditoría
            registrar_auditoria_operacion(
                'INSERT',
                'productos',
                $producto_id,
                'Nuevo producto creado: ' . $nombre,
                null,
                [
                    'codigo' => $codigo,
                    'nombre' => $nombre,
                    'precio_venta' => $precio_venta,
                    'stock' => $stock_actual
                ],
                'productos'
            );

            $exito = true;
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle"></i> Producto creado exitosamente. 
                    <a href="index.php" class="alert-link">Ver productos</a>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                  </div>';
        } catch(\Exception $e) {
            $errores[] = 'Error al guardar el producto: ' . $e->getMessage();
        }
    }
}

?>

<div class="container-fluid mt-4">
    <div class="row mb-4">
        <div class="col-md-12">
            <h2><i class="fas fa-plus-circle"></i> Crear Nuevo Producto</h2>
            <a href="index.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Volver</a>
            <hr>
        </div>
    </div>

    <?php if(!empty($errores)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <h5><i class="fas fa-exclamation-circle"></i> Errores encontrados:</h5>
        <ul class="mb-0">
            <?php foreach($errores as $error): ?>
            <li><?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" id="formProducto">
        <div class="row">
            <!-- INFORMACIÓN BÁSICA -->
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-info-circle"></i> Información Básica</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label"><strong>Código del Producto *</strong></label>
                            <input type="text" name="codigo" class="form-control" required 
                                   value="<?php echo htmlspecialchars($_POST['codigo'] ?? ''); ?>"
                                   placeholder="Ej: TECH-001">
                            <small class="text-muted">Código único para identificar el producto</small>
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><strong>Nombre del Producto *</strong></label>
                            <input type="text" name="nombre" class="form-control" required
                                   value="<?php echo htmlspecialchars($_POST['nombre'] ?? ''); ?>"
                                   placeholder="Ej: iPhone 13 Pro 128GB">
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><strong>Descripción</strong></label>
                            <textarea name="descripcion" class="form-control" rows="4" 
                                      placeholder="Descripción detallada del producto"><?php echo htmlspecialchars($_POST['descripcion'] ?? ''); ?></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label"><strong>Marca *</strong></label>
                                    <select name="marca_id" class="form-select" required>
                                        <option value="">Seleccionar...</option>
                                        <?php foreach($marcas as $m): ?>
                                        <option value="<?php echo $m['id']; ?>" <?php echo ($_POST['marca_id'] ?? 0) == $m['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($m['nombre']); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label"><strong>Categoría *</strong></label>
                                    <select name="categoria_id" class="form-select" required onchange="actualizarCamposCondicionales()">
                                        <option value="">Seleccionar...</option>
                                        <?php foreach($categorias as $c): ?>
                                        <option value="<?php echo $c['id']; ?>" <?php echo ($_POST['categoria_id'] ?? 0) == $c['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($c['nombre']); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- PRECIOS E INVENTARIO -->
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0"><i class="fas fa-dollar-sign"></i> Precios e Inventario</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label"><strong>Precio Compra *</strong></label>
                                    <input type="number" name="precio_compra" class="form-control" step="0.01" required
                                           value="<?php echo htmlspecialchars($_POST['precio_compra'] ?? ''); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label"><strong>Precio Venta *</strong></label>
                                    <input type="number" name="precio_venta" class="form-control" step="0.01" required
                                           value="<?php echo htmlspecialchars($_POST['precio_venta'] ?? ''); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label"><strong>Stock Actual *</strong></label>
                                    <input type="number" name="stock_actual" class="form-control" required min="0"
                                           value="<?php echo htmlspecialchars($_POST['stock_actual'] ?? '0'); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label"><strong>Stock Mínimo</strong></label>
                                    <input type="number" name="stock_minimo" class="form-control" min="0"
                                           value="<?php echo htmlspecialchars($_POST['stock_minimo'] ?? '5'); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><strong>Estado</strong></label>
                            <select name="estado" class="form-select">
                                <option value="Nuevo" <?php echo ($_POST['estado'] ?? 'Nuevo') === 'Nuevo' ? 'selected' : ''; ?>>Nuevo</option>
                                <option value="Reacondicionado" <?php echo ($_POST['estado'] ?? '') === 'Reacondicionado' ? 'selected' : ''; ?>>Reacondicionado</option>
                                <option value="Usado" <?php echo ($_POST['estado'] ?? '') === 'Usado' ? 'selected' : ''; ?>>Usado</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><strong>Garantía (meses)</strong></label>
                            <input type="number" name="garantia_meses" class="form-control" min="0"
                                   value="<?php echo htmlspecialchars($_POST['garantia_meses'] ?? '12'); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ESPECIFICACIONES TÉCNICAS -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="fas fa-microchip"></i> Especificaciones Técnicas</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label class="form-label"><strong>Modelo</strong></label>
                            <input type="text" name="modelo" class="form-control"
                                   value="<?php echo htmlspecialchars($_POST['modelo'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label class="form-label"><strong>Color</strong></label>
                            <input type="text" name="color" class="form-control"
                                   value="<?php echo htmlspecialchars($_POST['color'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label class="form-label"><strong>Almacenamiento</strong></label>
                            <input type="text" name="almacenamiento" class="form-control" placeholder="Ej: 128GB"
                                   value="<?php echo htmlspecialchars($_POST['almacenamiento'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label class="form-label"><strong>Memoria RAM</strong></label>
                            <input type="text" name="memoria_ram" class="form-control" placeholder="Ej: 8GB"
                                   value="<?php echo htmlspecialchars($_POST['memoria_ram'] ?? ''); ?>">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label"><strong id="label-imei">IMEI <small class="text-muted">(Si aplica)</small></strong></label>
                            <input type="text" name="imei" class="form-control"
                                   value="<?php echo htmlspecialchars($_POST['imei'] ?? ''); ?>"
                                   placeholder="Ej: 352033123456789">
                            <small class="text-muted">Requerido para teléfonos y tablets</small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label"><strong id="label-serie">Número de Serie <small class="text-muted">(Si aplica)</small></strong></label>
                            <input type="text" name="numero_serie" class="form-control"
                                   value="<?php echo htmlspecialchars($_POST['numero_serie'] ?? ''); ?>"
                                   placeholder="Ej: SN123456789">
                            <small class="text-muted">Requerido para computadoras y laptops</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- IMAGEN DEL PRODUCTO -->
        <div class="card mb-4">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0"><i class="fas fa-image"></i> Imagen del Producto</h5>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label"><strong>Subir Imagen</strong></label>
                    <input type="file" name="imagen" class="form-control" accept="image/*" id="inputImagen">
                    <small class="text-muted">Formatos: JPG, PNG, GIF. Máximo: 5MB</small>
                </div>
                <div id="previewImagen"></div>
            </div>
        </div>

        <!-- BOTONES -->
        <div class="row mb-4">
            <div class="col-md-12">
                <button type="submit" class="btn btn-success btn-lg">
                    <i class="fas fa-save"></i> Guardar Producto
                </button>
                <a href="index.php" class="btn btn-secondary btn-lg">
                    <i class="fas fa-times"></i> Cancelar
                </a>
            </div>
        </div>
    </form>
</div>

<?php include_once '../../includes/footer.php'; ?>

<script>
// Preview de imagen
document.getElementById('inputImagen').addEventListener('change', function(e) {
    const file = e.target.files[0];
    const preview = document.getElementById('previewImagen');
    
    if(file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            preview.innerHTML = `
                <div class="mt-3">
                    <img src="${event.target.result}" style="max-width: 200px; border-radius: 8px;">
                </div>
            `;
        };
        reader.readAsDataURL(file);
    }
});

// Actualizar campos condicionales según categoría
function actualizarCamposCondicionales() {
    // Aquí puedes agregar lógica adicional si es necesario
    console.log('Categoría actualizada');
}

// Validación en cliente
document.getElementById('formProducto').addEventListener('submit', function(e) {
    const precioCompra = parseFloat(document.querySelector('input[name="precio_compra"]').value);
    const precioVenta = parseFloat(document.querySelector('input[name="precio_venta"]').value);
    
    if(precioVenta <= precioCompra) {
        e.preventDefault();
        alert('El precio de venta debe ser mayor al precio de compra');
        return false;
    }
});
</script>
