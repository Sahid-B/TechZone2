<?php
require_once '../../includes/functions.php';
check_permission([1, 3]); // Admin y Almacen

include_once '../../includes/header.php';
$pdo = db_connect();
$stmt = $pdo->prepare("CALL sp_listar_productos()");
$stmt->execute();
$productos = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Gestión de Productos</h3>
    <a href="crear.php" class="btn btn-primary"><i class="fas fa-plus"></i> Nuevo Producto</a>
</div>

<div class="table-responsive">
    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Marca</th>
                <th>Categoría</th>
                <th>Precio Venta</th>
                <th>Stock</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($productos as $prod): ?>
            <tr>
                <td><?php echo htmlspecialchars($prod['codigo']); ?></td>
                <td><?php echo htmlspecialchars($prod['nombre']); ?></td>
                <td><?php echo htmlspecialchars($prod['marca']); ?></td>
                <td><?php echo htmlspecialchars($prod['categoria']); ?></td>
                <td><?php echo format_currency($prod['precio_venta']); ?></td>
                <td>
                    <?php
                    $badge = $prod['stock_actual'] <= $prod['stock_minimo'] ? 'bg-danger' : 'bg-success';
                    echo "<span class='badge $badge'>" . (int)$prod['stock_actual'] . "</span>";
                    ?>
                </td>
                <td><?php echo $prod['activo'] ? 'Activo' : 'Inactivo'; ?></td>
                <td>
                    <a href="editar.php?id=<?php echo $prod['id']; ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                    <a href="eliminar.php?id=<?php echo $prod['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Seguro que desea eliminar este producto?');"><i class="fas fa-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include_once '../../includes/footer.php'; ?>
