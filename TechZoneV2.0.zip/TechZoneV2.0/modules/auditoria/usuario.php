<?php
/**
 * MÓDULO: Auditoría - Vista de Actividades de Usuario Específico
 * Descripción: Timeline visual y estadísticas de acciones de un usuario
 */

require_once '../../includes/functions.php';
check_permission([1, 3]); // Admin y Auditor
include_once '../../includes/header.php';

$pdo = db_connect();

$usuario_id = isset($_GET['id']) ? (int)$_GET['id'] : null;

if(!$usuario_id) {
    echo '<div class="alert alert-danger">Usuario no especificado</div>';
    echo '<a href="logins.php" class="btn btn-primary">Volver</a>';
    exit;
}

// Obtener datos del usuario
$stmt_usuario = $pdo->prepare("SELECT id, nombre, email, rol_id FROM usuarios WHERE id = ?");
$stmt_usuario->execute([$usuario_id]);
$usuario = $stmt_usuario->fetch();

if(!$usuario) {
    echo '<div class="alert alert-danger">Usuario no encontrado</div>';
    echo '<a href="logins.php" class="btn btn-primary">Volver</a>';
    exit;
}

// Obtener estadísticas de logins
$stmt_logins = $pdo->prepare("SELECT 
    COUNT(*) as total_logins,
    SUM(CASE WHEN tipo_accion = 'login_exitoso' THEN 1 ELSE 0 END) as exitosos,
    SUM(CASE WHEN tipo_accion = 'login_fallido' THEN 1 ELSE 0 END) as fallidos
FROM auditoria_login WHERE id_usuario = ?");
$stmt_logins->execute([$usuario_id]);
$stats_logins = $stmt_logins->fetch();

// Obtener estadísticas de operaciones
$stmt_ops = $pdo->prepare("SELECT 
    COUNT(*) as total_operaciones,
    SUM(CASE WHEN accion = 'INSERT' THEN 1 ELSE 0 END) as inserts,
    SUM(CASE WHEN accion = 'UPDATE' THEN 1 ELSE 0 END) as updates,
    SUM(CASE WHEN accion = 'DELETE' THEN 1 ELSE 0 END) as deletes
FROM auditoria_operaciones WHERE id_usuario = ?");
$stmt_ops->execute([$usuario_id]);
$stats_ops = $stmt_ops->fetch();

// Productos modificados (diferentes)
$stmt_productos = $pdo->prepare("SELECT DISTINCT tabla_afectada, registro_afectado_id, COUNT(*) as cambios
FROM auditoria_operaciones 
WHERE id_usuario = ? AND tabla_afectada = 'productos'
GROUP BY registro_afectado_id
ORDER BY cambios DESC");
$stmt_productos->execute([$usuario_id]);
$productos_modificados = $stmt_productos->fetchAll();

// Obtener timeline completo de acciones
$stmt_timeline = $pdo->prepare("
    SELECT 'login' as tipo, id, fecha_hora, tipo_accion as accion, ip_address, 'login' as tabla_afectada, NULL as descripcion_accion, NULL as datos_nuevos
    FROM auditoria_login 
    WHERE id_usuario = ?
    UNION ALL
    SELECT 'operacion' as tipo, id, fecha_hora, accion, ip_address, tabla_afectada, descripcion_accion, datos_nuevos
    FROM auditoria_operaciones 
    WHERE id_usuario = ?
    ORDER BY fecha_hora DESC
    LIMIT 100
");
$stmt_timeline->execute([$usuario_id, $usuario_id]);
$timeline = $stmt_timeline->fetchAll();

?>

<div class="container-fluid mt-4">
    <div class="row mb-4">
        <div class="col-md-12">
            <h2><i class="fas fa-user-clock"></i> Auditoría de Usuario: <?php echo htmlspecialchars($usuario['nombre']); ?></h2>
            <p class="text-muted"><?php echo htmlspecialchars($usuario['email']); ?></p>
            <a href="logins.php" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Volver</a>
            <hr>
        </div>
    </div>

    <!-- Estadísticas -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h6 class="card-title">Logins Exitosos</h6>
                    <h3><?php echo $stats_logins['exitosos'] ?? 0; ?></h3>
                    <small><?php echo $stats_logins['total_logins'] ?? 0; ?> totales</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <h6 class="card-title">Logins Fallidos</h6>
                    <h3><?php echo $stats_logins['fallidos'] ?? 0; ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h6 class="card-title">Total Operaciones</h6>
                    <h3><?php echo $stats_ops['total_operaciones'] ?? 0; ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h6 class="card-title">Tablas Modificadas</h6>
                    <h3><?php echo count($productos_modificados); ?></h3>
                </div>
            </div>
        </div>
    </div>

    <!-- Estadísticas de Operaciones -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <strong>Operaciones CRUD</strong>
                </div>
                <div class="card-body">
                    <p><i class="fas fa-plus text-success"></i> <strong>INSERTs:</strong> <?php echo $stats_ops['inserts'] ?? 0; ?></p>
                    <p><i class="fas fa-edit text-info"></i> <strong>UPDATEs:</strong> <?php echo $stats_ops['updates'] ?? 0; ?></p>
                    <p><i class="fas fa-trash text-danger"></i> <strong>DELETEs:</strong> <?php echo $stats_ops['deletes'] ?? 0; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-dark text-white">
                    <strong>Productos Modificados</strong>
                </div>
                <div class="card-body">
                    <?php if(!empty($productos_modificados)): ?>
                    <div style="max-height: 200px; overflow-y: auto;">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>ID Producto</th>
                                    <th>Cambios</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($productos_modificados as $prod): ?>
                                <tr>
                                    <td><?php echo $prod['registro_afectado_id']; ?></td>
                                    <td><span class="badge bg-info"><?php echo $prod['cambios']; ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <p class="text-muted">Sin modificaciones en productos</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Timeline Visual -->
    <div class="card">
        <div class="card-header bg-dark text-white">
            <strong><i class="fas fa-stream"></i> Timeline de Actividades</strong>
        </div>
        <div class="card-body">
            <div class="timeline">
                <?php foreach($timeline as $evento): ?>
                <div class="timeline-item" style="padding: 15px; border-left: 3px solid #007bff; margin-left: 10px; padding-left: 20px; margin-bottom: 20px;">
                    <div class="timeline-marker" style="position: absolute; left: 0; width: 12px; height: 12px; background: #007bff; border-radius: 50%; margin-top: 5px;"></div>
                    
                    <div class="timeline-time">
                        <small class="text-muted">
                            <?php echo date('d/m/Y H:i:s', strtotime($evento['fecha_hora'])); ?>
                        </small>
                    </div>
                    
                    <div class="timeline-content">
                        <?php if($evento['tipo'] === 'login'): ?>
                            <strong><?php echo $evento['accion'] === 'login_exitoso' ? '✓ Login Exitoso' : '✗ Login Fallido'; ?></strong>
                            <p class="mb-1"><small>IP: <?php echo htmlspecialchars($evento['ip_address']); ?></small></p>
                        <?php else: ?>
                            <span class="badge bg-<?php echo $evento['accion'] === 'INSERT' ? 'success' : ($evento['accion'] === 'UPDATE' ? 'info' : 'danger'); ?>">
                                <?php echo $evento['accion']; ?>
                            </span>
                            <strong><?php echo htmlspecialchars($evento['tabla_afectada']); ?></strong>
                            <p class="mb-1"><small><?php echo htmlspecialchars($evento['descripcion_accion']); ?></small></p>
                            <p class="mb-1"><small>IP: <?php echo htmlspecialchars($evento['ip_address']); ?></small></p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<?php include_once '../../includes/footer.php'; ?>

<style>
.timeline {
    position: relative;
    padding: 20px 0;
}

.timeline-item {
    position: relative;
    border-left: 3px solid #007bff;
    padding-left: 30px;
    margin-bottom: 30px;
}

.timeline-item:before {
    content: "";
    position: absolute;
    left: -8px;
    top: 5px;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: #007bff;
}

.timeline-marker {
    position: absolute;
    left: -8px;
    top: 5px;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: #007bff;
}
</style>
