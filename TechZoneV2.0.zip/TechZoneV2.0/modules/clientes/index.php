<?php
require_once '../../includes/functions.php';
check_permission([1, 2]); // Admin y Vendedor
include_once '../../includes/header.php';
$pdo = db_connect();
$clientes = $pdo->query("SELECT * FROM clientes ORDER BY id DESC LIMIT 50")->fetchAll();
?>

<h3>Gestión de Clientes</h3>
<div class="mb-3">
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalCliente">Nuevo Cliente</button>
</div>

<table class="table table-striped">
    <thead>
        <tr>
            <th>Cédula</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Teléfono</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($clientes as $c): ?>
        <tr>
            <td><?php echo htmlspecialchars($c['cedula']); ?></td>
            <td><?php echo htmlspecialchars($c['nombre']); ?></td>
            <td><?php echo htmlspecialchars($c['email']); ?></td>
            <td><?php echo htmlspecialchars($c['telefono']); ?></td>
            <td>
                <a href="editar.php?id=<?php echo $c['id']; ?>" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                <?php if($_SESSION['rol_id'] == 1): ?>
                <a href="eliminar.php?id=<?php echo $c['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Eliminar cliente?');"><i class="fas fa-trash"></i></a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- Modal Nuevo Cliente (Simplificado reuse from POS logic, but here purely HTML) -->
<div class="modal fade" id="modalCliente" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="../../ajax/guardar-cliente.php" method="POST" id="formCliente"> <!-- This goes to AJAX but we can hijack or just reload -->
                <div class="modal-header">
                    <h5 class="modal-title">Registrar Cliente</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-2"><input type="text" name="cedula" class="form-control" placeholder="Cédula" required></div>
                    <div class="mb-2"><input type="text" name="nombre" class="form-control" placeholder="Nombre Completo" required></div>
                    <div class="mb-2"><input type="email" name="email" class="form-control" placeholder="Email"></div>
                    <div class="mb-2"><input type="text" name="telefono" class="form-control" placeholder="Teléfono"></div>
                    <div class="mb-2"><input type="text" name="direccion" class="form-control" placeholder="Dirección"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" onclick="guardarCliente()">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function guardarCliente() {
    const form = document.getElementById('formCliente');
    const formData = new FormData(form);

    fetch('<?php echo BASE_URL; ?>ajax/guardar-cliente.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            alert('Cliente guardado');
            location.reload();
        } else {
            alert('Error: ' + (data.message || 'Desconocido'));
        }
    });
}
</script>

<?php include_once '../../includes/footer.php'; ?>
