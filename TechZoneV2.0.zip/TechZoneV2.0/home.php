<?php
require_once 'includes/functions.php';
check_login();
include_once 'includes/header.php';
?>

<div class="container mt-5">
    <div class="row mb-5">
        <div class="col-12">
            <h1>Bienvenido, <?php echo htmlspecialchars($_SESSION['nombre']); ?></h1>
            <p class="text-muted">Rol: <?php echo htmlspecialchars($_SESSION['rol_nombre']); ?></p>
        </div>
    </div>

    <div class="row">
        <!-- Admin Menu -->
        <?php if ($_SESSION['rol_id'] == 1): ?>
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Gestión de Clientes</h5>
                    <p class="card-text">Administra el registro y datos de tus clientes.</p>
                    <a href="modules/clientes/index.php" class="btn btn-primary">Ir a Clientes</a>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Gestión de Productos</h5>
                    <p class="card-text">Administra el catálogo y inventario de productos.</p>
                    <a href="modules/productos/index.php" class="btn btn-primary">Ir a Productos</a>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Registrar Ventas</h5>
                    <p class="card-text">Registra nuevas ventas y consulta el historial.</p>
                    <a href="modules/ventas/index.php" class="btn btn-primary">Ir a Ventas</a>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Gestión de Usuarios</h5>
                    <p class="card-text">Administra usuarios del sistema.</p>
                    <a href="modules/usuarios/index.php" class="btn btn-primary">Ir a Usuarios</a>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Reportes</h5>
                    <p class="card-text">Consulta reportes de ventas, auditoría e inventario.</p>
                    <a href="modules/reportes/index.php" class="btn btn-primary">Ir a Reportes</a>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Dashboard</h5>
                    <p class="card-text">Ver estadísticas y métricas del sistema.</p>
                    <a href="dashboard.php" class="btn btn-primary">Ir al Dashboard</a>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Vendedor Menu -->
        <?php if ($_SESSION['rol_id'] == 2): ?>
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Nueva Venta</h5>
                    <p class="card-text">Registra una nueva venta rápidamente.</p>
                    <a href="modules/ventas/nueva-venta.php" class="btn btn-success">Nueva Venta</a>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Mis Ventas</h5>
                    <p class="card-text">Consulta el historial de tus ventas.</p>
                    <a href="modules/ventas/index.php" class="btn btn-primary">Ver Mis Ventas</a>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Dashboard</h5>
                    <p class="card-text">Ver tu desempeño de ventas.</p>
                    <a href="dashboard.php" class="btn btn-primary">Mi Dashboard</a>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Almacen Menu -->
        <?php if ($_SESSION['rol_id'] == 3): ?>
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Inventario</h5>
                    <p class="card-text">Consulta y gestiona el inventario de productos.</p>
                    <a href="modules/productos/index.php" class="btn btn-primary">Ver Inventario</a>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Reportes</h5>
                    <p class="card-text">Consulta reportes de inventario.</p>
                    <a href="modules/reportes/inventario.php" class="btn btn-primary">Ver Reportes</a>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Dashboard</h5>
                    <p class="card-text">Ver estado del inventario.</p>
                    <a href="dashboard.php" class="btn btn-primary">Mi Dashboard</a>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Cliente Menu -->
        <?php if ($_SESSION['rol_id'] == 4): ?>
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Mis Compras</h5>
                    <p class="card-text">Consulta el historial de tus compras.</p>
                    <a href="dashboard.php" class="btn btn-primary">Ver Mis Compras</a>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">Productos</h5>
                    <p class="card-text">Explora nuestro catálogo de productos.</p>
                    <a href="modules/productos/index.php" class="btn btn-primary">Ver Productos</a>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>
