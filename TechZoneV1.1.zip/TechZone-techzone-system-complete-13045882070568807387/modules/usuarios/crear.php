<?php
require_once '../../includes/functions.php';
check_permission([1]); // Admin
include_once '../../includes/header.php';
$pdo = db_connect();

$roles = $pdo->query("SELECT * FROM roles")->fetchAll();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $rol_id = $_POST['rol_id'];

    // Validar email
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    if($stmt->fetch()) {
        echo "<div class='alert alert-danger'>El email ya está registrado</div>";
    } else {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        try {
            // Trigger will handle audit
            $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, email, password, rol_id) VALUES (?, ?, ?, ?)");
            $stmt->execute([$nombre, $email, $hash, $rol_id]);
            echo "<div class='alert alert-success'>Usuario creado correctamente</div>";
        } catch(Exception $e) {
            echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
        }
    }
}
?>

<h3>Nuevo Usuario</h3>
<form method="POST" class="row g-3">
    <div class="col-md-6">
        <label>Nombre Completo</label>
        <input type="text" name="nombre" class="form-control" required>
    </div>
    <div class="col-md-6">
        <label>Email</label>
        <input type="email" name="email" class="form-control" required>
    </div>
    <div class="col-md-6">
        <label>Contraseña</label>
        <input type="password" name="password" class="form-control" required>
    </div>
    <div class="col-md-6">
        <label>Rol</label>
        <select name="rol_id" class="form-select" required>
            <?php foreach($roles as $r): ?>
                <option value="<?php echo $r['id']; ?>"><?php echo $r['nombre']; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-12 mt-3">
        <button type="submit" class="btn btn-primary">Guardar</button>
        <a href="index.php" class="btn btn-secondary">Cancelar</a>
    </div>
</form>

<?php include_once '../../includes/footer.php'; ?>
