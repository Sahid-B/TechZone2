<?php
require_once '../../includes/functions.php';
check_permission([1]); // Admin
include_once '../../includes/header.php';
?>

<h3>Reportes</h3>
<div class="list-group">
    <a href="ventas-periodo.php" class="list-group-item list-group-item-action">Ventas por Periodo</a>
    <a href="productos-top.php" class="list-group-item list-group-item-action">Productos Más Vendidos</a>
    <a href="inventario.php" class="list-group-item list-group-item-action">Inventario Valorizado</a>
    <a href="reporte-auditoria.php" class="list-group-item list-group-item-action list-group-item-danger">Reporte Completo de Auditoría (HTML)</a>
</div>

<?php include_once '../../includes/footer.php'; ?>
