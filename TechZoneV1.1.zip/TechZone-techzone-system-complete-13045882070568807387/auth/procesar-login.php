<?php
require_once __DIR__ . '/../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    $pdo = db_connect();

    try {
        // 1. Try System User Login
        $stmt = $pdo->prepare("CALL sp_validar_login(:email)");
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();
        $stmt->closeCursor();

        if ($user && password_verify($password, $user['password'])) {
            // Login Success (System User)
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['nombre'] = $user['nombre'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['rol_id'] = $user['rol_id'];

            // Get Role Name
            $stmtRole = $pdo->prepare("SELECT nombre FROM roles WHERE id = ?");
            $stmtRole->execute([$user['rol_id']]);
            $rol = $stmtRole->fetch();
            $_SESSION['rol_nombre'] = $rol['nombre'];

            registrar_auditoria_login($user['id'], $email, 'login_exitoso');
            header('Location: ' . BASE_URL . 'dashboard.php');
            exit;
        }

        // 2. Try Client Login
        $stmt = $pdo->prepare("CALL sp_validar_login_cliente(:email)");
        $stmt->execute([':email' => $email]);
        $client = $stmt->fetch();
        $stmt->closeCursor();

        if ($client && isset($client['password']) && password_verify($password, $client['password'])) {
             // Login Success (Client)
             session_regenerate_id(true);
             $_SESSION['user_id'] = $client['id'];
             $_SESSION['nombre'] = $client['nombre'];
             $_SESSION['email'] = $client['email'];
             $_SESSION['rol_id'] = 4; // Virtual Role for Client
             $_SESSION['rol_nombre'] = 'Cliente';

             registrar_auditoria_login($client['id'], $email, 'login_exitoso');
             header('Location: ' . BASE_URL . 'dashboard.php');
             exit;
        }

        // Login Failed
        registrar_auditoria_login(null, $email, 'login_fallido');
        $_SESSION['error_login'] = "Credenciales incorrectas.";
        header('Location: login.php');
        exit;

    } catch (PDOException $e) {
        error_log($e->getMessage());
        $_SESSION['error_login'] = "Error del sistema. Intente más tarde.";
        header('Location: login.php');
        exit;
    }
} else {
    header('Location: login.php');
    exit;
}
