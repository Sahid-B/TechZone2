<?php
require_once __DIR__ . '/../config/constants.php';
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . 'dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro Cliente - TechZone</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f0f2f5; display: flex; align-items: center; justify-content: center; height: 100vh; }
        .login-card { width: 100%; max-width: 500px; padding: 20px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); background: white; }
    </style>
</head>
<body>
    <div class="login-card">
        <h4 class="text-center mb-4">Registro de Clientes</h4>

        <?php if(isset($_SESSION['error_registro'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error_registro']; unset($_SESSION['error_registro']); ?></div>
        <?php endif; ?>

        <form action="procesar-registro.php" method="POST">
            <div class="mb-3">
                <label class="form-label">Cédula</label>
                <input type="text" class="form-control" name="cedula" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Nombre Completo</label>
                <input type="text" class="form-control" name="nombre" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" class="form-control" name="email" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Contraseña</label>
                <input type="password" class="form-control" name="password" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Teléfono</label>
                <input type="text" class="form-control" name="telefono">
            </div>
            <div class="mb-3">
                <label class="form-label">Dirección</label>
                <input type="text" class="form-control" name="direccion">
            </div>
            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary">Registrarse</button>
                <a href="login.php" class="btn btn-outline-secondary">Ya tengo cuenta</a>
            </div>
        </form>
    </div>
</body>
</html>
