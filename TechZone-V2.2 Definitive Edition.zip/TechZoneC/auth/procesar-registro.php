<?php
require_once __DIR__ . '/../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cedula = filter_input(INPUT_POST, 'cedula', FILTER_SANITIZE_STRING);
    $nombre = filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $telefono = filter_input(INPUT_POST, 'telefono', FILTER_SANITIZE_STRING);
    $direccion = filter_input(INPUT_POST, 'direccion', FILTER_SANITIZE_STRING);
    $password = $_POST['password'];

    $pdo = db_connect();

    // Validar duplicados (email o cedula)
    $stmt = $pdo->prepare("SELECT id FROM clientes WHERE email = ? OR cedula = ?");
    $stmt->execute([$email, $cedula]);
    if($stmt->fetch()) {
        $_SESSION['error_registro'] = "El email o la cédula ya están registrados.";
        header('Location: registro.php');
        exit;
    }

    try {
        $hash = password_hash($password, PASSWORD_BCRYPT);

        $stmt = $pdo->prepare("CALL sp_registrar_cliente(:ced, :nom, :ema, :tel, :dir, :pass)");
        $stmt->execute([
            ':ced' => $cedula,
            ':nom' => $nombre,
            ':ema' => $email,
            ':tel' => $telefono,
            ':dir' => $direccion,
            ':pass' => $hash
        ]);

        // Auto Login Logic
        // We need the new client ID
        $stmt = $pdo->prepare("SELECT id, nombre, email FROM clientes WHERE email = ?");
        $stmt->execute([$email]);
        $client = $stmt->fetch();

        if ($client) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $client['id'];
            $_SESSION['nombre'] = $client['nombre'];
            $_SESSION['email'] = $client['email'];
            $_SESSION['rol_id'] = 4; // Client Role
            $_SESSION['rol_nombre'] = 'Cliente';

            registrar_auditoria_login($client['id'], $email, 'login_exitoso');

            header('Location: ' . BASE_URL . 'index.php');
            exit;
        }

        $_SESSION['success_login'] = "Registro exitoso. Inicie sesión.";
        header('Location: login.php');
        exit;

    } catch (PDOException $e) {
        $_SESSION['error_registro'] = "Error del sistema: " . $e->getMessage();
        header('Location: registro.php');
        exit;
    }
} else {
    header('Location: registro.php');
    exit;
}
