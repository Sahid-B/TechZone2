<?php
require_once '../includes/functions.php';

check_login(); // Security: Ensure user is logged in

$term = $_GET['q'] ?? '';
if(strlen($term) < 2) { echo json_encode([]); exit; }

$pdo = db_connect();
$stmt = $pdo->prepare("SELECT * FROM productos WHERE (codigo LIKE ? OR nombre LIKE ?) AND stock_actual > 0 AND activo = 1 LIMIT 10");
$term = "%$term%";
$stmt->execute([$term, $term]);
$results = $stmt->fetchAll();

echo json_encode($results);
