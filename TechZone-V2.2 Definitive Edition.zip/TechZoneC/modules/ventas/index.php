<?php
require_once '../../includes/functions.php';
check_permission([1, 2]); // Admin y Vendedor
include_once '../../includes/header.php';
$pdo = db_connect();

$stmt = $pdo->query("SELECT v.*, c.nombre as cliente, u.nombre as vendedor FROM ventas v JOIN clientes c ON v.id_cliente = c.id JOIN usuarios u ON v.id_usuario = u.id ORDER BY v.fecha_venta DESC LIMIT 50");
$ventas = $stmt->fetchAll();
?>

<h3>Historial de Ventas</h3>

<table class="table table-hover">
    <thead>
        <tr>
            <th># Venta</th>
            <th>Fecha</th>
            <th>Cliente</th>
            <th>Vendedor</th>
            <th>Total</th>
            <th>Método</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($ventas as $v): ?>
        <tr>
            <td><?php echo htmlspecialchars($v['numero_venta']); ?></td>
            <td><?php echo htmlspecialchars($v['fecha_venta']); ?></td>
            <td><?php echo htmlspecialchars($v['cliente']); ?></td>
            <td><?php echo htmlspecialchars($v['vendedor']); ?></td>
            <td><?php echo format_currency($v['total']); ?></td>
            <td><?php echo htmlspecialchars($v['metodo_pago']); ?></td>
            <td>
                <a href="ticket.php?id=<?php echo $v['id']; ?>" class="btn btn-sm btn-info" target="_blank"><i class="fas fa-print"></i></a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include_once '../../includes/footer.php'; ?>
