<?php
require_once '../../includes/functions.php';
check_permission([1]); // Admin
include_once '../../includes/header.php';
$pdo = db_connect();

$roles = $pdo->query("SELECT * FROM roles")->fetchAll();

$mensaje = '';
$tipo_mensaje = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    $rol_id = (int)$_POST['rol_id'];

    // Validar email
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    if($stmt->fetch()) {
        $mensaje = 'El email ya está registrado';
        $tipo_mensaje = 'danger';
    } else {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        try {
            $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, email, password, rol_id) VALUES (?, ?, ?, ?)");
            $stmt->execute([$nombre, $email, $hash, $rol_id]);
            
            $nuevo_id = $pdo->lastInsertId();
            
            // Registrar auditoría
            registrar_auditoria_operacion(
                'INSERT',
                'usuarios',
                $nuevo_id,
                "Usuario creado: $nombre",
                null,
                ['nombre' => $nombre, 'email' => $email, 'rol_id' => $rol_id],
                'usuarios'
            );
            
            $_SESSION['success_message'] = 'Usuario creado correctamente';
            header('Location: index.php');
            exit;
        } catch(Exception $e) {
            $mensaje = 'Error: ' . $e->getMessage();
            $tipo_mensaje = 'danger';
        }
    }
}
?>

<style>
    .form-card {
        border: none;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        padding: 30px;
    }
    .form-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 20px;
        border-radius: 15px 15px 0 0;
        margin: -30px -30px 30px -30px;
    }
    .form-label {
        font-weight: 600;
        color: #495057;
        margin-bottom: 8px;
    }
    .form-control, .form-select {
        border-radius: 8px;
        border: 1px solid #dee2e6;
        padding: 10px 15px;
    }
    .form-control:focus, .form-select:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
    }
</style>

<!-- Breadcrumb -->
<nav aria-label="breadcrumb" class="mb-4">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>index.php"><i class="fas fa-home"></i> Inicio</a></li>
        <li class="breadcrumb-item"><a href="index.php">Usuarios</a></li>
        <li class="breadcrumb-item active">Nuevo Usuario</li>
    </ol>
</nav>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card form-card">
            <div class="form-header">
                <h3 class="mb-0"><i class="fas fa-user-plus"></i> Crear Nuevo Usuario</h3>
                <p class="mb-0 opacity-75">Completa el formulario para registrar un nuevo usuario</p>
            </div>

            <?php if($mensaje): ?>
                <div class="alert alert-<?php echo $tipo_mensaje; ?> alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $mensaje; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-12">
                        <label class="form-label">
                            <i class="fas fa-user"></i> Nombre Completo
                        </label>
                        <input type="text" name="nombre" class="form-control" required 
                               placeholder="Ej: Juan Pérez" autofocus>
                    </div>
                    
                    <div class="col-md-12">
                        <label class="form-label">
                            <i class="fas fa-envelope"></i> Correo Electrónico
                        </label>
                        <input type="email" name="email" class="form-control" required 
                               placeholder="usuario@ejemplo.com">
                        <small class="text-muted">Este email será usado para iniciar sesión</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">
                            <i class="fas fa-lock"></i> Contraseña
                        </label>
                        <input type="password" name="password" class="form-control" required 
                               placeholder="Mínimo 6 caracteres" minlength="6">
                        <small class="text-muted">La contraseña debe tener al menos 6 caracteres</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">
                            <i class="fas fa-user-tag"></i> Rol del Usuario
                        </label>
                        <select name="rol_id" class="form-select" required>
                            <option value="">Seleccione un rol</option>
                            <?php foreach($roles as $r): ?>
                                <option value="<?php echo $r['id']; ?>">
                                    <?php echo htmlspecialchars($r['nombre']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted">El rol determina los permisos del usuario</small>
                    </div>
                    
                    <div class="col-12 mt-4">
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary btn-lg flex-fill">
                                <i class="fas fa-save"></i> Guardar Usuario
                            </button>
                            <a href="index.php" class="btn btn-outline-secondary btn-lg">
                                <i class="fas fa-times"></i> Cancelar
                            </a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include_once '../../includes/footer.php'; ?>
