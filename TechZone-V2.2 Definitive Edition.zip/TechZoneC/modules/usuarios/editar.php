<?php
require_once '../../includes/functions.php';
check_permission([1]); // Admin
include_once '../../includes/header.php';
$pdo = db_connect();

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$id]);
$u = $stmt->fetch();

if(!$u) { 
    echo "<div class='alert alert-danger'>Usuario no encontrado</div>";
    echo "<a href='index.php' class='btn btn-secondary'>Volver</a>";
    include_once '../../includes/footer.php';
    exit; 
}

$roles = $pdo->query("SELECT * FROM roles")->fetchAll();

$mensaje = '';
$tipo_mensaje = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $rol_id = (int)$_POST['rol_id'];
    $password = $_POST['password'] ?? '';

    try {
        // Guardar datos anteriores para auditoría
        $datos_old = [
            'nombre' => $u['nombre'],
            'email' => $u['email'],
            'rol_id' => $u['rol_id']
        ];
        
        if(!empty($password)) {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE usuarios SET nombre=?, email=?, rol_id=?, password=? WHERE id=?");
            $stmt->execute([$nombre, $email, $rol_id, $hash, $id]);
            $mensaje = 'Usuario actualizado correctamente (incluyendo contraseña)';
            $tipo_mensaje = 'success';
        } else {
            $stmt = $pdo->prepare("UPDATE usuarios SET nombre=?, email=?, rol_id=? WHERE id=?");
            $stmt->execute([$nombre, $email, $rol_id, $id]);
            $mensaje = 'Usuario actualizado correctamente';
            $tipo_mensaje = 'success';
        }
        
        // Registrar auditoría
        $datos_new = [
            'nombre' => $nombre,
            'email' => $email,
            'rol_id' => $rol_id
        ];
        
        registrar_auditoria_operacion(
            'UPDATE',
            'usuarios',
            $id,
            "Usuario actualizado: $nombre",
            $datos_old,
            $datos_new,
            'usuarios'
        );
        
        // Refresh datos
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
        $stmt->execute([$id]);
        $u = $stmt->fetch();
    } catch(Exception $e) {
        $mensaje = 'Error: ' . $e->getMessage();
        $tipo_mensaje = 'danger';
    }
}
?>

<style>
    .form-card {
        border: none;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        padding: 30px;
    }
    .form-header {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        color: white;
        padding: 20px;
        border-radius: 15px 15px 0 0;
        margin: -30px -30px 30px -30px;
    }
    .user-info-card {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px;
    }
    .form-label {
        font-weight: 600;
        color: #495057;
        margin-bottom: 8px;
    }
    .form-control, .form-select {
        border-radius: 8px;
        border: 1px solid #dee2e6;
        padding: 10px 15px;
    }
    .form-control:focus, .form-select:focus {
        border-color: #f5576c;
        box-shadow: 0 0 0 0.2rem rgba(245, 87, 108, 0.25);
    }
</style>

<!-- Breadcrumb -->
<nav aria-label="breadcrumb" class="mb-4">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>index.php"><i class="fas fa-home"></i> Inicio</a></li>
        <li class="breadcrumb-item"><a href="index.php">Usuarios</a></li>
        <li class="breadcrumb-item active">Editar Usuario</li>
    </ol>
</nav>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card form-card">
            <div class="form-header">
                <h3 class="mb-0"><i class="fas fa-user-edit"></i> Editar Usuario</h3>
                <p class="mb-0 opacity-75">Modifica la información del usuario</p>
            </div>

            <!-- Información del Usuario -->
            <div class="user-info-card">
                <div class="d-flex align-items-center">
                    <div class="user-avatar" style="width: 50px; height: 50px; border-radius: 50%; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); display: flex; align-items: center; justify-content: center; color: white; font-size: 20px; font-weight: bold; margin-right: 15px;">
                        <?php echo strtoupper(substr($u['nombre'], 0, 1)); ?>
                    </div>
                    <div>
                        <h5 class="mb-0"><?php echo htmlspecialchars($u['nombre']); ?></h5>
                        <p class="text-muted mb-0 small">
                            <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($u['email']); ?>
                        </p>
                    </div>
                </div>
            </div>

            <?php if($mensaje): ?>
                <div class="alert alert-<?php echo $tipo_mensaje; ?> alert-dismissible fade show" role="alert">
                    <i class="fas fa-<?php echo $tipo_mensaje == 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i> 
                    <?php echo $mensaje; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-12">
                        <label class="form-label">
                            <i class="fas fa-user"></i> Nombre Completo
                        </label>
                        <input type="text" name="nombre" class="form-control" 
                               value="<?php echo htmlspecialchars($u['nombre']); ?>" required>
                    </div>
                    
                    <div class="col-md-12">
                        <label class="form-label">
                            <i class="fas fa-envelope"></i> Correo Electrónico
                        </label>
                        <input type="email" name="email" class="form-control" 
                               value="<?php echo htmlspecialchars($u['email']); ?>" required>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">
                            <i class="fas fa-lock"></i> Nueva Contraseña
                        </label>
                        <input type="password" name="password" class="form-control" 
                               placeholder="Dejar en blanco para mantener la actual" minlength="6">
                        <small class="text-muted">Solo completa si deseas cambiar la contraseña</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">
                            <i class="fas fa-user-tag"></i> Rol del Usuario
                        </label>
                        <select name="rol_id" class="form-select" required>
                            <?php foreach($roles as $r): ?>
                                <option value="<?php echo $r['id']; ?>" 
                                    <?php echo $r['id'] == $u['rol_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($r['nombre']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">
                            <i class="fas fa-toggle-on"></i> Estado
                        </label>
                        <div class="form-control bg-light">
                            <?php if($u['activo']): ?>
                                <span class="badge bg-success">
                                    <i class="fas fa-check-circle"></i> Activo
                                </span>
                            <?php else: ?>
                                <span class="badge bg-secondary">
                                    <i class="fas fa-times-circle"></i> Inactivo
                                </span>
                            <?php endif; ?>
                        </div>
                        <small class="text-muted">El estado se gestiona desde la lista de usuarios</small>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label">
                            <i class="fas fa-calendar"></i> Fecha de Creación
                        </label>
                        <div class="form-control bg-light">
                            <?php echo date('d/m/Y H:i', strtotime($u['fecha_creacion'])); ?>
                        </div>
                    </div>
                    
                    <div class="col-12 mt-4">
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary btn-lg flex-fill">
                                <i class="fas fa-save"></i> Guardar Cambios
                            </button>
                            <a href="index.php" class="btn btn-outline-secondary btn-lg">
                                <i class="fas fa-arrow-left"></i> Volver
                            </a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include_once '../../includes/footer.php'; ?>
