<?php
require_once '../../includes/functions.php';
check_permission([1, 3]);
include_once '../../includes/header.php';
$pdo = db_connect();

$sql = "SELECT c.nombre as categoria, COUNT(p.id) as cantidad_prods,
        SUM(p.stock_actual) as stock_total,
        SUM(p.stock_actual * p.precio_compra) as valor_compra,
        SUM(p.stock_actual * p.precio_venta) as valor_venta
        FROM productos p
        JOIN categorias_producto c ON p.categoria_id = c.id
        WHERE p.activo = 1
        GROUP BY c.id";
$inv = $pdo->query($sql)->fetchAll();

$t_compra = 0;
$t_venta = 0;
?>

<h3>Inventario Valorizado por Categoría</h3>
<button onclick="window.print()" class="btn btn-secondary mb-3 no-print">Imprimir</button>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Categoría</th>
            <th>Items Diferentes</th>
            <th>Unidades Totales</th>
            <th>Valor Compra (Costo)</th>
            <th>Valor Venta (PVP)</th>
            <th>Utilidad Potencial</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($inv as $i):
            $t_compra += $i['valor_compra'];
            $t_venta += $i['valor_venta'];
        ?>
        <tr>
            <td><?php echo htmlspecialchars($i['categoria']); ?></td>
            <td><?php echo $i['cantidad_prods']; ?></td>
            <td><?php echo $i['stock_total']; ?></td>
            <td><?php echo format_currency($i['valor_compra']); ?></td>
            <td><?php echo format_currency($i['valor_venta']); ?></td>
            <td><?php echo format_currency($i['valor_venta'] - $i['valor_compra']); ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
    <tfoot class="table-dark">
        <tr>
            <td colspan="3" class="text-end">TOTALES:</td>
            <td><?php echo format_currency($t_compra); ?></td>
            <td><?php echo format_currency($t_venta); ?></td>
            <td><?php echo format_currency($t_venta - $t_compra); ?></td>
        </tr>
    </tfoot>
</table>

<style>@media print { .no-print { display: none; } }</style>

<?php include_once '../../includes/footer.php'; ?>
