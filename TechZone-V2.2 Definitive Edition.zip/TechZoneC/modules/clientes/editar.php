<?php
require_once '../../includes/functions.php';
check_permission([1, 2]); // Admin y Vendedor
include_once '../../includes/header.php';
$pdo = db_connect();

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM clientes WHERE id = ?");
$stmt->execute([$id]);
$c = $stmt->fetch();

if(!$c) { echo "Cliente no encontrado"; exit; }

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cedula = $_POST['cedula'];
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];

    try {
        // Guardar datos anteriores para auditoría
        $datos_old = [
            'cedula' => $c['cedula'],
            'nombre' => $c['nombre'],
            'email' => $c['email'],
            'telefono' => $c['telefono'],
            'direccion' => $c['direccion']
        ];
        
        $stmt = $pdo->prepare("UPDATE clientes SET cedula=?, nombre=?, email=?, telefono=?, direccion=? WHERE id=?");
        $stmt->execute([$cedula, $nombre, $email, $telefono, $direccion, $id]);
        
        // Registrar auditoría manual (el trigger también lo hará, pero es redundante y está bien)
        $datos_new = [
            'cedula' => $cedula,
            'nombre' => $nombre,
            'email' => $email,
            'telefono' => $telefono,
            'direccion' => $direccion
        ];
        
        registrar_auditoria_operacion(
            'UPDATE',
            'clientes',
            $id,
            "Cliente actualizado: $nombre",
            $datos_old,
            $datos_new,
            'clientes'
        );
        
        echo "<div class='alert alert-success'>Cliente actualizado</div>";
        $c = $_POST; // Update view
    } catch(Exception $e) {
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}
?>

<h3>Editar Cliente: <?php echo htmlspecialchars($c['nombre']); ?></h3>
<form method="POST" class="row g-3">
    <div class="col-md-6">
        <label>Cédula/RUC</label>
        <input type="text" name="cedula" class="form-control" value="<?php echo htmlspecialchars($c['cedula']); ?>" required>
    </div>
    <div class="col-md-6">
        <label>Nombre</label>
        <input type="text" name="nombre" class="form-control" value="<?php echo htmlspecialchars($c['nombre']); ?>" required>
    </div>
    <div class="col-md-6">
        <label>Email</label>
        <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($c['email']); ?>">
    </div>
    <div class="col-md-6">
        <label>Teléfono</label>
        <input type="text" name="telefono" class="form-control" value="<?php echo htmlspecialchars($c['telefono']); ?>">
    </div>
    <div class="col-12">
        <label>Dirección</label>
        <input type="text" name="direccion" class="form-control" value="<?php echo htmlspecialchars($c['direccion']); ?>">
    </div>
    <div class="col-12 mt-3">
        <button type="submit" class="btn btn-primary">Actualizar</button>
        <a href="index.php" class="btn btn-secondary">Volver</a>
    </div>
</form>

<?php include_once '../../includes/footer.php'; ?>
