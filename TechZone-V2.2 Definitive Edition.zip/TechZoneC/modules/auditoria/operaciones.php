<?php
require_once '../../includes/functions.php';
check_permission([1]); // Solo admin

include_once '../../includes/header.php';

$pdo = db_connect();

$start_date = $_GET['start'] ?? date('Y-m-d');
$end_date = $_GET['end'] ?? date('Y-m-d');
$start_ts = $start_date . " 00:00:00";
$end_ts = $end_date . " 23:59:59";

$stmt = $pdo->prepare("CALL sp_obtener_auditoria_operaciones(?, ?)");
$stmt->execute([$start_ts, $end_ts]);
$operaciones = $stmt->fetchAll();
?>

<h3>Auditoría de Operaciones CRUD</h3>

<form class="row g-3 mb-4" method="GET">
    <div class="col-auto">
        <label for="start" class="col-form-label">Desde</label>
        <input type="date" class="form-control" name="start" value="<?php echo $start_date; ?>">
    </div>
    <div class="col-auto">
        <label for="end" class="col-form-label">Hasta</label>
        <input type="date" class="form-control" name="end" value="<?php echo $end_date; ?>">
    </div>
    <div class="col-auto align-self-end">
        <button type="submit" class="btn btn-primary">Filtrar</button>
    </div>
</form>

<table class="table table-striped table-sm">
    <thead class="table-dark">
        <tr>
            <th>Fecha</th>
            <th>Usuario</th>
            <th>Acción</th>
            <th>Tabla</th>
            <th>ID Reg.</th>
            <th>Descripción</th>
            <th>Detalles</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($operaciones as $op): ?>
        <tr>
            <td><?php echo htmlspecialchars($op['fecha_hora']); ?></td>
            <td><?php echo htmlspecialchars($op['nombre_usuario']); ?></td>
            <td>
                <?php
                $badge = 'secondary';
                if ($op['accion'] == 'INSERT') $badge = 'primary';
                if ($op['accion'] == 'UPDATE') $badge = 'warning';
                if ($op['accion'] == 'DELETE') $badge = 'danger';
                ?>
                <span class="badge bg-<?php echo $badge; ?>"><?php echo htmlspecialchars($op['accion']); ?></span>
            </td>
            <td><?php echo htmlspecialchars($op['tabla_afectada']); ?></td>
            <td><?php echo htmlspecialchars($op['registro_afectado_id']); ?></td>
            <td><?php echo htmlspecialchars($op['descripcion_accion']); ?></td>
            <td>
                <button class="btn btn-xs btn-info btn-detalles"
                        data-bs-toggle="modal"
                        data-bs-target="#modalDetalle"
                        data-id="<?php echo $op['id']; ?>"
                        data-old='<?php echo htmlspecialchars($op['datos_anteriores'] ?? '{}', ENT_QUOTES); ?>'
                        data-new='<?php echo htmlspecialchars($op['datos_nuevos'] ?? '{}', ENT_QUOTES); ?>'
                        data-accion="<?php echo htmlspecialchars($op['accion']); ?>">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<!-- Modal Detalle -->
<div class="modal fade" id="modalDetalle" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Detalle de Operación</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div id="detalleContent" class="table-responsive">
            <table class="table table-bordered table-striped" id="tableComparison">
                <thead>
                    <tr>
                        <th>Campo</th>
                        <th>Valor Anterior (OLD)</th>
                        <th>Valor Nuevo (NEW)</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- JS fills this -->
                </tbody>
            </table>

            <!-- Fallback for DELETE/INSERT single views -->
            <div id="singleView" style="display:none;">
                <h6 id="singleViewTitle">Datos:</h6>
                <pre id="singleViewData" class="bg-light p-2 border"></pre>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const detailButtons = document.querySelectorAll('.btn-detalles');
    const tableBody = document.querySelector('#tableComparison tbody');
    const tableComparison = document.getElementById('tableComparison');
    const singleView = document.getElementById('singleView');
    const singleViewData = document.getElementById('singleViewData');
    const singleViewTitle = document.getElementById('singleViewTitle');

    detailButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const oldData = JSON.parse(this.getAttribute('data-old'));
            const newData = JSON.parse(this.getAttribute('data-new'));
            const action = this.getAttribute('data-accion');

            tableBody.innerHTML = '';
            tableComparison.style.display = 'none';
            singleView.style.display = 'none';

            if (action === 'UPDATE') {
                // Side by Side Comparison
                tableComparison.style.display = 'table';

                // Get all keys
                let keys = new Set([...Object.keys(oldData || {}), ...Object.keys(newData || {})]);

                keys.forEach(key => {
                    let oldVal = oldData[key] !== undefined ? oldData[key] : '';
                    let newVal = newData[key] !== undefined ? newData[key] : '';

                    let bgClass = (oldVal != newVal) ? 'table-warning' : '';

                    let row = `<tr class="${bgClass}">
                        <td><strong>${key}</strong></td>
                        <td class="text-danger">${oldVal}</td>
                        <td class="text-success">${newVal}</td>
                    </tr>`;
                    tableBody.innerHTML += row;
                });

            } else if (action === 'INSERT') {
                // Show New Data
                singleView.style.display = 'block';
                singleViewTitle.textContent = "Datos Nuevos Registrados:";
                // Pretty JSON or Table? Let's use Table key-value for cleaner look
                let html = '<table class="table table-bordered table-sm">';
                for (const [key, value] of Object.entries(newData)) {
                     html += `<tr><th>${key}</th><td>${value}</td></tr>`;
                }
                html += '</table>';
                singleViewData.innerHTML = html; // Using innerHTML to render table
                singleViewData.classList.remove('bg-light', 'p-2', 'border'); // Remove pre styling

            } else if (action === 'DELETE') {
                 // Show Old Data
                singleView.style.display = 'block';
                singleViewTitle.textContent = "Datos Eliminados:";
                let html = '<table class="table table-bordered table-sm">';
                for (const [key, value] of Object.entries(oldData)) {
                     html += `<tr><th>${key}</th><td>${value}</td></tr>`;
                }
                html += '</table>';
                singleViewData.innerHTML = html;
                singleViewData.classList.remove('bg-light', 'p-2', 'border');
            }
        });
    });
});
</script>

<?php include_once '../../includes/footer.php'; ?>
