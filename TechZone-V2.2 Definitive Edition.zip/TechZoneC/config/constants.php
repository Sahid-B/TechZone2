<?php
// config/constants.php
// Configuración de URLs - Puertos estándar de XAMPP
// Puerto 80: HTTP (no se especifica, es el puerto por defecto)
// Puerto 443: HTTPS (no se especifica, es el puerto por defecto)
define('BASE_URL', 'http://localhost/techzone/');
define('BASE_URL_HTTPS', 'https://localhost/techzone/');

// Configuración de Base de Datos - Puerto 3306 (estándar MySQL)
define('DB_HOST', 'localhost');
define('DB_PORT', '3306'); // Puerto estándar de MySQL en XAMPP
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'techzone');
define('DB_CHARSET', 'utf8mb4');
?>
