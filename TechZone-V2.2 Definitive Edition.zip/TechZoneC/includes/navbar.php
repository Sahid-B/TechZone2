<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo BASE_URL; ?>dashboard.php"><i class="fas fa-microchip"></i> TechZone</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto">

        <!-- Dashboard -->
        <li class="nav-item">
          <a class="nav-link" href="<?php echo BASE_URL; ?>dashboard.php">Dashboard</a>
        </li>

        <!-- Productos (Admin y Almacen) -->
        <?php if(in_array($_SESSION['rol_id'], [1, 3])): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo BASE_URL; ?>modules/productos/index.php">Productos</a>
        </li>
        <?php endif; ?>

        <!-- Ventas (Admin y Vendedor) -->
        <?php if(in_array($_SESSION['rol_id'], [1, 2])): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo BASE_URL; ?>modules/ventas/index.php">Ventas</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo BASE_URL; ?>modules/ventas/nueva-venta.php">Nueva Venta</a>
        </li>
        <?php endif; ?>

        <!-- Clientes (Admin y Vendedor) -->
        <?php if(in_array($_SESSION['rol_id'], [1, 2])): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo BASE_URL; ?>modules/clientes/index.php">Clientes</a>
        </li>
        <?php endif; ?>

        <!-- Auditoría y Usuarios (Solo Admin) -->
        <?php if($_SESSION['rol_id'] == 1): ?>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Admin</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>modules/usuarios/index.php">Usuarios</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>modules/auditoria/logins.php">Auditoría Logins</a></li>
            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>modules/auditoria/operaciones.php">Auditoría Operaciones</a></li>
            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>modules/reportes/index.php">Reportes</a></li>
          </ul>
        </li>
        <?php endif; ?>

      </ul>
      <span class="navbar-text me-3">
        <?php echo $_SESSION['nombre']; ?> (<?php echo $_SESSION['rol_nombre']; ?>)
      </span>
      <a href="<?php echo BASE_URL; ?>auth/logout.php" class="btn btn-danger btn-sm">Salir</a>
    </div>
  </div>
</nav>
